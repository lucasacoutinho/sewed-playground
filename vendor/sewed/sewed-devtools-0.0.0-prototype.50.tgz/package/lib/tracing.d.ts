import { Tracer } from "effect";
import type { DevToolsSchema } from "effect/devtools";
import { Diagnostics } from "sewed";
import type { Health, Span } from "./model.ts";
type Observation = Diagnostics.Observation;
/** Effect installs RPC attributes after constructing the span, including long-lived streams. */
export declare const observeAttributes: (tracer: Tracer.Tracer, send: (span: DevToolsSchema.Span) => void) => Tracer.Tracer;
export interface TraceStore {
    readonly sendUnsafe: (message: DevToolsSchema.Span | DevToolsSchema.SpanEvent) => void;
    readonly sendObservation: (observation: Observation) => void;
    readonly consume: (records: readonly {
        readonly sequence: number;
        readonly event: Diagnostics.Event;
    }[]) => void;
    readonly snapshot: () => {
        readonly spans: readonly Span[];
        readonly evictedSpans: number;
        readonly droppedTraceEvents: number;
    };
    readonly health: (options: {
        readonly complete: boolean;
        readonly dropped: number;
    }) => Health;
}
export declare const traceStore: (capacity: number) => TraceStore;
export {};
//# sourceMappingURL=tracing.d.ts.map