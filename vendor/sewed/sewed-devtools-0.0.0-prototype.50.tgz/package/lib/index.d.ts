import { Effect, Layer } from "effect";
import type { Scope } from "effect";
import { Diagnostics, MainContext, SewedError } from "sewed";
import type { Snapshot } from "./model.ts";
export type { Snapshot, Span, Health } from "./model.ts";
export interface Options {
    readonly capacity?: number;
}
export interface Handle {
    readonly layer: Diagnostics.Collector["layer"];
    readonly snapshot: Effect.Effect<Snapshot>;
}
export declare const make: (options?: Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
export declare const layer: (options?: Options & {
    readonly enabled?: boolean;
}) => Layer.Layer<never, SewedError, MainContext>;
//# sourceMappingURL=index.d.ts.map