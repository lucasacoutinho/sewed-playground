import { type SewedViteOptions } from "@sewed/vite";
export declare const sewedDevTools: (options: SewedViteOptions) => import("vite").Plugin<any>;
//# sourceMappingURL=vite.d.ts.map