import { Schema } from "effect";
/**
 * Where the updater asks for releases; Squirrel on Windows and macOS read this feed. Only HTTPS
 * is accepted, because a feed a network attacker can rewrite is a feed that installs their code.
 */
export declare const Feed: Schema.Struct<{
    readonly url: Schema.String;
    readonly headers: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
    readonly serverType: Schema.optionalKey<Schema.Literals<readonly ["json", "default"]>>;
}>;
export type Feed = typeof Feed.Type;
export declare const GithubRepository: Schema.Struct<{
    readonly owner: Schema.String;
    readonly repo: Schema.String;
    readonly host: Schema.optionalKey<Schema.String>;
}>;
export type GithubRepository = typeof GithubRepository.Type;
export declare const State: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"idle">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"checking">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"available">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"not-available">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"downloaded">;
    readonly releaseName: Schema.String;
    readonly releaseNotes: Schema.String;
    readonly releaseDate: Schema.String;
    readonly updateUrl: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"installing">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"error">;
    readonly message: Schema.String;
}>]>;
export type State = typeof State.Type;
/**
 * The update.electronjs.org feed for a repository, platform, architecture, and version. The
 * repository is validated and every path segment is encoded, so no input can escape its segment.
 */
export declare const feedUrl: (repository: GithubRepository, platform: string, arch: string, version: string) => string;
//# sourceMappingURL=UpdaterSchema.d.ts.map