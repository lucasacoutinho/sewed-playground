import type { GithubRepository } from "./Updater.ts";
/** A Forge maker preset; each maps to the maker package Forge resolves by name. */
export type Maker = "squirrel" | "zip" | "deb" | "rpm" | "dmg";
export type Platform = "win32" | "darwin" | "linux";
export interface GithubPublish extends GithubRepository {
    readonly prerelease?: boolean;
    readonly draft?: boolean;
}
export interface Options {
    /** The executable and product name; defaults to the package name Forge reads. */
    readonly name?: string;
    /** Icon path without extension; Forge picks the platform's extension. */
    readonly icon?: string;
    readonly appBundleId?: string;
    readonly asar?: boolean;
    readonly extraResources?: readonly string[];
    /** Globs or patterns Forge leaves out of the package; the build output stays in. */
    readonly ignore?: readonly (string | RegExp)[];
    /** Maker presets; defaults to Squirrel for Windows, DMG and ZIP for macOS, DEB and RPM for Linux. */
    readonly makers?: readonly Maker[];
    /** Publishing to GitHub releases, which update.electronjs.org serves to `Updater.githubFeed`. */
    readonly github?: GithubPublish;
}
export interface Entry {
    readonly name: string;
    readonly config?: Record<string, unknown>;
    readonly platforms?: readonly Platform[];
}
/** The shape Forge reads from `forge.config.js`; it satisfies Forge's own `ForgeConfig` type. */
export interface Config {
    readonly packagerConfig: Record<string, unknown>;
    readonly rebuildConfig: Record<string, unknown>;
    readonly makers: readonly Entry[];
    readonly publishers: readonly Entry[];
    readonly plugins: readonly Entry[];
}
/**
 * Builds a Forge configuration from a few decisions. Makers are referenced by package name, so
 * only the makers you keep need installing, and the GitHub publisher shares its repository with
 * `Updater.githubFeed`, which is the whole binding between publishing and updating.
 */
export declare const makeConfig: (options?: Options) => Config;
//# sourceMappingURL=config.d.ts.map