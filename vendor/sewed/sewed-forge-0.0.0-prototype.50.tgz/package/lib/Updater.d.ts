import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import { MainContext, SewedError } from "sewed";
import { Feed, GithubRepository, type State } from "./UpdaterSchema.ts";
export { Feed, GithubRepository, State, feedUrl } from "./UpdaterSchema.ts";
/** The feed for the running application's platform, architecture, and version. */
export declare const githubFeed: (repository: GithubRepository) => Effect.Effect<Feed, SewedError, MainContext>;
export interface Handle {
    /** Replays the current state and follows the updater's events. */
    readonly state: Stream.Stream<State, SewedError, MainContext>;
    readonly current: Effect.Effect<State, SewedError, MainContext>;
    readonly check: Effect.Effect<void, SewedError, MainContext>;
    /** Restarts into the downloaded update; `Protocol` unless the state is downloaded. */
    readonly install: Effect.Effect<void, SewedError, MainContext>;
    readonly feed: Effect.Effect<string, SewedError, MainContext>;
}
/**
 * Points Electron's updater at a feed for the scope's lifetime and observes it. One updater is
 * active at a time, and Linux has no updater, so `make` fails with `Native` there.
 */
export declare const make: (feed: Feed) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Updater.d.ts.map