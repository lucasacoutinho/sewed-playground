import { Effect } from "effect";
import { Declaration as SewedDeclaration } from "sewed/main";
import { MainContext, SewedError } from "sewed";
import { Declaration, type Parameters, type Report } from "./CrashReporterSchema.ts";
export { Declaration, Key, Options, Parameters, Report, Value } from "./CrashReporterSchema.ts";
/**
 * Declares the crash reporter for `App.run`: it starts before readiness so every later process is
 * covered. `directory` is created, recursively, and then set as Electron's `crashDumps` path
 * before the reporter starts, so the directory exists once the program runs; invalid options, or a
 * directory that cannot be created, fail startup with code `Startup`.
 */
export declare const declare: (options: Declaration) => SewedDeclaration.Declaration;
export declare const lastReport: Effect.Effect<Report | null, SewedError, MainContext>;
export declare const uploadedReports: Effect.Effect<readonly Report[], SewedError, MainContext>;
export declare const uploadToServer: Effect.Effect<boolean, SewedError, MainContext>;
export declare const setUploadToServer: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
export declare const parameters: Effect.Effect<Parameters, SewedError, MainContext>;
export declare const setParameter: (key: string, value: string) => Effect.Effect<void, SewedError, MainContext>;
export declare const removeParameter: (key: string) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=CrashReporter.d.ts.map