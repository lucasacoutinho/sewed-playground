import { Schema } from "effect";
/** Crash parameter keys are at most 39 bytes and values at most 127 bytes, as Electron requires. */
export declare const Key: Schema.String;
export declare const Value: Schema.String;
export declare const Parameters: Schema.$Record<Schema.String, Schema.String>;
export type Parameters = typeof Parameters.Type;
export declare const Options: Schema.Struct<{
    /** Crash reports carry process state, so they only travel over HTTPS. */
    readonly submitUrl: Schema.optionalKey<Schema.String>;
    readonly productName: Schema.optionalKey<Schema.String>;
    readonly companyName: Schema.optionalKey<Schema.String>;
    readonly uploadToServer: Schema.optionalKey<Schema.Boolean>;
    readonly ignoreSystemCrashHandler: Schema.optionalKey<Schema.Boolean>;
    readonly rateLimit: Schema.optionalKey<Schema.Boolean>;
    readonly compress: Schema.optionalKey<Schema.Boolean>;
    readonly extra: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
    readonly globalExtra: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
}>;
export type Options = typeof Options.Type;
export declare const Report: Schema.Struct<{
    readonly id: Schema.String;
    readonly date: Schema.String;
}>;
export type Report = typeof Report.Type;
/**
 * `Options` plus the crash-dump directory, created and then set as Electron's `crashDumps` path
 * before the reporter starts.
 */
export declare const Declaration: Schema.Struct<{
    /** Crash reports carry process state, so they only travel over HTTPS. */
    readonly submitUrl: Schema.optionalKey<Schema.String>;
    readonly productName: Schema.optionalKey<Schema.String>;
    readonly companyName: Schema.optionalKey<Schema.String>;
    readonly uploadToServer: Schema.optionalKey<Schema.Boolean>;
    readonly ignoreSystemCrashHandler: Schema.optionalKey<Schema.Boolean>;
    readonly rateLimit: Schema.optionalKey<Schema.Boolean>;
    readonly compress: Schema.optionalKey<Schema.Boolean>;
    readonly extra: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
    readonly globalExtra: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
    readonly directory: Schema.optionalKey<Schema.String>;
}>;
export type Declaration = typeof Declaration.Type;
//# sourceMappingURL=CrashReporterSchema.d.ts.map