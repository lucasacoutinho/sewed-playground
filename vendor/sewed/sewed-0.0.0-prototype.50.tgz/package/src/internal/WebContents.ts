import { statSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { BrowserWindow, screen, type WebContents } from "electron";
import { Deferred, Effect, Stream } from "effect";
import type { Bound, Complete } from "../Binding.ts";
import * as Decidables from "../Decidables.ts";
import type * as Download from "../Download.ts";
import type { Entry } from "../Renderer.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Blocked } from "../WebContents.ts";
import * as UrlRule from "../UrlRule.ts";
import { mainBridge } from "./MainBridge.ts";
import * as BindingContract from "./BindingContract.ts";
import * as ContentsDownloads from "./ContentsDownloads.ts";
import * as ContentsBluetooth from "./ContentsBluetooth.ts";
import * as ContentsInput from "./ContentsInput.ts";
import * as ContentsPosture from "./ContentsPosture.ts";
import * as ContentsRegistry from "./ContentsRegistry.ts";
import * as ContentsWebviews from "./ContentsWebviews.ts";
import * as Registry from "./DecisionRegistry.ts";
import { nativeImageOf } from "./ImageSource.ts";
import { sink } from "./Diagnostics.ts";
import * as Observation from "./Observation.ts";
import * as Observers from "./Observers.ts";
import { core, onFreshTask } from "./WebContentsCore.ts";

/**
 * A renderer's web contents: the shared core plus the bridge, loading, and the bound-document
 * allowance. A browser window passes `windowDecidesTitle` for its own contents (see
 * `Owner.windowDecidesTitle`).
 */
export const webContents = (
  native: WebContents,
  options: { readonly windowDecidesTitle?: boolean } = {},
) =>
  Effect.gen(function* () {
    yield* MainContext;
    const lifetime = yield* Effect.scope;
    const bridge = mainBridge(native, lifetime, yield* sink);
    let boundDocument: string | undefined;
    const blocked = Observers.make<Blocked>("Blocked");
    const downloadEntry = (sourceId: string): ContentsDownloads.Governor => ({
      sourceId,
      onBlocked: (url) => blocked.publish({ kind: "download", url }),
      decide: (download) => registry.resolveSync(Decidables.WebContents.Download, download),
    });
    // This document's own posture — see `ContentsPosture.rendererFallbacks`'s own doc for why this
    // lives in its own importable module rather than inline here — plus input and download gates
    // that attach only while their decidables have a decider (`ContentsInput.hook` and
    // `ContentsDownloads.hook`). Their thunks read `registry` after `make` has returned, which is
    // why the annotation is here: the reference is inside its own initializer.
    const registry: Registry.Registry<"contents"> = Registry.make({
      owner: "contents",
      fallbacks: ContentsPosture.rendererFallbacks(),
      hooks: [
        ContentsInput.hook(native, () => registry),
        ContentsBluetooth.hook(
          () => native,
          () => registry,
        ),
        ContentsDownloads.hook(native.session, native.id, () => {
          const sourceId = ContentsRegistry.handleIdOf(native.id);
          if (sourceId === undefined)
            throw new SewedError({ code: "Closed", message: "Web contents has no Sewed owner" });
          return downloadEntry(sourceId);
        }),
      ],
    });
    const { contents, control } = yield* core(native, {
      registry,
      ...options,
      allows: (url) => UrlRule.documentKey(url) === boundDocument,
      blocked: (kind, url) => blocked.publish({ kind, url }),
      imageOf: nativeImageOf,
      displayScaleFactor: () => {
        const window = BrowserWindow.fromWebContents(native);
        return window === null
          ? screen.getPrimaryDisplay().scaleFactor
          : screen.getDisplayMatching(window.getBounds()).scaleFactor;
      },
    });
    // The bound document moved with the History API; a reload of that URL stays allowed.
    const inPage = (_event: Electron.Event, url: string, mainFrame: boolean) => {
      if (!mainFrame) return;
      const document = URL.parse(url);
      if (document) boundDocument = UrlRule.documentKey(document);
    };
    native.on("did-navigate-in-page", inPage);
    yield* Effect.addFinalizer(() =>
      Effect.sync(() => {
        native.off("did-navigate-in-page", inPage);
        blocked.finish();
      }),
    );
    /**
     * The downloads this document starts and `Decidables.WebContents.Download` accepted, decided
     * through this document's own registry (whose fallback prompts rather than denies — see its
     * declaration above) rather than a function passed here. Subscribing is what engages the native
     * listener while a subscriber exists; a download decider also engages it on its own through the
     * registry hook above, so it keeps governing after the last subscriber ends. With neither one,
     * Electron's own download behavior applies. A denial is still published on `blocked` without a
     * `downloads` subscriber. Accepted items are adopted only while at least one subscriber can
     * receive their handle. `sourceId`'s lookup stays lazy for the same reason it always has —
     * `internal/Window.ts` and `internal/WebContentsView.ts` register this contents' id with
     * `ContentsRegistry` at different points relative to calling `webContents`, and only by the
     * time a caller can reach this stream or install a decider has either finished doing so.
     */
    const downloads: Stream.Stream<Download.Handle, SewedError, MainContext> = Stream.unwrap(
      Effect.gen(function* () {
        yield* MainContext;
        if (control.isClosed()) return Stream.fail(control.closedError());
        const sourceId = ContentsRegistry.handleIdOf(native.id);
        if (sourceId === undefined)
          return Stream.fail(
            new SewedError({ code: "Closed", message: "Web contents has no Sewed owner" }),
          );
        return Observation.listen<Download.Handle>("Downloads", (offer) =>
          Effect.sync(() => {
            const ungovern = ContentsDownloads.install(
              native.session,
              native.id,
              downloadEntry(sourceId),
            );
            const unobserve = ContentsDownloads.observe(native.session, native.id, offer);
            return () => {
              unobserve();
              ungovern();
            };
          }),
        ).pipe(Stream.interruptWhen(Deferred.await(control.closed)));
      }),
    );
    // Webviews this page attaches become owned handles; see `ContentsWebviews.install`.
    const webviews = ContentsWebviews.install(native, yield* Effect.context<MainContext>(), {
      imageOf: nativeImageOf,
      displayScaleFactor: () => screen.getPrimaryDisplay().scaleFactor,
    });
    yield* Effect.addFinalizer(() => Effect.sync(webviews.release));
    return {
      /**
       * This document's own decision registry, exposed for `internal/Window.ts` alone: its
       * window-level `page-title-updated` listener resolves `Decidables.WebContents.TitleUpdate`
       * here, because only that event's own `preventDefault` holds the native title bar (see
       * `docs/window-controls.md`). Not part of the public `WebContents` handle — `decide` above
       * is the public door onto this same registry.
       */
      registry,
      contents: {
        ...contents,
        /**
         * The webviews and main-frame navigations this document's policy denied, and the popups
         * denied with no decider installed to allow them; an allowed popup opens and is not reported
         * here.
         */
        blocked: blocked.stream,
        /**
         * The `<webview>`s this page attaches from now on, each as an owned
         * `ContentsWebviews.Handle`. A window needs `webviewTag` and a
         * `Decidables.WebContents.WebviewAttach` decider for any to attach.
         */
        webviews: webviews.webviews.pipe(Stream.interruptWhen(Deferred.await(control.closed))),
        load: <Keys extends string, const B extends readonly Bound<Keys>[]>(
          entry: Entry<Keys> & Complete<Keys, B>,
          options: { readonly bindings: B },
        ) =>
          Effect.gen(function* () {
            yield* MainContext;
            // A `file:` document must exist, and be a file rather than a directory, before the
            // bridge is configured or Electron navigates to it; every other scheme is Electron's
            // own problem to report through `loadURL`. `fileURLToPath` itself throws for some
            // well-formed URLs (an encoded slash, on this platform) — that throw fails `Protocol`
            // with its own message, kept as the cause, distinct from "not found" so a consumer does
            // not mistake a URL it could not even read as a path for one that read as a path that
            // does not exist.
            if (entry.url.protocol === "file:") {
              const path = yield* Effect.try({
                try: () => fileURLToPath(entry.url),
                catch: (cause) =>
                  new SewedError({
                    code: "Protocol",
                    message: `Local document URL could not be read as a path: ${entry.url}`,
                    cause,
                  }),
              });
              let stats: ReturnType<typeof statSync> | undefined;
              // A missing path is an answer here, not a failure.
              // @effect-diagnostics-next-line tryCatchInEffectGen:off
              try {
                stats = statSync(path);
              } catch {
                stats = undefined;
              }
              if (stats === undefined)
                return yield* new SewedError({
                  code: "Protocol",
                  message: `Local document not found: ${path}`,
                });
              if (!stats.isFile())
                return yield* new SewedError({
                  code: "Protocol",
                  message: `Local document is not a file: ${path}`,
                });
            }
            yield* BindingContract.validate(
              entry.bindings.map((binding) => binding.key),
              options.bindings.map((binding) => binding.slot.key),
              "Window bindings do not match the renderer entry",
            );
            yield* control.operation(() => {
              boundDocument = UrlRule.documentKey(entry.url);
              bridge.configure(entry.url, options.bindings);
            });
            yield* Effect.tryPromise({
              try: () => onFreshTask(() => native.loadURL(entry.url.href)),
              catch: (cause) =>
                new SewedError({ code: "Native", message: "Could not load renderer", cause }),
            });
          }),
        reload: control.operation(() => {
          native.reload();
        }),
        /** Reloads the document, fetching every resource again instead of reading the cache. */
        reloadIgnoringCache: control.operation(() => {
          native.reloadIgnoringCache();
        }),
        /** Stops a navigation or load that is still in progress. */
        stopLoading: control.operation(() => {
          native.stop();
        }),
        downloads,
      },
    };
  });
