import { Schema } from "effect";
export declare const Product: Schema.Struct<{
    readonly productIdentifier: Schema.String;
    readonly localizedTitle: Schema.String;
    readonly localizedDescription: Schema.String;
    readonly price: Schema.Finite;
    readonly formattedPrice: Schema.String;
    readonly currencyCode: Schema.String;
    readonly isDownloadable: Schema.Boolean;
}>;
export type Product = typeof Product.Type;
export declare const TransactionState: Schema.Literals<readonly ["purchasing", "purchased", "failed", "restored", "deferred"]>;
export type TransactionState = typeof TransactionState.Type;
export declare const Transaction: Schema.Struct<{
    readonly transactionIdentifier: Schema.String;
    readonly originalTransactionIdentifier: Schema.String;
    readonly transactionDate: Schema.String;
    readonly transactionState: Schema.Literals<readonly ["purchasing", "purchased", "failed", "restored", "deferred"]>;
    readonly errorCode: Schema.Finite;
    readonly errorMessage: Schema.String;
    readonly productIdentifier: Schema.String;
    readonly quantity: Schema.Finite;
}>;
export type Transaction = typeof Transaction.Type;
export declare const Quantity: Schema.Int;
//# sourceMappingURL=InAppPurchase.d.ts.map