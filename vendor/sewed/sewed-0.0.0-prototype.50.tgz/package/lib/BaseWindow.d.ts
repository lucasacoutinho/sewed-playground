import { BaseWindow as NativeBaseWindow } from "electron";
import { Effect } from "effect";
import type * as Window from "./internal/Window.ts";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
export interface Options extends Window.Options {
    /** Another Sewed window; with `modal: true` this window blocks it. */
    readonly parent?: Window.Parent;
}
export type AttachOptions = Window.AttachOptions;
declare const create: (options: Options) => Effect.Effect<Omit<{
    setFocusable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    focusable: Effect.Effect<boolean, SewedError, MainContext>;
    contentProtected: Effect.Effect<boolean, SewedError, MainContext>;
    setRepresentedFilename: (path: string) => Effect.Effect<void, SewedError, MainContext>;
    representedFilename: Effect.Effect<string, SewedError, MainContext>;
    setDocumentEdited: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    documentEdited: Effect.Effect<boolean, SewedError, MainContext>;
    setVibrancy: (vibrancy: import("./WindowControls.ts").Vibrancy) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonPosition: (position: import("./Screen.ts").Point | null) => Effect.Effect<void, SewedError, MainContext>;
    windowButtonPosition: Effect.Effect<{
        x: number;
        y: number;
    } | null, SewedError, MainContext>;
    setSheetOffset: (offset: {
        readonly y: number;
        readonly x?: number;
    }) => Effect.Effect<void, SewedError, MainContext>;
    previewFile: (path: string, displayName?: string) => Effect.Effect<void, SewedError, MainContext>;
    closeFilePreview: Effect.Effect<void, SewedError, MainContext>;
    setHiddenInMissionControl: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    hiddenInMissionControl: Effect.Effect<boolean, SewedError, MainContext>;
    setAutoHideCursor: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    invalidateShadow: Effect.Effect<void, SewedError, MainContext>;
    setExcludedFromShownWindowsMenu: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    excludedFromShownWindowsMenu: Effect.Effect<boolean, SewedError, MainContext>;
    tabs: {
        identifier: Effect.Effect<string | null, SewedError, MainContext>;
        selectNext: Effect.Effect<void, SewedError, MainContext>;
        selectPrevious: Effect.Effect<void, SewedError, MainContext>;
        showAll: Effect.Effect<void, SewedError, MainContext>;
        mergeAll: Effect.Effect<void, SewedError, MainContext>;
        moveToNewWindow: Effect.Effect<void, SewedError, MainContext>;
        toggleBar: Effect.Effect<void, SewedError, MainContext>;
        add: (window: {
            readonly id: string;
        }) => Effect.Effect<void, SewedError, MainContext>;
    };
    setAccentColor: (color: import("./WindowControls.ts").AccentColor) => Effect.Effect<void, SewedError, MainContext>;
    setAppDetails: (details: import("./WindowControls.ts").AppDetails) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundMaterial: (material: import("./WindowControls.ts").BackgroundMaterial) => Effect.Effect<void, SewedError, MainContext>;
    setThumbarButtons: (buttons: ReadonlyArray<import("./WindowControls.ts").ThumbarButton>) => Effect.Effect<void, SewedError, MainContext>;
    thumbarClicks: import("effect/Stream").Stream<string, SewedError, MainContext>;
    setThumbnailClip: (region: import("./WindowControls.ts").Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setThumbnailToolTip: (text: string) => Effect.Effect<void, SewedError, MainContext>;
    snapped: Effect.Effect<boolean, SewedError, MainContext>;
    tabletMode: Effect.Effect<boolean, SewedError, MainContext>;
    windowMessages: (message: number) => import("effect/Stream").Stream<import("./WindowControls.ts").WindowMessage, SewedError, MainContext>;
    native: NativeBaseWindow;
    closed: import("effect/Deferred").Deferred<void, never>;
    webContents: {
        frames: (options?: import("./WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("./WebContents.ts").Frame, SewedError, MainContext>;
        painting: Effect.Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, SewedError, MainContext>;
        setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setFrameRate: (rate: import("./WebContents.ts").FrameRate) => Effect.Effect<void, SewedError, MainContext>;
        invalidate: Effect.Effect<void, SewedError, MainContext>;
        frameTree: Effect.Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], SewedError, MainContext>;
        opener: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        focusedFrame: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        hostId: Effect.Effect<string | null, SewedError, MainContext>;
        devToolsContentsId: Effect.Effect<number | null, SewedError, MainContext>;
        collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        frame: (identity: import("./WebContents.ts").FrameAddress) => {
            info: Effect.Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly top: number | null;
                readonly detached: boolean;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            }, SewedError, MainContext>;
            reload: Effect.Effect<void, SewedError, MainContext>;
            collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        };
        zoomLevel: Effect.Effect<number, SewedError, MainContext>;
        setZoomLevel: (level: import("./WebContents.ts").ZoomLevel) => Effect.Effect<void, SewedError, MainContext>;
        zoomMode: Effect.Effect<"default" | "disabled" | "isolated" | "manual", SewedError, MainContext>;
        setZoomMode: (mode: import("./WebContents.ts").ZoomMode) => Effect.Effect<void, SewedError, MainContext>;
        rendererProcessId: Effect.Effect<number, SewedError, MainContext>;
        sharedWorkers: Effect.Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], SewedError, MainContext>;
        inspectSharedWorker: (id: string) => Effect.Effect<void, SewedError, MainContext>;
        devToolsTargetId: Effect.Effect<string, SewedError, MainContext>;
        addDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        removeDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        printers: Effect.Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], SewedError, MainContext>;
        webRtc: Effect.Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, SewedError, MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("./WebContents.ts").WebRtcIpHandlingPolicy) => Effect.Effect<void, SewedError, MainContext>;
        setWebRtcUdpPortRange: (range: import("./WebContents.ts").UdpPortRange) => Effect.Effect<void, SewedError, MainContext>;
        caretBrowsing: Effect.Effect<boolean, SewedError, MainContext>;
        setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, SewedError, MainContext>;
        activity: Effect.Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, SewedError, MainContext>;
        devTools: Effect.Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, SewedError, MainContext>;
        toggleDevTools: Effect.Effect<void, SewedError, MainContext>;
        setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
        inspectElement: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, MainContext>;
        enableDeviceEmulation: (parameters: import("./WebContents.ts").DeviceEmulation) => Effect.Effect<void, SewedError, MainContext>;
        disableDeviceEmulation: Effect.Effect<void, SewedError, MainContext>;
        edit: (command: import("./WebContents.ts").EditCommand) => Effect.Effect<void, SewedError, MainContext>;
        replace: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        adjustSelection: (adjustment: import("./WebContents.ts").SelectionAdjustment) => Effect.Effect<void, SewedError, MainContext>;
        copyVideoFrameAt: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        saveVideoFrameAs: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        copyImageAt: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        setVisualZoomLimits: (limits: import("./WebContents.ts").VisualZoomLimits) => Effect.Effect<void, SewedError, MainContext>;
        setImageAnimationPolicy: (policy: import("./WebContents.ts").ImageAnimationPolicy) => Effect.Effect<void, SewedError, MainContext>;
        startDrag: (drag: import("./WebContents.ts").Drag) => Effect.Effect<void, SewedError, MainContext>;
        showDefinitionForSelection: Effect.Effect<void, SewedError, MainContext>;
        takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        blocked: import("effect/Stream").Stream<{
            readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
            readonly url: string;
        }, SewedError, MainContext>;
        webviews: import("effect/Stream").Stream<import("./internal/ContentsWebviews.ts").Handle, SewedError, MainContext>;
        load: <Keys extends string, const B extends readonly import("./Binding.ts").Bound<Keys>[]>(entry: import("./Renderer.ts").Entry<Keys> & import("./Binding.ts").Complete<Keys, B>, options: {
            readonly bindings: B;
        }) => Effect.Effect<undefined, SewedError, MainContext>;
        reload: Effect.Effect<void, SewedError, MainContext>;
        reloadIgnoringCache: Effect.Effect<void, SewedError, MainContext>;
        stopLoading: Effect.Effect<void, SewedError, MainContext>;
        downloads: import("effect/Stream").Stream<import("./Download.ts").Handle, SewedError, MainContext>;
        print: (options?: import("./WebContents.ts").PrintOptions) => Effect.Effect<void, SewedError, MainContext>;
        pdf: (options?: import("./WebContents.ts").PdfOptions) => Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
        capture: (options?: import("./WebContents.ts").CaptureOptions) => Effect.Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, SewedError, MainContext>;
        zoom: import("effect/Stream").Stream<{
            readonly factor: number;
        }, never, MainContext>;
        setZoom: (factor: number) => Effect.Effect<void, SewedError, MainContext>;
        audio: import("effect/Stream").Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, MainContext>;
        setAudioMuted: (muted: boolean) => Effect.Effect<void, SewedError, MainContext>;
        userAgent: Effect.Effect<string, SewedError, MainContext>;
        setUserAgent: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
        insertText: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        savePage: (path: string, type?: import("./WebContents.ts").SaveType) => Effect.Effect<void, SewedError, MainContext>;
        setBackgroundThrottling: (allowed: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
        find: (text: string, options?: import("./WebContents.ts").FindOptions) => Effect.Effect<import("./WebContents.ts").Search, SewedError, MainContext | import("effect/Scope").Scope>;
        findNext: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
        stopFind: (action?: import("./WebContents.ts").FindStop) => Effect.Effect<void, SewedError, MainContext>;
        style: (css: string, options?: import("./WebContents.ts").StyleOptions) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
        history: import("effect/Stream").Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, MainContext>;
        back: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        forward: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        go: (index: number) => Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        removeHistoryEntry: (index: number) => Effect.Effect<void, SewedError, MainContext>;
        clearHistory: Effect.Effect<void, SewedError, MainContext>;
        openDevTools: (options?: import("./WebContents.ts").DevToolsOptions) => Effect.Effect<void, SewedError, MainContext>;
        openDevToolsIn: (host: import("./WebContentsView.ts").Handle, options?: import("./WebContents.ts").DevToolsHostOptions) => Effect.Effect<void, SewedError, MainContext>;
        closeDevTools: Effect.Effect<void, SewedError, MainContext>;
        focus: Effect.Effect<void, SewedError, MainContext>;
        console: import("effect/Stream").Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, SewedError, MainContext>;
        state: import("effect/Stream").Stream<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, MainContext>;
        responsiveness: import("effect/Stream").Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, MainContext>;
        favicons: import("effect/Stream").Stream<readonly string[], never, MainContext>;
        title: import("effect/Stream").Stream<string, never, MainContext>;
        current: Effect.Effect<{
            readonly state: {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, SewedError, MainContext>;
        terminate: Effect.Effect<void, SewedError, MainContext>;
        recover: Effect.Effect<void, SewedError, MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("./Decision.ts").Decidable<Event, Answer, Timing, import("./Decision.ts").Composition, "contents">, decider: import("./Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
    } | undefined;
    id: string;
    current: Effect.Effect<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, SewedError, MainContext>;
    show: Effect.Effect<void, SewedError, MainContext>;
    showInactive: Effect.Effect<void, SewedError, MainContext>;
    hide: Effect.Effect<void, SewedError, MainContext>;
    focus: Effect.Effect<void, SewedError, MainContext>;
    blur: Effect.Effect<void, SewedError, MainContext>;
    setBounds: (bounds: import("./WindowControls.ts").BoundsUpdate) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreen: (fullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSimpleFullScreen: (simpleFullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    minimize: Effect.Effect<void, SewedError, MainContext>;
    maximize: Effect.Effect<void, SewedError, MainContext>;
    restore: Effect.Effect<void, SewedError, MainContext>;
    close: Effect.Effect<void, SewedError, MainContext>;
    setTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    setAlwaysOnTop: (alwaysOnTop: boolean, level?: import("./WindowControls.ts").AlwaysOnTopLevel) => Effect.Effect<void, SewedError, MainContext>;
    setOpacity: (opacity: number) => Effect.Effect<void, SewedError, MainContext>;
    setResizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMovable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMaximizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setClosable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreenable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMenuBarVisibility: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setKiosk: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSkipTaskbar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentProtection: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    flash: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonVisibility: (visible: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setProgress: (progress: number, mode?: import("./WindowControls.ts").ProgressMode) => Effect.Effect<void, SewedError, MainContext>;
    setOverlayIcon: (icon: import("./Image.ts").Source | null, description: string) => Effect.Effect<void, SewedError, MainContext>;
    setIcon: (icon: import("./Image.ts").Source) => Effect.Effect<void, SewedError, MainContext>;
    setParent: (parent: Window.Parent | null) => Effect.Effect<void, SewedError, MainContext>;
    setEnabled: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setIgnoreMouseEvents: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setAutoHideMenuBar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentView: (view: import("./View.ts").Handle) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
    contentViewId: Effect.Effect<string | null, never, MainContext>;
    setVisibleOnAllWorkspaces: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimumSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setMaximumSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setAspectRatio: (ratio: number, extra?: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundColor: (color: string) => Effect.Effect<void, SewedError, MainContext>;
    setHasShadow: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentBounds: (bounds: import("./WindowControls.ts").Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setContentSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    moveAbove: (mediaSourceId: string) => Effect.Effect<void, SewedError, MainContext>;
    setAccessibleTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    setTitleBarOverlay: (overlay: import("./WindowControls.ts").TitleBarOverlay) => Effect.Effect<void, SewedError, MainContext>;
    setShape: (rectangles: ReadonlyArray<import("./WindowControls.ts").Bounds>) => Effect.Effect<void, SewedError, MainContext>;
    setMenu: (options: import("./Menu.ts").ApplicationOptions) => Effect.Effect<import("./internal/ApplicationMenu.ts").Handle, SewedError, MainContext | import("effect/Scope").Scope>;
    removeMenu: Effect.Effect<void, SewedError, MainContext>;
    events: import("effect/Stream").Stream<{
        readonly kind: "ready-to-show";
    } | {
        readonly kind: "persisted-state-restored";
    } | {
        readonly kind: "app-command";
        readonly command: string;
    } | {
        readonly kind: "moved" | "resized";
    } | {
        readonly kind: "will-move" | "will-resize";
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly edge?: string;
    } | {
        readonly kind: "swipe";
        readonly direction: string;
    } | {
        readonly kind: "rotate-gesture";
        readonly rotation: number;
    } | {
        readonly kind: "sheet-begin" | "sheet-end";
    } | {
        readonly kind: "new-window-for-tab";
    } | {
        readonly kind: "session-end";
        readonly reasons: readonly string[];
    } | {
        readonly kind: "system-context-menu";
        readonly x: number;
        readonly y: number;
    }, SewedError, MainContext>;
    center: Effect.Effect<void, SewedError, MainContext>;
    moveTop: Effect.Effect<void, SewedError, MainContext>;
    decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("./Decision.ts").Decidable<Event, Answer, Timing, import("./Decision.ts").Composition, "window">, decider: import("./Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
    state: import("effect/Stream").Stream<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, never, MainContext>;
    awaitClosed: Effect.Effect<void, never, MainContext>;
    attach: (view: import("./View.ts").Attachable, options: import("./View.ts").AttachOptions) => Effect.Effect<import("./View.ts").Attachment, SewedError, MainContext | import("effect/Scope").Scope>;
    mediaSourceId: Effect.Effect<string, SewedError, MainContext>;
    contentBounds: Effect.Effect<Electron.Rectangle, SewedError, MainContext>;
    sizeLimits: Effect.Effect<{
        readonly minimum: {
            readonly width: number;
            readonly height: number;
        };
        readonly maximum: {
            readonly width: number;
            readonly height: number;
        };
    }, SewedError, MainContext>;
    enabled: Effect.Effect<boolean, SewedError, MainContext>;
    backgroundColor: Effect.Effect<string, SewedError, MainContext>;
    visibleOnAllWorkspaces: Effect.Effect<boolean, SewedError, MainContext>;
    parentId: Effect.Effect<string | null, SewedError, MainContext>;
    childIds: Effect.Effect<string[], SewedError, MainContext>;
    shadow: Effect.Effect<boolean, SewedError, MainContext>;
    accessibleTitle: Effect.Effect<string, SewedError, MainContext>;
    normal: Effect.Effect<boolean, SewedError, MainContext>;
    menuBarAutoHide: Effect.Effect<boolean, SewedError, MainContext>;
    nativeHandle: Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
    touchBar: import("./internal/TouchBar.ts").Handle;
}, "closed" | "native" | "webContents">, SewedError, MainContext | import("effect/Scope").Scope>;
export type Handle = Effect.Success<ReturnType<typeof create>>;
export declare const make: (options?: Options) => Effect.Effect<Omit<{
    setFocusable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    focusable: Effect.Effect<boolean, SewedError, MainContext>;
    contentProtected: Effect.Effect<boolean, SewedError, MainContext>;
    setRepresentedFilename: (path: string) => Effect.Effect<void, SewedError, MainContext>;
    representedFilename: Effect.Effect<string, SewedError, MainContext>;
    setDocumentEdited: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    documentEdited: Effect.Effect<boolean, SewedError, MainContext>;
    setVibrancy: (vibrancy: import("./WindowControls.ts").Vibrancy) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonPosition: (position: import("./Screen.ts").Point | null) => Effect.Effect<void, SewedError, MainContext>;
    windowButtonPosition: Effect.Effect<{
        x: number;
        y: number;
    } | null, SewedError, MainContext>;
    setSheetOffset: (offset: {
        readonly y: number;
        readonly x?: number;
    }) => Effect.Effect<void, SewedError, MainContext>;
    previewFile: (path: string, displayName?: string) => Effect.Effect<void, SewedError, MainContext>;
    closeFilePreview: Effect.Effect<void, SewedError, MainContext>;
    setHiddenInMissionControl: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    hiddenInMissionControl: Effect.Effect<boolean, SewedError, MainContext>;
    setAutoHideCursor: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    invalidateShadow: Effect.Effect<void, SewedError, MainContext>;
    setExcludedFromShownWindowsMenu: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    excludedFromShownWindowsMenu: Effect.Effect<boolean, SewedError, MainContext>;
    tabs: {
        identifier: Effect.Effect<string | null, SewedError, MainContext>;
        selectNext: Effect.Effect<void, SewedError, MainContext>;
        selectPrevious: Effect.Effect<void, SewedError, MainContext>;
        showAll: Effect.Effect<void, SewedError, MainContext>;
        mergeAll: Effect.Effect<void, SewedError, MainContext>;
        moveToNewWindow: Effect.Effect<void, SewedError, MainContext>;
        toggleBar: Effect.Effect<void, SewedError, MainContext>;
        add: (window: {
            readonly id: string;
        }) => Effect.Effect<void, SewedError, MainContext>;
    };
    setAccentColor: (color: import("./WindowControls.ts").AccentColor) => Effect.Effect<void, SewedError, MainContext>;
    setAppDetails: (details: import("./WindowControls.ts").AppDetails) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundMaterial: (material: import("./WindowControls.ts").BackgroundMaterial) => Effect.Effect<void, SewedError, MainContext>;
    setThumbarButtons: (buttons: ReadonlyArray<import("./WindowControls.ts").ThumbarButton>) => Effect.Effect<void, SewedError, MainContext>;
    thumbarClicks: import("effect/Stream").Stream<string, SewedError, MainContext>;
    setThumbnailClip: (region: import("./WindowControls.ts").Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setThumbnailToolTip: (text: string) => Effect.Effect<void, SewedError, MainContext>;
    snapped: Effect.Effect<boolean, SewedError, MainContext>;
    tabletMode: Effect.Effect<boolean, SewedError, MainContext>;
    windowMessages: (message: number) => import("effect/Stream").Stream<import("./WindowControls.ts").WindowMessage, SewedError, MainContext>;
    native: NativeBaseWindow;
    closed: import("effect/Deferred").Deferred<void, never>;
    webContents: {
        frames: (options?: import("./WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("./WebContents.ts").Frame, SewedError, MainContext>;
        painting: Effect.Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, SewedError, MainContext>;
        setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setFrameRate: (rate: import("./WebContents.ts").FrameRate) => Effect.Effect<void, SewedError, MainContext>;
        invalidate: Effect.Effect<void, SewedError, MainContext>;
        frameTree: Effect.Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], SewedError, MainContext>;
        opener: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        focusedFrame: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        hostId: Effect.Effect<string | null, SewedError, MainContext>;
        devToolsContentsId: Effect.Effect<number | null, SewedError, MainContext>;
        collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        frame: (identity: import("./WebContents.ts").FrameAddress) => {
            info: Effect.Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly top: number | null;
                readonly detached: boolean;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            }, SewedError, MainContext>;
            reload: Effect.Effect<void, SewedError, MainContext>;
            collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        };
        zoomLevel: Effect.Effect<number, SewedError, MainContext>;
        setZoomLevel: (level: import("./WebContents.ts").ZoomLevel) => Effect.Effect<void, SewedError, MainContext>;
        zoomMode: Effect.Effect<"default" | "disabled" | "isolated" | "manual", SewedError, MainContext>;
        setZoomMode: (mode: import("./WebContents.ts").ZoomMode) => Effect.Effect<void, SewedError, MainContext>;
        rendererProcessId: Effect.Effect<number, SewedError, MainContext>;
        sharedWorkers: Effect.Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], SewedError, MainContext>;
        inspectSharedWorker: (id: string) => Effect.Effect<void, SewedError, MainContext>;
        devToolsTargetId: Effect.Effect<string, SewedError, MainContext>;
        addDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        removeDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        printers: Effect.Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], SewedError, MainContext>;
        webRtc: Effect.Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, SewedError, MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("./WebContents.ts").WebRtcIpHandlingPolicy) => Effect.Effect<void, SewedError, MainContext>;
        setWebRtcUdpPortRange: (range: import("./WebContents.ts").UdpPortRange) => Effect.Effect<void, SewedError, MainContext>;
        caretBrowsing: Effect.Effect<boolean, SewedError, MainContext>;
        setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, SewedError, MainContext>;
        activity: Effect.Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, SewedError, MainContext>;
        devTools: Effect.Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, SewedError, MainContext>;
        toggleDevTools: Effect.Effect<void, SewedError, MainContext>;
        setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
        inspectElement: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, MainContext>;
        enableDeviceEmulation: (parameters: import("./WebContents.ts").DeviceEmulation) => Effect.Effect<void, SewedError, MainContext>;
        disableDeviceEmulation: Effect.Effect<void, SewedError, MainContext>;
        edit: (command: import("./WebContents.ts").EditCommand) => Effect.Effect<void, SewedError, MainContext>;
        replace: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        adjustSelection: (adjustment: import("./WebContents.ts").SelectionAdjustment) => Effect.Effect<void, SewedError, MainContext>;
        copyVideoFrameAt: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        saveVideoFrameAs: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        copyImageAt: (point: import("./WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        setVisualZoomLimits: (limits: import("./WebContents.ts").VisualZoomLimits) => Effect.Effect<void, SewedError, MainContext>;
        setImageAnimationPolicy: (policy: import("./WebContents.ts").ImageAnimationPolicy) => Effect.Effect<void, SewedError, MainContext>;
        startDrag: (drag: import("./WebContents.ts").Drag) => Effect.Effect<void, SewedError, MainContext>;
        showDefinitionForSelection: Effect.Effect<void, SewedError, MainContext>;
        takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        blocked: import("effect/Stream").Stream<{
            readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
            readonly url: string;
        }, SewedError, MainContext>;
        webviews: import("effect/Stream").Stream<import("./internal/ContentsWebviews.ts").Handle, SewedError, MainContext>;
        load: <Keys extends string, const B extends readonly import("./Binding.ts").Bound<Keys>[]>(entry: import("./Renderer.ts").Entry<Keys> & import("./Binding.ts").Complete<Keys, B>, options: {
            readonly bindings: B;
        }) => Effect.Effect<undefined, SewedError, MainContext>;
        reload: Effect.Effect<void, SewedError, MainContext>;
        reloadIgnoringCache: Effect.Effect<void, SewedError, MainContext>;
        stopLoading: Effect.Effect<void, SewedError, MainContext>;
        downloads: import("effect/Stream").Stream<import("./Download.ts").Handle, SewedError, MainContext>;
        print: (options?: import("./WebContents.ts").PrintOptions) => Effect.Effect<void, SewedError, MainContext>;
        pdf: (options?: import("./WebContents.ts").PdfOptions) => Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
        capture: (options?: import("./WebContents.ts").CaptureOptions) => Effect.Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, SewedError, MainContext>;
        zoom: import("effect/Stream").Stream<{
            readonly factor: number;
        }, never, MainContext>;
        setZoom: (factor: number) => Effect.Effect<void, SewedError, MainContext>;
        audio: import("effect/Stream").Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, MainContext>;
        setAudioMuted: (muted: boolean) => Effect.Effect<void, SewedError, MainContext>;
        userAgent: Effect.Effect<string, SewedError, MainContext>;
        setUserAgent: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
        insertText: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        savePage: (path: string, type?: import("./WebContents.ts").SaveType) => Effect.Effect<void, SewedError, MainContext>;
        setBackgroundThrottling: (allowed: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
        find: (text: string, options?: import("./WebContents.ts").FindOptions) => Effect.Effect<import("./WebContents.ts").Search, SewedError, MainContext | import("effect/Scope").Scope>;
        findNext: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
        stopFind: (action?: import("./WebContents.ts").FindStop) => Effect.Effect<void, SewedError, MainContext>;
        style: (css: string, options?: import("./WebContents.ts").StyleOptions) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
        history: import("effect/Stream").Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, MainContext>;
        back: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        forward: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        go: (index: number) => Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        removeHistoryEntry: (index: number) => Effect.Effect<void, SewedError, MainContext>;
        clearHistory: Effect.Effect<void, SewedError, MainContext>;
        openDevTools: (options?: import("./WebContents.ts").DevToolsOptions) => Effect.Effect<void, SewedError, MainContext>;
        openDevToolsIn: (host: import("./WebContentsView.ts").Handle, options?: import("./WebContents.ts").DevToolsHostOptions) => Effect.Effect<void, SewedError, MainContext>;
        closeDevTools: Effect.Effect<void, SewedError, MainContext>;
        focus: Effect.Effect<void, SewedError, MainContext>;
        console: import("effect/Stream").Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, SewedError, MainContext>;
        state: import("effect/Stream").Stream<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, MainContext>;
        responsiveness: import("effect/Stream").Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, MainContext>;
        favicons: import("effect/Stream").Stream<readonly string[], never, MainContext>;
        title: import("effect/Stream").Stream<string, never, MainContext>;
        current: Effect.Effect<{
            readonly state: {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, SewedError, MainContext>;
        terminate: Effect.Effect<void, SewedError, MainContext>;
        recover: Effect.Effect<void, SewedError, MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("./Decision.ts").Decidable<Event, Answer, Timing, import("./Decision.ts").Composition, "contents">, decider: import("./Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
    } | undefined;
    id: string;
    current: Effect.Effect<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, SewedError, MainContext>;
    show: Effect.Effect<void, SewedError, MainContext>;
    showInactive: Effect.Effect<void, SewedError, MainContext>;
    hide: Effect.Effect<void, SewedError, MainContext>;
    focus: Effect.Effect<void, SewedError, MainContext>;
    blur: Effect.Effect<void, SewedError, MainContext>;
    setBounds: (bounds: import("./WindowControls.ts").BoundsUpdate) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreen: (fullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSimpleFullScreen: (simpleFullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    minimize: Effect.Effect<void, SewedError, MainContext>;
    maximize: Effect.Effect<void, SewedError, MainContext>;
    restore: Effect.Effect<void, SewedError, MainContext>;
    close: Effect.Effect<void, SewedError, MainContext>;
    setTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    setAlwaysOnTop: (alwaysOnTop: boolean, level?: import("./WindowControls.ts").AlwaysOnTopLevel) => Effect.Effect<void, SewedError, MainContext>;
    setOpacity: (opacity: number) => Effect.Effect<void, SewedError, MainContext>;
    setResizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMovable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMaximizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setClosable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreenable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMenuBarVisibility: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setKiosk: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSkipTaskbar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentProtection: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    flash: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonVisibility: (visible: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setProgress: (progress: number, mode?: import("./WindowControls.ts").ProgressMode) => Effect.Effect<void, SewedError, MainContext>;
    setOverlayIcon: (icon: import("./Image.ts").Source | null, description: string) => Effect.Effect<void, SewedError, MainContext>;
    setIcon: (icon: import("./Image.ts").Source) => Effect.Effect<void, SewedError, MainContext>;
    setParent: (parent: Window.Parent | null) => Effect.Effect<void, SewedError, MainContext>;
    setEnabled: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setIgnoreMouseEvents: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setAutoHideMenuBar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentView: (view: import("./View.ts").Handle) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
    contentViewId: Effect.Effect<string | null, never, MainContext>;
    setVisibleOnAllWorkspaces: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimumSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setMaximumSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setAspectRatio: (ratio: number, extra?: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundColor: (color: string) => Effect.Effect<void, SewedError, MainContext>;
    setHasShadow: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentBounds: (bounds: import("./WindowControls.ts").Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setContentSize: (size: import("./WindowControls.ts").Size) => Effect.Effect<void, SewedError, MainContext>;
    moveAbove: (mediaSourceId: string) => Effect.Effect<void, SewedError, MainContext>;
    setAccessibleTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    setTitleBarOverlay: (overlay: import("./WindowControls.ts").TitleBarOverlay) => Effect.Effect<void, SewedError, MainContext>;
    setShape: (rectangles: ReadonlyArray<import("./WindowControls.ts").Bounds>) => Effect.Effect<void, SewedError, MainContext>;
    setMenu: (options: import("./Menu.ts").ApplicationOptions) => Effect.Effect<import("./internal/ApplicationMenu.ts").Handle, SewedError, MainContext | import("effect/Scope").Scope>;
    removeMenu: Effect.Effect<void, SewedError, MainContext>;
    events: import("effect/Stream").Stream<{
        readonly kind: "ready-to-show";
    } | {
        readonly kind: "persisted-state-restored";
    } | {
        readonly kind: "app-command";
        readonly command: string;
    } | {
        readonly kind: "moved" | "resized";
    } | {
        readonly kind: "will-move" | "will-resize";
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly edge?: string;
    } | {
        readonly kind: "swipe";
        readonly direction: string;
    } | {
        readonly kind: "rotate-gesture";
        readonly rotation: number;
    } | {
        readonly kind: "sheet-begin" | "sheet-end";
    } | {
        readonly kind: "new-window-for-tab";
    } | {
        readonly kind: "session-end";
        readonly reasons: readonly string[];
    } | {
        readonly kind: "system-context-menu";
        readonly x: number;
        readonly y: number;
    }, SewedError, MainContext>;
    center: Effect.Effect<void, SewedError, MainContext>;
    moveTop: Effect.Effect<void, SewedError, MainContext>;
    decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("./Decision.ts").Decidable<Event, Answer, Timing, import("./Decision.ts").Composition, "window">, decider: import("./Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
    state: import("effect/Stream").Stream<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, never, MainContext>;
    awaitClosed: Effect.Effect<void, never, MainContext>;
    attach: (view: import("./View.ts").Attachable, options: import("./View.ts").AttachOptions) => Effect.Effect<import("./View.ts").Attachment, SewedError, MainContext | import("effect/Scope").Scope>;
    mediaSourceId: Effect.Effect<string, SewedError, MainContext>;
    contentBounds: Effect.Effect<Electron.Rectangle, SewedError, MainContext>;
    sizeLimits: Effect.Effect<{
        readonly minimum: {
            readonly width: number;
            readonly height: number;
        };
        readonly maximum: {
            readonly width: number;
            readonly height: number;
        };
    }, SewedError, MainContext>;
    enabled: Effect.Effect<boolean, SewedError, MainContext>;
    backgroundColor: Effect.Effect<string, SewedError, MainContext>;
    visibleOnAllWorkspaces: Effect.Effect<boolean, SewedError, MainContext>;
    parentId: Effect.Effect<string | null, SewedError, MainContext>;
    childIds: Effect.Effect<string[], SewedError, MainContext>;
    shadow: Effect.Effect<boolean, SewedError, MainContext>;
    accessibleTitle: Effect.Effect<string, SewedError, MainContext>;
    normal: Effect.Effect<boolean, SewedError, MainContext>;
    menuBarAutoHide: Effect.Effect<boolean, SewedError, MainContext>;
    nativeHandle: Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
    touchBar: import("./internal/TouchBar.ts").Handle;
}, "closed" | "native" | "webContents">, SewedError, MainContext | import("effect/Scope").Scope>;
/**
 * Forgets the bounds and display mode persisted for the window of this `name`, so its next
 * creation starts from its options. Works for a browser window's name too.
 */
export declare const clearPersistedState: (name: string) => Effect.Effect<void, SewedError, MainContext>;
export {};
//# sourceMappingURL=BaseWindow.d.ts.map