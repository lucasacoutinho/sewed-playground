import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export declare const SameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
export type SameSite = typeof SameSite.Type;
export declare const Cookie: Schema.Struct<{
    readonly name: Schema.String;
    readonly value: Schema.String;
    readonly domain: Schema.optionalKey<Schema.String>;
    readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    readonly session: Schema.optionalKey<Schema.Boolean>;
    readonly expirationDate: Schema.optionalKey<Schema.Finite>;
    readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
}>;
export type Cookie = typeof Cookie.Type;
export declare const Filter: Schema.Struct<{
    readonly url: Schema.optionalKey<Schema.String>;
    readonly name: Schema.optionalKey<Schema.String>;
    readonly domain: Schema.optionalKey<Schema.String>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly session: Schema.optionalKey<Schema.Boolean>;
    readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
}>;
export type Filter = typeof Filter.Type;
export declare const Details: Schema.Struct<{
    readonly url: Schema.String;
    readonly name: Schema.String;
    readonly value: Schema.String;
    readonly domain: Schema.optionalKey<Schema.String>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    readonly expirationDate: Schema.optionalKey<Schema.Finite>;
    readonly sameSite: Schema.optionalKey<Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>>;
}>;
export type Details = typeof Details.Type;
export declare const Cause: Schema.Literals<readonly ["inserted", "inserted-no-change-overwrite", "inserted-no-value-change-overwrite", "explicit", "overwrite", "expired", "evicted", "expired-overwrite"]>;
export type Cause = typeof Cause.Type;
export declare const Change: Schema.Struct<{
    readonly cookie: Schema.Struct<{
        readonly name: Schema.String;
        readonly value: Schema.String;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
        readonly session: Schema.optionalKey<Schema.Boolean>;
        readonly expirationDate: Schema.optionalKey<Schema.Finite>;
        readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
    }>;
    readonly cause: Schema.Literals<readonly ["inserted", "inserted-no-change-overwrite", "inserted-no-value-change-overwrite", "explicit", "overwrite", "expired", "evicted", "expired-overwrite"]>;
    readonly removed: Schema.Boolean;
}>;
export type Change = typeof Change.Type;
/** Origins this capability may read, write, and observe cookies for; nothing else is reachable. */
export declare const Policy: Schema.$Array<Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
}>>;
export type Policy = typeof Policy.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"changes", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly cookie: Schema.Struct<{
        readonly name: Schema.String;
        readonly value: Schema.String;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
        readonly session: Schema.optionalKey<Schema.Boolean>;
        readonly expirationDate: Schema.optionalKey<Schema.Finite>;
        readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
    }>;
    readonly cause: Schema.Literals<readonly ["inserted", "inserted-no-change-overwrite", "inserted-no-value-change-overwrite", "explicit", "overwrite", "expired", "evicted", "expired-overwrite"]>;
    readonly removed: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"flush", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"get", Schema.Struct<{
    filter: Schema.Struct<{
        readonly url: Schema.optionalKey<Schema.String>;
        readonly name: Schema.optionalKey<Schema.String>;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly session: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    }>;
}>, Schema.$Array<Schema.Struct<{
    readonly name: Schema.String;
    readonly value: Schema.String;
    readonly domain: Schema.optionalKey<Schema.String>;
    readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    readonly session: Schema.optionalKey<Schema.Boolean>;
    readonly expirationDate: Schema.optionalKey<Schema.Finite>;
    readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
}>>, typeof SewedError, never, never> | Rpc.Rpc<"remove", Schema.Struct<{
    url: Schema.String;
    name: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"set", Schema.Struct<{
    details: Schema.Struct<{
        readonly url: Schema.String;
        readonly name: Schema.String;
        readonly value: Schema.String;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
        readonly expirationDate: Schema.optionalKey<Schema.Finite>;
        readonly sameSite: Schema.optionalKey<Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>>;
    }>;
}>, Schema.Void, typeof SewedError, never, never>>;
/**
 * A session's cookies as one capability: `Cookies.native(session, policy)` in `sewed/main` carries
 * the origin policy for one acquired session, `Capability.client` reaches it from a document, and
 * `Testing.Cookies.memory` stands in for tests.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"changes", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly cookie: Schema.Struct<{
        readonly name: Schema.String;
        readonly value: Schema.String;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
        readonly session: Schema.optionalKey<Schema.Boolean>;
        readonly expirationDate: Schema.optionalKey<Schema.Finite>;
        readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
    }>;
    readonly cause: Schema.Literals<readonly ["inserted", "inserted-no-change-overwrite", "inserted-no-value-change-overwrite", "explicit", "overwrite", "expired", "evicted", "expired-overwrite"]>;
    readonly removed: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"flush", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"get", Schema.Struct<{
    filter: Schema.Struct<{
        readonly url: Schema.optionalKey<Schema.String>;
        readonly name: Schema.optionalKey<Schema.String>;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly session: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    }>;
}>, Schema.$Array<Schema.Struct<{
    readonly name: Schema.String;
    readonly value: Schema.String;
    readonly domain: Schema.optionalKey<Schema.String>;
    readonly hostOnly: Schema.optionalKey<Schema.Boolean>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
    readonly session: Schema.optionalKey<Schema.Boolean>;
    readonly expirationDate: Schema.optionalKey<Schema.Finite>;
    readonly sameSite: Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>;
}>>, typeof SewedError, never, never> | Rpc.Rpc<"remove", Schema.Struct<{
    url: Schema.String;
    name: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"set", Schema.Struct<{
    details: Schema.Struct<{
        readonly url: Schema.String;
        readonly name: Schema.String;
        readonly value: Schema.String;
        readonly domain: Schema.optionalKey<Schema.String>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly secure: Schema.optionalKey<Schema.Boolean>;
        readonly httpOnly: Schema.optionalKey<Schema.Boolean>;
        readonly expirationDate: Schema.optionalKey<Schema.Finite>;
        readonly sameSite: Schema.optionalKey<Schema.Literals<readonly ["unspecified", "no_restriction", "lax", "strict"]>>;
    }>;
}>, Schema.Void, typeof SewedError, never, never>, "sewed/binding/cookies">;
//# sourceMappingURL=Cookie.d.ts.map