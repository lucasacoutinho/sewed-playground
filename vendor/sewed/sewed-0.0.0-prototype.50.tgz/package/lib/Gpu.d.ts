import type * as Application from "./Application.ts";
import type * as Declaration from "./Declaration.ts";
export type Options = Application.Gpu;
/** Declares GPU settings that must precede readiness; `acceleration: false` disables the GPU. */
export declare const declare: (options: Options) => Declaration.Declaration;
//# sourceMappingURL=Gpu.d.ts.map