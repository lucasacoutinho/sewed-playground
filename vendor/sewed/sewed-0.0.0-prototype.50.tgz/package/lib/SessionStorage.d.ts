import { Schema } from "effect";
export declare const OriginStorage: Schema.Literals<readonly ["localstorage", "indexdb", "serviceworkers", "cachestorage"]>;
export declare const Storage: Schema.Literals<readonly ["cookies", "filesystem", "indexdb", "localstorage", "shadercache", "serviceworkers", "cachestorage"]>;
export declare const ClearOptions: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"session">;
    readonly storages: Schema.NonEmptyArray<Schema.Literals<readonly ["cookies", "filesystem", "indexdb", "localstorage", "shadercache", "serviceworkers", "cachestorage"]>>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
    readonly storages: Schema.NonEmptyArray<Schema.Literals<readonly ["localstorage", "indexdb", "serviceworkers", "cachestorage"]>>;
}>]>;
export type ClearOptions = typeof ClearOptions.Type;
export declare const DataType: Schema.Literals<readonly ["backgroundFetch", "cache", "cookies", "downloads", "fileSystems", "indexedDB", "localStorage", "serviceWorkers", "webSQL"]>;
export type DataType = typeof DataType.Type;
/**
 * What `Session.clearData` clears. Every data type and every origin unless narrowed; `origins`
 * and `excludeOrigins` are alternatives. `originMatchingMode` says whether an origin's data is
 * cleared only where it is the top-level site or wherever it appears.
 */
export declare const ClearData: Schema.Struct<{
    readonly dataTypes: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["backgroundFetch", "cache", "cookies", "downloads", "fileSystems", "indexedDB", "localStorage", "serviceWorkers", "webSQL"]>>>;
    readonly origins: Schema.optionalKey<Schema.NonEmptyArray<Schema.String>>;
    readonly excludeOrigins: Schema.optionalKey<Schema.NonEmptyArray<Schema.String>>;
    readonly avoidClosingConnections: Schema.optionalKey<Schema.Boolean>;
    readonly originMatchingMode: Schema.optionalKey<Schema.Literals<readonly ["third-parties-included", "origin-in-all-contexts"]>>;
}>;
export type ClearData = typeof ClearData.Type;
/** The isolation key a shared dictionary is stored under. */
export declare const SharedDictionaryKey: Schema.Struct<{
    readonly frameOrigin: Schema.String;
    readonly topFrameSite: Schema.String;
}>;
export type SharedDictionaryKey = typeof SharedDictionaryKey.Type;
export declare const SharedDictionaryUsage: Schema.Struct<{
    readonly frameOrigin: Schema.String;
    readonly topFrameSite: Schema.String;
    readonly totalSizeBytes: Schema.Finite;
}>;
export type SharedDictionaryUsage = typeof SharedDictionaryUsage.Type;
/** One stored compression dictionary; times are milliseconds since the epoch. */
export declare const SharedDictionary: Schema.Struct<{
    readonly id: Schema.String;
    readonly dictionaryUrl: Schema.String;
    readonly match: Schema.String;
    readonly matchDestinations: Schema.$Array<Schema.String>;
    readonly hash: Schema.String;
    readonly size: Schema.Finite;
    readonly expirationDuration: Schema.Finite;
    readonly responseTime: Schema.Finite;
    readonly lastFetchTime: Schema.Finite;
    readonly lastUsedTime: Schema.Finite;
}>;
export type SharedDictionary = typeof SharedDictionary.Type;
/** A spell checker dictionary file being fetched or becoming usable, by language code. */
export declare const DictionaryEvent: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["initialized", "download-begin", "download-success", "download-failure"]>;
    readonly language: Schema.String;
}>;
export type DictionaryEvent = typeof DictionaryEvent.Type;
/** A page asking for a file or directory Chromium treats as sensitive. */
export declare const FileSystemAccess: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly path: Schema.String;
    readonly isDirectory: Schema.Boolean;
}>;
export type FileSystemAccess = typeof FileSystemAccess.Type;
/**
 * A script the session runs before a frame's or a service worker's own scripts, in every web
 * contents that uses the session. `filePath` must be absolute.
 */
export declare const PreloadScript: Schema.Struct<{
    readonly type: Schema.Literals<readonly ["frame", "service-worker"]>;
    readonly filePath: Schema.String;
    readonly id: Schema.optionalKey<Schema.String>;
}>;
export type PreloadScript = typeof PreloadScript.Type;
export declare const RegisteredPreloadScript: Schema.Struct<{
    readonly type: Schema.Literals<readonly ["frame", "service-worker"]>;
    readonly filePath: Schema.String;
    readonly id: Schema.String;
}>;
export type RegisteredPreloadScript = typeof RegisteredPreloadScript.Type;
//# sourceMappingURL=SessionStorage.d.ts.map