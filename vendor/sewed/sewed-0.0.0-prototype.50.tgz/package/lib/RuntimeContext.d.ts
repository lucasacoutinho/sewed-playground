import { Context } from "effect";
import type { Connection } from "./internal/Transport.ts";
import type { Effect, Scope } from "effect";
import type { SewedError } from "./SewedError.ts";
declare const runtimeIdentity: unique symbol;
type Identity = {
    readonly [runtimeIdentity]: true;
};
declare const MainContext_base: Context.ServiceClass<MainContext, "sewed/Main", Identity>;
export declare class MainContext extends MainContext_base {
}
declare const RendererContext_base: Context.ServiceClass<RendererContext, "sewed/Renderer", Identity>;
export declare class RendererContext extends RendererContext_base {
}
declare const WorkerContext_base: Context.ServiceClass<WorkerContext, "sewed/Worker", Identity & {
    readonly threadId: number;
}>;
export declare class WorkerContext extends WorkerContext_base {
}
declare const UtilityContext_base: Context.ServiceClass<UtilityContext, "sewed/Utility", Identity & {
    readonly processId: number;
}>;
export declare class UtilityContext extends UtilityContext_base {
}
declare const ClientContext_base: Context.ServiceClass<ClientContext, "sewed/Client", {
    readonly identity: object;
    readonly bindings: Context.Context<never>;
    readonly owners: ReadonlyMap<string, string>;
    readonly isClosed: () => boolean;
}>;
export declare class ClientContext extends ClientContext_base {
}
export interface ConnectionFactory {
    readonly connect: Effect.Effect<Connection, SewedError, Scope.Scope>;
}
export declare const mainIdentity: MainContext["Service"];
export declare const rendererIdentity: RendererContext["Service"];
export declare const workerIdentity: (threadId: number) => WorkerContext["Service"];
export declare const utilityIdentity: (processId: number) => UtilityContext["Service"];
export {};
//# sourceMappingURL=RuntimeContext.d.ts.map