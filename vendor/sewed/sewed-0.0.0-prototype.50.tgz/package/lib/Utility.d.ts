import { Effect, Scope } from "effect";
import type { Rpc, RpcGroup } from "effect/rpc";
import { type Bound, type Declaration } from "./Binding.ts";
import { ClientContext, UtilityContext } from "./RuntimeContext.ts";
import { type HandlerLayer } from "./internal/HandlerLayer.ts";
declare const definitionType: unique symbol;
export interface Definition<Rpcs extends Rpc.Any, Keys extends string = never> {
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    readonly [definitionType]: {
        readonly rpcs: (rpc: Rpcs) => Rpcs;
        readonly keys: Keys;
    };
}
/** See `Worker.Entry`: `string` leaves spawn bindings unchecked, a narrower type checks them. */
export interface Entry<Rpcs extends Rpc.Any, Keys extends string = string> {
    readonly url: URL;
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    readonly bindings: readonly Declaration<Keys>[];
}
export type DefinitionRpcs<D> = D extends Definition<infer Rpcs, infer _Keys> ? Rpcs : never;
export type DefinitionKeys<D> = D extends Definition<infer _Rpcs, infer Keys> ? Keys : never;
export declare function define<Rpcs extends Rpc.Any, E>(protocol: RpcGroup.RpcGroup<Rpcs>, handlers: HandlerLayer<Rpcs, E, UtilityContext>): Definition<Rpcs, never>;
export declare function define<Rpcs extends Rpc.Any, E, Keys extends string>(protocol: RpcGroup.RpcGroup<Rpcs>, handlers: HandlerLayer<Rpcs, E, UtilityContext | ClientContext>, options: {
    readonly bindings: readonly Declaration<Keys>[];
}): Definition<Rpcs, Keys>;
export declare function entry<Rpcs extends Rpc.Any>(url: URL, protocol: RpcGroup.RpcGroup<Rpcs>): Entry<Rpcs, string>;
export declare function entry<Rpcs extends Rpc.Any, Keys extends string>(url: URL, protocol: RpcGroup.RpcGroup<Rpcs>, options: {
    readonly bindings: readonly Declaration<Keys>[];
}): Entry<Rpcs, Keys>;
/** Types the entry from the utility module without importing it into main. */
export declare function entry<Module extends {
    readonly default: unknown;
}>(url: URL, protocol: RpcGroup.RpcGroup<DefinitionRpcs<Module["default"]>>): Entry<DefinitionRpcs<Module["default"]>, DefinitionKeys<Module["default"]>>;
export declare const start: (definition: unknown, bindings: readonly Bound[]) => Effect.Effect<{
    accept(connection: import("./internal/Transport.ts").Connection): void;
}, unknown, Scope.Scope | UtilityContext>;
export declare const processId: Effect.Effect<number, never, UtilityContext>;
export {};
//# sourceMappingURL=Utility.d.ts.map