import { Schema } from "effect";
export declare const MessageOptions: Schema.Struct<{
    readonly message: Schema.String;
    readonly buttons: Schema.NonEmptyArray<Schema.String>;
    readonly type: Schema.optionalKey<Schema.Literals<readonly ["none", "info", "error", "question", "warning"]>>;
    readonly title: Schema.optionalKey<Schema.String>;
    readonly detail: Schema.optionalKey<Schema.String>;
    readonly defaultId: Schema.optionalKey<Schema.Finite>;
    readonly cancelId: Schema.optionalKey<Schema.Finite>;
    readonly checkbox: Schema.optionalKey<Schema.Struct<{
        readonly label: Schema.String;
        readonly checked: Schema.optionalKey<Schema.Boolean>;
    }>>;
    readonly noLink: Schema.optionalKey<Schema.Boolean>;
    readonly normalizeAccessKeys: Schema.optionalKey<Schema.Boolean>;
}>;
export type MessageOptions = typeof MessageOptions.Type;
export declare const MessageResult: Schema.Struct<{
    readonly response: Schema.Finite;
    readonly checkboxChecked: Schema.Boolean;
}>;
export type MessageResult = typeof MessageResult.Type;
export declare const FileFilter: Schema.Struct<{
    readonly name: Schema.String;
    readonly extensions: Schema.NonEmptyArray<Schema.String>;
}>;
export type FileFilter = typeof FileFilter.Type;
/**
 * Electron's own save dialog flags, minus `showOverwriteConfirmation`'s implicit default (see
 * `SaveOptions.properties`) and every flag that names a mode or multiplicity `SaveOptions` already
 * models structurally.
 */
export declare const SaveProperty: Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "treatPackageAsDirectory", "showOverwriteConfirmation", "dontAddToRecent"]>;
export type SaveProperty = typeof SaveProperty.Type;
/**
 * Electron's own open dialog flags, minus `openFile`/`openDirectory`/`multiSelections` — `mode`
 * and `multiple` already model those, and a caller repeating them here could contradict the
 * selection mode `OpenOptions`'s own shape enforces.
 */
export declare const OpenProperty: Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "promptToCreate", "noResolveAliases", "treatPackageAsDirectory", "dontAddToRecent"]>;
export type OpenProperty = typeof OpenProperty.Type;
export declare const OpenOptions: Schema.Union<readonly [Schema.Struct<{
    readonly title: Schema.optionalKey<Schema.String>;
    readonly defaultPath: Schema.optionalKey<Schema.String>;
    readonly buttonLabel: Schema.optionalKey<Schema.String>;
    readonly multiple: Schema.optionalKey<Schema.Boolean>;
    readonly mode: Schema.Literal<"file">;
    readonly filters: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
        readonly name: Schema.String;
        readonly extensions: Schema.NonEmptyArray<Schema.String>;
    }>>>;
    readonly properties: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "promptToCreate", "noResolveAliases", "treatPackageAsDirectory", "dontAddToRecent"]>>>;
}>, Schema.Struct<{
    readonly title: Schema.optionalKey<Schema.String>;
    readonly defaultPath: Schema.optionalKey<Schema.String>;
    readonly buttonLabel: Schema.optionalKey<Schema.String>;
    readonly multiple: Schema.optionalKey<Schema.Boolean>;
    readonly mode: Schema.Literal<"directory">;
    readonly properties: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "promptToCreate", "noResolveAliases", "treatPackageAsDirectory", "dontAddToRecent"]>>>;
}>]>;
export type OpenOptions = typeof OpenOptions.Type;
/**
 * `properties` forwards verbatim to Electron; absent, the dialog capability's own `save` keeps
 * requesting overwrite confirmation, its long-standing default — `internal/Dialog.ts`, not this
 * schema, supplies that default, so a caller reading `SaveOptions.properties` back off a value
 * this schema decoded sees exactly what it wrote, `undefined` included.
 */
export declare const SaveOptions: Schema.Struct<{
    readonly title: Schema.optionalKey<Schema.String>;
    readonly defaultPath: Schema.optionalKey<Schema.String>;
    readonly buttonLabel: Schema.optionalKey<Schema.String>;
    readonly filters: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
        readonly name: Schema.String;
        readonly extensions: Schema.NonEmptyArray<Schema.String>;
    }>>>;
    readonly properties: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "treatPackageAsDirectory", "showOverwriteConfirmation", "dontAddToRecent"]>>>;
}>;
export type SaveOptions = typeof SaveOptions.Type;
export declare const OpenResult: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"canceled">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"selected">;
    readonly paths: Schema.NonEmptyArray<Schema.String>;
}>]>;
export type OpenResult = typeof OpenResult.Type;
export declare const SaveResult: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"canceled">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"selected">;
    readonly path: Schema.String;
}>]>;
export type SaveResult = typeof SaveResult.Type;
//# sourceMappingURL=Dialog.d.ts.map