import { Schema } from "effect";
export declare const Appearance: Schema.Literals<readonly ["dark", "light", "unknown"]>;
export type Appearance = typeof Appearance.Type;
export declare const MediaKind: Schema.Literals<readonly ["microphone", "camera", "screen"]>;
export type MediaKind = typeof MediaKind.Type;
export declare const MediaAccess: Schema.Literals<readonly ["not-determined", "granted", "denied", "restricted", "unknown"]>;
export type MediaAccess = typeof MediaAccess.Type;
export declare const Animation: Schema.Struct<{
    readonly shouldRenderRichAnimation: Schema.Boolean;
    readonly scrollAnimationsEnabledBySystem: Schema.Boolean;
    readonly prefersReducedMotion: Schema.Boolean;
}>;
export type Animation = typeof Animation.Type;
/** A Windows or macOS system color name; Electron validates the name itself. */
export declare const ColorName: Schema.String;
export declare const SystemColor: Schema.Literals<readonly ["blue", "brown", "gray", "green", "orange", "pink", "purple", "red", "yellow"]>;
export type SystemColor = typeof SystemColor.Type;
export declare const Change: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"accent-color">;
    readonly color: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"color">;
}>]>;
export type Change = typeof Change.Type;
/** Which macOS notification center: between applications, inside this one, or the workspace's. */
export declare const NotificationCenter: Schema.Literals<readonly ["distributed", "local", "workspace"]>;
export type NotificationCenter = typeof NotificationCenter.Type;
/** A macOS notification center message; `userInfo` is `null` when it is not JSON. */
export declare const CenterNotification: Schema.Struct<{
    readonly event: Schema.String;
    readonly userInfo: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly object: Schema.String;
}>;
export type CenterNotification = typeof CenterNotification.Type;
/** Values registered as defaults in the macOS user defaults. */
export declare const Defaults: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Boolean, Schema.Finite]>>;
export type Defaults = typeof Defaults.Type;
/** How a macOS user default is stored; the same value reads differently under another type. */
export declare const UserDefaultType: Schema.Literals<readonly ["string", "boolean", "integer", "float", "double", "url", "array", "dictionary"]>;
export type UserDefaultType = typeof UserDefaultType.Type;
/** One macOS user default, with the type it is stored as. */
export declare const UserDefault: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literals<readonly ["string", "url"]>;
    readonly value: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"boolean">;
    readonly value: Schema.Boolean;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"integer">;
    readonly value: Schema.Int;
}>, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["float", "double"]>;
    readonly value: Schema.Finite;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"array">;
    readonly value: Schema.$Array<Schema.Unknown>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"dictionary">;
    readonly value: Schema.$Record<Schema.String, Schema.Unknown>;
}>]>;
export type UserDefault = typeof UserDefault.Type;
//# sourceMappingURL=SystemPreferences.d.ts.map