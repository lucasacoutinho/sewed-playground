import { Rpc, RpcGroup, RpcMiddleware, RpcSchema } from "effect/rpc";
import { Effect, Layer, Schema, Scope } from "effect";
import { type Client as BindingClient, type Slot } from "./Binding.ts";
import type { HandlerServices } from "./Runtime.ts";
import type { ClientContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
declare const acquireTag: "__sewed_remote_acquire";
declare const releaseTag: "__sewed_remote_release";
declare const leaseToken: Schema.String;
declare const LeaseGuard_base: RpcMiddleware.ServiceClass<LeaseGuard, "sewed/remote/LeaseGuard", never, typeof SewedError, never, never, false>;
declare class LeaseGuard extends LeaseGuard_base {
}
type AcquireError<Failure extends Schema.Top> = Schema.Union<readonly [Failure, typeof SewedError]>;
type AcquireRpc<Payload extends Schema.Top, Failure extends Schema.Top> = Rpc.Rpc<typeof acquireTag, Payload extends Schema.Struct.Fields ? Schema.Struct<Payload> : Payload, RpcSchema.Stream<typeof leaseToken, AcquireError<Failure>>, typeof Schema.Never>;
type ReleaseRpc = Rpc.Rpc<typeof releaseTag, typeof Schema.Void, typeof Schema.Void, typeof SewedError>;
type WireRpcs<Rpcs extends Rpc.Any, Payload extends Schema.Top, Failure extends Schema.Top> = Rpc.AddMiddleware<Rpcs, typeof LeaseGuard> | AcquireRpc<Payload, Failure> | ReleaseRpc;
declare const definitionType: unique symbol;
export interface Definition<Payload extends Schema.Top, Rpcs extends Rpc.Any, Failure extends Schema.Top, Wire extends Rpc.Any = WireRpcs<Rpcs, Payload, Failure>> {
    readonly payload: Payload;
    readonly protocol: RpcGroup.RpcGroup<Wire>;
    readonly methods: RpcGroup.RpcGroup<Rpcs>;
    readonly error: Failure;
    readonly [definitionType]: {
        readonly payload: Payload;
        readonly rpcs: Rpcs;
        readonly failure: Failure;
        readonly wire: Wire;
    };
}
export declare const make: <Payload extends Schema.Top, Rpcs extends Rpc.Any, Failure extends Schema.Top = Schema.Never>(options: {
    readonly payload: Payload;
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    readonly error?: Failure | undefined;
}) => Definition<Payload, Rpcs, Failure, WireRpcs<Rpcs, Payload, Failure>>;
type RemoteError<Failure extends Schema.Top> = Failure["Type"] | SewedError;
export interface Handle<Rpcs extends Rpc.Any, Failure extends Schema.Top> {
    readonly client: BindingClient<Rpcs>;
    readonly release: Effect.Effect<void, RemoteError<Failure>, ClientContext | Rpc.MiddlewareClient<Rpcs>>;
}
export declare const layer: <Payload extends Schema.Top, Rpcs extends Rpc.Any, Failure extends Schema.Top, Wire extends Rpc.Any, R>(definition: Definition<Payload, Rpcs, Failure, Wire>, build: (payload: Payload["Type"]) => Layer.Layer<NoInfer<Rpc.ToHandler<Rpcs> | Rpc.Middleware<Rpcs>>, Failure["Type"] | SewedError, R>) => Layer.Layer<HandlerServices<Wire>, Failure["Type"] | SewedError, R | Rpc.ServicesServer<Wire>>;
export declare const acquire: <Payload extends Schema.Top, Rpcs extends Rpc.Any, Failure extends Schema.Top, Wire extends Rpc.Any>(definition: Definition<Payload, Rpcs, Failure, Wire>, slot: Slot<NoInfer<Wire>>, payload: Payload["~type.make.in"]) => Effect.Effect<Handle<Rpcs, Failure>, RemoteError<Failure>, import("./RuntimeContext.ts").ClientContext | Scope.Scope | Rpc.MiddlewareClient<Wire> | Payload["EncodingServices"] | Failure["DecodingServices"]>;
export {};
//# sourceMappingURL=Remote.d.ts.map