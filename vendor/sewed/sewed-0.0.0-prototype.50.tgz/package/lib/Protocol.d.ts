import { Schema } from "effect";
import type { Effect, Scope } from "effect";
import type { HttpServerRequest, HttpServerResponse } from "effect/http";
export declare const Privileges: Schema.Struct<{
    readonly standard: Schema.optionalKey<Schema.Boolean>;
    readonly secure: Schema.optionalKey<Schema.Boolean>;
    readonly supportFetchAPI: Schema.optionalKey<Schema.Boolean>;
    readonly corsEnabled: Schema.optionalKey<Schema.Boolean>;
    readonly stream: Schema.optionalKey<Schema.Boolean>;
    readonly serviceWorkers: Schema.optionalKey<Schema.Boolean>;
    readonly codeCache: Schema.optionalKey<Schema.Boolean>;
}>;
export type Privileges = typeof Privileges.Type;
declare const schemeIdentity: unique symbol;
export interface Scheme {
    readonly [schemeIdentity]: true;
}
export interface SchemeDefinition {
    readonly name: string;
    readonly privileges: Privileges;
}
/** Creates an inert protocol definition. Native registration happens in `App.run`. */
export declare const scheme: (name: string, privileges?: Privileges) => Scheme;
export declare const definition: (value: Scheme) => SchemeDefinition | undefined;
export type Handler<E = never, R = never> = (request: HttpServerRequest.HttpServerRequest) => Effect.Effect<HttpServerResponse.HttpServerResponse, E, R | Scope.Scope>;
export type Request = HttpServerRequest.HttpServerRequest;
export type Response = HttpServerResponse.HttpServerResponse;
/**
 * The web's own request/response shape `handleWeb` takes: no `HttpServerRequest`/
 * `HttpServerResponse` wrapping, `signal` aborts the same way a registration's teardown or the
 * native request's own cancellation would tell any other cancellable call, and a thrown or
 * rejected answer fails the request the way a `Handler`'s own failure does.
 */
export type WebHandler = (request: globalThis.Request) => globalThis.Response | Promise<globalThis.Response>;
export {};
//# sourceMappingURL=Protocol.d.ts.map