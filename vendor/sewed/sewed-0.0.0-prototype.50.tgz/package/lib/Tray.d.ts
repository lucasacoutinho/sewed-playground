import { Schema } from "effect";
import * as Menu from "./Menu.ts";
type MenuOptionsValue = Omit<Menu.PopupOptions, "position">;
export declare const MenuOptions: Schema.Codec<MenuOptionsValue>;
export type MenuOptions = MenuOptionsValue;
export declare const Options: Schema.Struct<{
    /** A path or already-encoded bytes, over wave 3's `Image.Source`. */
    readonly icon: Schema.Union<readonly [Schema.String, import("./Binary.ts").Bytes]>;
    /**
     * Calls the native image's own `setTemplateImage(true)` — macOS semantics (a monochrome image
     * the system tints for light and dark menu bars) and a probed no-op elsewhere: `isTemplateImage`
     * stays `false` on Linux.
     */
    readonly template: Schema.optionalKey<Schema.Boolean>;
    readonly tooltip: Schema.optionalKey<Schema.String>;
    readonly menu: Schema.optionalKey<Schema.Codec<MenuOptionsValue, MenuOptionsValue, never, never>>;
}>;
export type Options = typeof Options.Type;
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"click">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"right-click">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"double-click">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"menu-selection">;
    readonly selection: Schema.Union<readonly [Schema.Struct<{
        readonly kind: Schema.Literal<"command">;
        readonly id: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"checkbox">;
        readonly id: Schema.String;
        readonly checked: Schema.Boolean;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"radio">;
        readonly id: Schema.String;
    }>]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"middle-click">;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["mouse-enter", "mouse-leave", "mouse-move", "mouse-down", "mouse-up"]>;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["balloon-show", "balloon-click", "balloon-closed"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["drag-enter", "drag-leave", "drag-end", "drop"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"drop-files">;
    readonly files: Schema.$Array<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"drop-text">;
    readonly text: Schema.String;
}>]>;
export type Event = typeof Event.Type;
/** A Windows notification balloon attached to the tray icon. */
export declare const Balloon: Schema.Struct<{
    readonly title: Schema.String;
    readonly content: Schema.String;
    readonly icon: Schema.optionalKey<Schema.Union<readonly [Schema.String, import("./Binary.ts").Bytes]>>;
    readonly iconType: Schema.optionalKey<Schema.Literals<readonly ["none", "info", "warning", "error", "custom"]>>;
    readonly largeIcon: Schema.optionalKey<Schema.Boolean>;
    readonly noSound: Schema.optionalKey<Schema.Boolean>;
    readonly respectQuietTime: Schema.optionalKey<Schema.Boolean>;
}>;
export type Balloon = typeof Balloon.Type;
export {};
//# sourceMappingURL=Tray.d.ts.map