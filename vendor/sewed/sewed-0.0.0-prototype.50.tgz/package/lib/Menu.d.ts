import { Schema } from "effect";
declare const SubmenuFields: {
    kind: Schema.Literal<"submenu">;
    label: Schema.String;
    enabled: Schema.optionalKey<Schema.Boolean>;
};
interface Submenu extends Schema.Struct.Type<typeof SubmenuFields> {
    readonly items: readonly [Item, ...Item[]];
}
declare const Submenu: Schema.Codec<Submenu>;
export declare const Item: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"command">;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"checkbox">;
    readonly checked: Schema.Boolean;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"radio">;
    readonly checked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"separator">;
}>, Schema.Codec<Submenu, Submenu, never, never>]>;
export type Item = typeof Item.Type;
export declare const RoleName: Schema.Literals<readonly ["appMenu", "fileMenu", "editMenu", "viewMenu", "windowMenu", "undo", "redo", "cut", "copy", "paste", "pasteAndMatchStyle", "delete", "selectAll", "reload", "forceReload", "toggleDevTools", "resetZoom", "zoomIn", "zoomOut", "togglefullscreen", "minimize", "close", "about", "quit", "services", "hide", "hideOthers", "unhide", "front", "zoom", "help", "window", "recentDocuments", "clearRecentDocuments", "toggleTabBar", "selectNextTab", "selectPreviousTab", "showAllTabs", "mergeAllWindows", "moveTabToNewWindow", "toggleSpellChecker", "showSubstitutions", "toggleSmartQuotes", "toggleSmartDashes", "toggleTextReplacement", "startSpeaking", "stopSpeaking"]>;
export type RoleName = typeof RoleName.Type;
export declare const Role: Schema.Struct<{
    readonly kind: Schema.Literal<"role">;
    readonly role: Schema.Literals<readonly ["appMenu", "fileMenu", "editMenu", "viewMenu", "windowMenu", "undo", "redo", "cut", "copy", "paste", "pasteAndMatchStyle", "delete", "selectAll", "reload", "forceReload", "toggleDevTools", "resetZoom", "zoomIn", "zoomOut", "togglefullscreen", "minimize", "close", "about", "quit", "services", "hide", "hideOthers", "unhide", "front", "zoom", "help", "window", "recentDocuments", "clearRecentDocuments", "toggleTabBar", "selectNextTab", "selectPreviousTab", "showAllTabs", "mergeAllWindows", "moveTabToNewWindow", "toggleSpellChecker", "showSubstitutions", "toggleSmartQuotes", "toggleSmartDashes", "toggleTextReplacement", "startSpeaking", "stopSpeaking"]>;
}>;
export type Role = typeof Role.Type;
declare const OpenSubmenuRoles: readonly ["help", "window"];
declare const FilledSubmenuRoles: readonly ["services", "recentDocuments"];
declare const RoledSubmenuFields: {
    kind: Schema.Literal<"submenu">;
    label: Schema.optionalKey<Schema.String>;
    enabled: Schema.optionalKey<Schema.Boolean>;
};
interface RoledOpenSubmenu extends Schema.Struct.Type<typeof RoledSubmenuFields> {
    readonly role: (typeof OpenSubmenuRoles)[number];
    readonly items: readonly [ApplicationItem, ...ApplicationItem[]];
}
interface LabeledOpenSubmenu extends Schema.Struct.Type<typeof SubmenuFields> {
    readonly items: readonly [ApplicationItem, ...ApplicationItem[]];
}
type OpenApplicationSubmenu = RoledOpenSubmenu | LabeledOpenSubmenu;
interface FilledApplicationSubmenu extends Schema.Struct.Type<typeof RoledSubmenuFields> {
    readonly role: (typeof FilledSubmenuRoles)[number];
    readonly items: readonly ApplicationItem[];
}
type ApplicationSubmenu = OpenApplicationSubmenu | FilledApplicationSubmenu;
declare const RoledOpenSubmenu: Schema.Codec<RoledOpenSubmenu>;
declare const LabeledOpenSubmenu: Schema.Codec<LabeledOpenSubmenu>;
declare const OpenApplicationSubmenu: Schema.Codec<OpenApplicationSubmenu>;
declare const FilledApplicationSubmenu: Schema.Codec<FilledApplicationSubmenu>;
declare const ApplicationSubmenu: Schema.Codec<ApplicationSubmenu>;
export declare const ApplicationItem: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"command">;
    readonly accelerator: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"checkbox">;
    readonly checked: Schema.Boolean;
    readonly accelerator: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly enabled: Schema.optionalKey<Schema.Boolean>;
    readonly sublabel: Schema.optionalKey<Schema.String>;
    readonly toolTip: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literal<"radio">;
    readonly checked: Schema.Boolean;
    readonly accelerator: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"separator">;
}>, Schema.Codec<ApplicationSubmenu, ApplicationSubmenu, never, never>, Schema.Struct<{
    readonly kind: Schema.Literal<"role">;
    readonly role: Schema.Literals<readonly ["appMenu", "fileMenu", "editMenu", "viewMenu", "windowMenu", "undo", "redo", "cut", "copy", "paste", "pasteAndMatchStyle", "delete", "selectAll", "reload", "forceReload", "toggleDevTools", "resetZoom", "zoomIn", "zoomOut", "togglefullscreen", "minimize", "close", "about", "quit", "services", "hide", "hideOthers", "unhide", "front", "zoom", "help", "window", "recentDocuments", "clearRecentDocuments", "toggleTabBar", "selectNextTab", "selectPreviousTab", "showAllTabs", "mergeAllWindows", "moveTabToNewWindow", "toggleSpellChecker", "showSubstitutions", "toggleSmartQuotes", "toggleSmartDashes", "toggleTextReplacement", "startSpeaking", "stopSpeaking"]>;
}>]>;
export type ApplicationItem = typeof ApplicationItem.Type;
export declare const ApplicationOptions: Schema.Struct<{
    readonly items: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Codec<ApplicationSubmenu, ApplicationSubmenu, never, never>, Schema.Struct<{
        readonly kind: Schema.Literal<"role">;
        readonly role: Schema.Literals<readonly ["appMenu", "fileMenu", "editMenu", "viewMenu", "windowMenu"]>;
    }>]>>;
}>;
export type ApplicationOptions = typeof ApplicationOptions.Type;
export declare const PopupOptions: Schema.Struct<{
    readonly items: Schema.NonEmptyArray<Schema.suspend<Schema.Codec<Submenu | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "command";
    } | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "checkbox";
        readonly checked: boolean;
    } | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "radio";
        readonly checked: boolean;
    } | {
        readonly kind: "separator";
    }, Submenu | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "command";
    } | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "checkbox";
        readonly checked: boolean;
    } | {
        readonly id: string;
        readonly label: string;
        readonly enabled?: boolean;
        readonly sublabel?: string;
        readonly toolTip?: string;
        readonly kind: "radio";
        readonly checked: boolean;
    } | {
        readonly kind: "separator";
    }, never, never>>>;
    readonly position: Schema.optionalKey<Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
    }>>;
}>;
export type PopupOptions = typeof PopupOptions.Type;
export declare const Selection: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"command">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"checkbox">;
    readonly id: Schema.String;
    readonly checked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"radio">;
    readonly id: Schema.String;
}>]>;
export type Selection = typeof Selection.Type;
/** Content for the macOS share sheet; at least one list must carry an entry. */
export declare const SharingItem: Schema.Struct<{
    readonly urls: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly filePaths: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly texts: Schema.optionalKey<Schema.$Array<Schema.String>>;
}>;
export type SharingItem = typeof SharingItem.Type;
export declare const PopupResult: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"dismissed">;
}>, Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"command">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"checkbox">;
    readonly id: Schema.String;
    readonly checked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"radio">;
    readonly id: Schema.String;
}>]>]>;
export type PopupResult = typeof PopupResult.Type;
export {};
//# sourceMappingURL=Menu.d.ts.map