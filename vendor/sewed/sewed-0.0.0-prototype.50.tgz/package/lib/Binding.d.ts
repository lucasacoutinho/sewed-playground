import { Context, Effect, Layer, Scope, Stream } from "effect";
import { RpcSchema } from "effect/rpc";
import type { Rpc, RpcGroup } from "effect/rpc";
import { ClientContext, MainContext, type ConnectionFactory } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
declare const slotIdentifier: unique symbol;
declare const ownerType: unique symbol;
export type Client<Rpcs extends Rpc.Any> = {
    readonly [Current in Rpcs as Current["_tag"]]: (input: Rpc.PayloadConstructor<Current>) => Current extends Rpc.Rpc<infer _Tag, infer _Payload, infer Success, infer Error, infer Middleware, infer _Requires> ? Success extends RpcSchema.Stream<infer A, infer E> ? Stream.Stream<A["Type"], E["Type"] | Error["Type"] | Middleware["error"]["Type"] | Middleware["~ClientError"] | SewedError, ClientContext | Scope.Scope | Rpc.ServicesClient<Current> | Rpc.MiddlewareClient<Rpcs>> : Effect.Effect<Success["Type"], Error["Type"] | Middleware["error"]["Type"] | Middleware["~ClientError"] | SewedError, ClientContext | Scope.Scope | Rpc.ServicesClient<Current> | Rpc.MiddlewareClient<Rpcs>> : never;
};
export interface Slot<Rpcs extends Rpc.Any, Key extends string = string> extends Context.Service<typeof slotIdentifier, ConnectionFactory> {
    readonly key: Key;
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    (): Effect.Effect<Client<Rpcs>, SewedError, ClientContext | Scope.Scope | Rpc.MiddlewareClient<Rpcs>>;
}
export interface Owner<Rpcs extends Rpc.Any> {
    readonly id: string;
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    readonly [ownerType]: (rpc: Rpcs) => Rpcs;
}
export interface Bound<Key extends string = string> {
    readonly slot: Context.Service<typeof slotIdentifier, ConnectionFactory>;
    readonly key: Key;
    readonly ownerId: string;
}
/** A declaration of the slots a runtime entry expects, by slot key. */
export interface Declaration<Keys extends string = string> {
    readonly key: Keys;
}
/**
 * The declared slot keys that a binding list leaves unbound. `unknown` when nothing is missing
 * or when the entry declared no keys to check; otherwise an object naming the missing slots,
 * which no binding list can satisfy, so the compiler reports them.
 */
export type Complete<Keys extends string, B extends readonly Bound<Keys>[]> = string extends Keys ? unknown : [Exclude<Keys, B[number]["key"]>] extends [never] ? unknown : {
    readonly missing: Exclude<Keys, B[number]["key"]>;
};
declare const prefix = "sewed/binding/";
export declare const makeBound: <Key extends string>(slot: Bound["slot"] & {
    readonly key: Key;
}, ownerId: string, factory: ConnectionFactory) => Bound<Key>;
export declare const factoryOf: (bound: Bound) => ConnectionFactory;
export declare const makeOwner: <Rpcs extends Rpc.Any, Fields extends object>(id: string, protocol: RpcGroup.RpcGroup<Rpcs>, factory: ConnectionFactory, fields: Fields) => Owner<Rpcs> & Fields;
export declare const slot: <const Name extends string, Rpcs extends Rpc.Any>(name: Name, protocol: RpcGroup.RpcGroup<Rpcs>) => Slot<Rpcs, `${typeof prefix}${Name}`>;
export declare const to: <Rpcs extends Rpc.Any, Key extends string>(slot: Slot<Rpcs, Key>, owner: Owner<NoInfer<Rpcs>>) => Bound<Key>;
/**
 * One `ClientContext` service over `bindings`, with no placement requirement of its own: `layer`
 * builds this the same way but also requires `MainContext`. A caller that supplies its own
 * identity instead — a renderer's own testing store, for instance — calls this directly.
 */
export declare const clientContext: (bindings: readonly Bound[]) => Effect.Effect<{
    readonly identity: object;
    readonly bindings: Context.Context<never>;
    readonly owners: ReadonlyMap<string, string>;
    readonly isClosed: () => boolean;
}, SewedError, Scope.Scope>;
/**
 * How a deferred client reaches its owner: one connection per slot for the client environment,
 * or one connection per operation. The renderer bridge handshake dominates small calls, so
 * `shared` is the default and `per-call` is the isolation opt-out.
 */
export type Connection = "shared" | "per-call";
export declare const layer: (bindings: readonly Bound[]) => Layer.Layer<ClientContext, SewedError, MainContext>;
export type DynamicResult = Effect.Effect<unknown, unknown, unknown> | Stream.Stream<unknown, unknown, unknown>;
type DynamicCall = (tag: string, input: unknown) => DynamicResult;
export declare const propsOf: (rpc: Rpc.Any) => Rpc.AnyWithProps;
export declare const methods: <Rpcs extends Rpc.Any, Shape = Client<Rpcs>>(protocol: RpcGroup.RpcGroup<Rpcs>, invoke: DynamicCall) => Shape;
export declare const table: <Rpcs extends Rpc.Any, Shape = Client<Rpcs>>(client: Shape) => Record<string, (input: unknown) => DynamicResult>;
export declare const client: <Rpcs extends Rpc.Any>(binding: Slot<Rpcs>) => Effect.Effect<Client<Rpcs>, SewedError, ClientContext | Scope.Scope | Rpc.MiddlewareClient<Rpcs>>;
export declare const deferred: <Rpcs extends Rpc.Any>(binding: Slot<Rpcs>, options?: {
    readonly connection?: Connection;
}) => Effect.Effect<Client<Rpcs>, never, ClientContext>;
/**
 * A client over a context that is not known yet: `options.context` is an Effect the caller is
 * still waiting on, still running, or has already failed — a runtime store's own future state, for
 * instance. Every call `flatMap`s it first, so a call made before it resolves parks there until it
 * does; a call made after it has failed `Closed` fails `Closed` the same way every other call does.
 * The returned `Client<Rpcs>` is one object built once: its identity does not change as `context`
 * moves through those states, only what each call does when it runs.
 */
export declare const pending: <Rpcs extends Rpc.Any>(binding: Slot<Rpcs>, options: {
    readonly context: Effect.Effect<ClientContext["Service"], SewedError>;
    readonly connection?: Connection;
}) => Client<Rpcs>;
export {};
//# sourceMappingURL=Binding.d.ts.map