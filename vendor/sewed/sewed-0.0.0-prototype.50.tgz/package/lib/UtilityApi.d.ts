export { define, entry, processId } from "./Utility.ts";
export type { Definition, Entry } from "./Utility.ts";
//# sourceMappingURL=UtilityApi.d.ts.map