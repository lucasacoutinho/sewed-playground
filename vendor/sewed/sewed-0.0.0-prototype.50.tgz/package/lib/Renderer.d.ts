import { Effect } from "effect";
import type { Scope } from "effect";
import { type Declaration } from "./Binding.ts";
import { ClientContext, RendererContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
/** The slot keys this document declares; main's `load` must bind exactly these. */
export interface Entry<Keys extends string = string> {
    readonly url: URL;
    readonly bindings: readonly Declaration<Keys>[];
}
export declare const entry: <Keys extends string>(url: URL, options: {
    readonly bindings: readonly Declaration<Keys>[];
}) => Entry<Keys>;
/**
 * A document shipped with the application: `path` resolves against `importMetaUrl` to a `file:`
 * URL, exactly as `entry(new URL(path, importMetaUrl), options)` would. `window.webContents.load`
 * checks that the resolved file exists before it configures the bridge or navigates, failing
 * `Protocol` and naming the path when it does not — this constructor stays inert and does no
 * filesystem work itself. Refuses, all with `Protocol` naming the path rather than an
 * undocumented `URIError` or a document outside the application: a `path` the URL constructor
 * cannot resolve (a bare `%` not part of a percent-escape, for instance); a `path` whose
 * resolved URL is not `file:` (an absolute `http:`/`https:` path, or `importMetaUrl` itself not
 * a `file:` URL); and a `path` that resolves above `importMetaUrl`'s own directory (a `..`
 * escape).
 */
export declare const local: <Keys extends string = never>(path: string, importMetaUrl: string, options?: {
    readonly bindings: readonly Declaration<Keys>[];
}) => Entry<Keys>;
/**
 * A document main writes itself, with nothing behind it: a `data:text/html;base64,…` entry with
 * no bindings, since a `data:` page has an opaque origin and cannot load the renderer runtime.
 * Use it for a message with no capability behind it, such as a crash-loop breaker's parked page
 * or a fatal notice; a page that offers an action needs a `local` document bound to a capability
 * instead. Refuses an empty string with `Protocol`.
 */
export declare const inline: (html: string) => Entry<never>;
/**
 * The native path of a file the user dropped or chose in this document. Files that did not
 * come from the desktop have no path and fail with `Protocol`; the preload bridge answers
 * synchronously, so no main policy is involved: the user disclosed the file.
 */
export declare const pathOf: (file: File) => Effect.Effect<string, SewedError, RendererContext>;
export declare const run: <E>(entry: Entry, setup: Effect.Effect<unknown, E, RendererContext | ClientContext | Scope.Scope>) => import("effect/Fiber").Fiber<void, E | SewedError>;
//# sourceMappingURL=Renderer.d.ts.map