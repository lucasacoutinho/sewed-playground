import { Schema } from "effect";
import type { Effect } from "effect";
import type { MainContext } from "./RuntimeContext.ts";
import type { SewedError } from "./SewedError.ts";
/** A DevTools protocol method such as `Runtime.evaluate`. */
export declare const DevToolsMethod: Schema.String;
export type DevToolsMethod = typeof DevToolsMethod.Type;
/** The automation web contents are created with; an undeclared operation does not exist on the handle. */
export declare const Declaration: Schema.Struct<{
    readonly evaluate: Schema.optionalKey<Schema.Literal<true>>;
    readonly devtools: Schema.optionalKey<Schema.NonEmptyArray<Schema.String>>;
    readonly input: Schema.optionalKey<Schema.Literal<true>>;
}>;
export type Declaration = typeof Declaration.Type;
export declare const EvaluateOptions: Schema.Struct<{
    readonly userGesture: Schema.optionalKey<Schema.Boolean>;
    /**
     * Runs the script in an isolated world of this id instead of the page's own, so it shares the
     * DOM but none of the page's JavaScript state. Ids from 1000 up are free for applications.
     */
    readonly world: Schema.optionalKey<Schema.Int>;
}>;
export type EvaluateOptions = typeof EvaluateOptions.Type;
/** Data mirrors of Electron's input structures; the library copies them before sending. */
export declare const MouseInput: Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly globalX: Schema.optionalKey<Schema.Finite>;
    readonly globalY: Schema.optionalKey<Schema.Finite>;
    readonly movementX: Schema.optionalKey<Schema.Finite>;
    readonly movementY: Schema.optionalKey<Schema.Finite>;
    readonly type: Schema.Literals<readonly ["mouseDown", "mouseUp", "mouseEnter", "mouseLeave", "contextMenu", "mouseMove"]>;
    readonly button: Schema.optionalKey<Schema.Literals<readonly ["left", "middle", "right"]>>;
    readonly clickCount: Schema.optionalKey<Schema.Int>;
}>;
export type MouseInput = typeof MouseInput.Type;
export declare const MouseWheelInput: Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly globalX: Schema.optionalKey<Schema.Finite>;
    readonly globalY: Schema.optionalKey<Schema.Finite>;
    readonly movementX: Schema.optionalKey<Schema.Finite>;
    readonly movementY: Schema.optionalKey<Schema.Finite>;
    readonly type: Schema.Literal<"mouseWheel">;
    readonly deltaX: Schema.optionalKey<Schema.Finite>;
    readonly deltaY: Schema.optionalKey<Schema.Finite>;
    readonly wheelTicksX: Schema.optionalKey<Schema.Finite>;
    readonly wheelTicksY: Schema.optionalKey<Schema.Finite>;
    readonly accelerationRatioX: Schema.optionalKey<Schema.Finite>;
    readonly accelerationRatioY: Schema.optionalKey<Schema.Finite>;
    readonly hasPreciseScrollingDeltas: Schema.optionalKey<Schema.Boolean>;
    readonly canScroll: Schema.optionalKey<Schema.Boolean>;
}>;
export type MouseWheelInput = typeof MouseWheelInput.Type;
export declare const KeyboardInput: Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly type: Schema.Literals<readonly ["rawKeyDown", "keyDown", "keyUp", "char"]>;
    readonly keyCode: Schema.String;
}>;
export type KeyboardInput = typeof KeyboardInput.Type;
export declare const InputEvent: Schema.Union<readonly [Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly globalX: Schema.optionalKey<Schema.Finite>;
    readonly globalY: Schema.optionalKey<Schema.Finite>;
    readonly movementX: Schema.optionalKey<Schema.Finite>;
    readonly movementY: Schema.optionalKey<Schema.Finite>;
    readonly type: Schema.Literals<readonly ["mouseDown", "mouseUp", "mouseEnter", "mouseLeave", "contextMenu", "mouseMove"]>;
    readonly button: Schema.optionalKey<Schema.Literals<readonly ["left", "middle", "right"]>>;
    readonly clickCount: Schema.optionalKey<Schema.Int>;
}>, Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly globalX: Schema.optionalKey<Schema.Finite>;
    readonly globalY: Schema.optionalKey<Schema.Finite>;
    readonly movementX: Schema.optionalKey<Schema.Finite>;
    readonly movementY: Schema.optionalKey<Schema.Finite>;
    readonly type: Schema.Literal<"mouseWheel">;
    readonly deltaX: Schema.optionalKey<Schema.Finite>;
    readonly deltaY: Schema.optionalKey<Schema.Finite>;
    readonly wheelTicksX: Schema.optionalKey<Schema.Finite>;
    readonly wheelTicksY: Schema.optionalKey<Schema.Finite>;
    readonly accelerationRatioX: Schema.optionalKey<Schema.Finite>;
    readonly accelerationRatioY: Schema.optionalKey<Schema.Finite>;
    readonly hasPreciseScrollingDeltas: Schema.optionalKey<Schema.Boolean>;
    readonly canScroll: Schema.optionalKey<Schema.Boolean>;
}>, Schema.Struct<{
    readonly modifiers: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["shift", "control", "ctrl", "alt", "meta", "command", "cmd", "iskeypad", "isautorepeat", "leftbuttondown", "middlebuttondown", "rightbuttondown", "capslock", "numlock", "left", "right"]>>>;
    readonly type: Schema.Literals<readonly ["rawKeyDown", "keyDown", "keyUp", "char"]>;
    readonly keyCode: Schema.String;
}>]>;
export type InputEvent = typeof InputEvent.Type;
/** The DevTools methods a declaration allows; none when the declaration has no allowlist. */
export type DevToolsOf<A extends Declaration> = A extends {
    readonly devtools: readonly string[];
} ? A["devtools"][number] : never;
/** Every automation member, typed against one declaration. */
export interface Members<A extends Declaration> {
    readonly evaluate: <T, I>(script: string, result: Schema.Codec<T, I>, options?: EvaluateOptions) => Effect.Effect<T, SewedError, MainContext>;
    readonly devtools: <T, I>(method: DevToolsOf<A>, params: Schema.Json | undefined, result: Schema.Codec<T, I>) => Effect.Effect<T, SewedError, MainContext>;
    readonly input: (event: InputEvent) => Effect.Effect<void, SewedError, MainContext>;
}
/** The automation members a declaration grants; undeclared members do not exist on the type. */
export type Of<A extends Declaration> = Pick<Members<A>, Extract<keyof A, keyof Members<A>>>;
//# sourceMappingURL=Automation.d.ts.map