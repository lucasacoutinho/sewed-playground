import { Schema } from "effect";
export declare const Mode: Schema.Literals<readonly ["record-until-full", "record-continuously", "record-as-much-as-possible", "trace-to-console"]>;
export type Mode = typeof Mode.Type;
export declare const Options: Schema.Struct<{
    readonly included: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly excluded: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly mode: Schema.optionalKey<Schema.Literals<readonly ["record-until-full", "record-continuously", "record-as-much-as-possible", "trace-to-console"]>>;
    readonly bufferKb: Schema.optionalKey<Schema.Int>;
    readonly argumentFilter: Schema.optionalKey<Schema.Boolean>;
}>;
export type Options = typeof Options.Type;
export declare const BufferUsage: Schema.Struct<{
    readonly value: Schema.Finite;
    readonly percentage: Schema.Finite;
}>;
export type BufferUsage = typeof BufferUsage.Type;
/** Which processes record heap allocations into a trace, and how often they sample. */
export declare const HeapProfiling: Schema.Struct<{
    readonly mode: Schema.optionalKey<Schema.Literals<readonly ["all", "browser", "gpu", "minimal", "renderer-sampling", "all-renderers", "utility-sampling", "all-utilities", "utility-and-browser"]>>;
    /** Bytes between samples, on average. */
    readonly samplingRate: Schema.optionalKey<Schema.Int>;
}>;
export type HeapProfiling = typeof HeapProfiling.Type;
//# sourceMappingURL=ContentTracing.d.ts.map