import { Context, Effect, Layer } from "effect";
import type { Stream } from "effect";
import type { Rpc, RpcGroup, RpcSchema } from "effect/rpc";
import * as Binding from "./Binding.ts";
import { ClientContext } from "./RuntimeContext.ts";
import type { HandlerLayer } from "./internal/HandlerLayer.ts";
import { SewedError } from "./SewedError.ts";
/**
 * What a capability offers its caller: one method per RPC, carrying only the requirements that are
 * genuinely the caller's to provide — the protocol's own schema services. Acquiring the capability
 * is what proves the environment, so an operation needs no client context, no scope, and no
 * middleware service. Both layers satisfy this: the native one calls handlers directly, and the
 * client one captures its environment when it is built.
 */
export type Operations<Rpcs extends Rpc.Any> = {
    readonly [Current in Rpcs as Current["_tag"]]: (input: Rpc.PayloadConstructor<Current>) => Current extends Rpc.Rpc<infer _Tag, infer _Payload, infer Success, infer Error, infer _Middleware, infer _Requires> ? Success extends RpcSchema.Stream<infer A, infer E> ? Stream.Stream<A["Type"], E["Type"] | Error["Type"] | SewedError, Rpc.ServicesClient<Current>> : Effect.Effect<Success["Type"], Error["Type"] | SewedError, Rpc.ServicesClient<Current>> : never;
};
export interface Capability<Rpcs extends Rpc.Any, Key extends string = string> extends Context.Service<Capability<Rpcs, Key>, Operations<Rpcs>> {
    readonly key: Key;
    readonly protocol: RpcGroup.RpcGroup<Rpcs>;
    readonly slot: Binding.Slot<Rpcs, Key>;
}
type HasProtocol = {
    readonly key: string;
    readonly protocol: {
        readonly requests: ReadonlyMap<string, Rpc.Any>;
    };
};
type RpcsOf<C extends HasProtocol> = RpcGroup.Rpcs<C["protocol"]>;
/**
 * A capability's operations: what `yield* capability` answers, named so a helper can take it as a
 * parameter instead of writing out `Operations<Rpcs>` by hand.
 */
export type Client<C extends HasProtocol> = Operations<RpcsOf<C>>;
/**
 * A capability's handler record — one function per operation — sharing the requirement `R`.
 * Effect's own `RpcGroup.HandlersFrom` types every handler's requirement as `any`, because its
 * `Rpc.ToHandlerFn` defaults `R` to `any` when nothing supplies one; a record annotated with
 * `HandlersFrom` therefore makes `toLayer` infer `R = any`, and a host built over it collapses
 * `R | MainContext | Scope` to `any` — a requirement no caller can discharge, so `Effect.runPromise`
 * accepts it though nothing was actually provided. A record typed with `Implementation` keeps `R`,
 * so the host built from it carries a requirement a caller can still discharge, and `R` defaults to
 * `never` for a record whose handlers need nothing.
 */
export type Implementation<C extends HasProtocol, R = never> = {
    readonly [Current in RpcsOf<C> as Current["_tag"]]: Rpc.ToHandlerFn<Current, R>;
};
export declare const define: <const Name extends string, Rpcs extends Rpc.Any>(name: Name, protocol: RpcGroup.RpcGroup<Rpcs>) => Capability<Rpcs, `sewed/binding/${Name}`>;
export declare const client: <Rpcs extends Rpc.Any, Key extends string>(capability: Capability<Rpcs, Key>, options?: {
    readonly connection?: Binding.Connection;
}) => Layer.Layer<Capability<Rpcs, Key>, never, ClientContext>;
/**
 * The handlers a host serves for a capability's protocol: a Layer of the protocol's handlers, or
 * a function of `implement` (the protocol's `toLayer`) returning one. This is what
 * {@link fromHandlers}, `Testing.client`, and `Testing.layer` all take, named so a function can
 * take a host as a parameter.
 */
export type Handlers<Rpcs extends Rpc.Any, E = never, R = never> = HandlerLayer<Rpcs, E, R>;
export declare const fromHandlers: <Rpcs extends Rpc.Any, Key extends string, E, R>(capability: Capability<Rpcs, Key>, handlers: HandlerLayer<Rpcs, E, R>) => Layer.Layer<Capability<Rpcs, Key>, E, R>;
/**
 * The slot a served capability's owner binds to, for a renderer entry's `bindings` list.
 * `Binding.to(capability.slot, owner)` pairs it with the owner `serve` returns.
 */
export declare const declaration: <Rpcs extends Rpc.Any, Key extends string>(capability: Capability<Rpcs, Key>) => Binding.Declaration<Key>;
export {};
//# sourceMappingURL=Capability.d.ts.map