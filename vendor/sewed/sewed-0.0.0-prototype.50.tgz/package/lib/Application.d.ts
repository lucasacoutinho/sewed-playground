import { Schema } from "effect";
import * as Binary from "./Binary.ts";
/** Inert schemas for the application surface that `App` in `sewed/main` operates. */
export declare const PathName: Schema.Literals<readonly ["home", "appData", "assets", "userData", "sessionData", "temp", "exe", "module", "desktop", "documents", "downloads", "music", "pictures", "videos", "recent", "logs", "crashDumps"]>;
export type PathName = typeof PathName.Type;
export declare const Info: Schema.Struct<{
    readonly name: Schema.String;
    readonly version: Schema.String;
    readonly locale: Schema.String;
    readonly localeCountryCode: Schema.String;
    readonly systemLocale: Schema.String;
    readonly preferredLanguages: Schema.$Array<Schema.String>;
    readonly packaged: Schema.Boolean;
    readonly appPath: Schema.String;
    readonly hardwareAcceleration: Schema.Boolean;
}>;
export type Info = typeof Info.Type;
export declare const GpuInfoKind: Schema.Literals<readonly ["basic", "complete"]>;
export type GpuInfoKind = typeof GpuInfoKind.Type;
export declare const LoginItems: Schema.Struct<{
    readonly openAtLogin: Schema.Boolean;
    readonly wasOpenedAtLogin: Schema.Boolean;
    readonly status: Schema.Literals<readonly ["not-registered", "enabled", "requires-approval", "not-found"]>;
}>;
export type LoginItems = typeof LoginItems.Type;
export declare const LoginItemSettings: Schema.Struct<{
    readonly openAtLogin: Schema.optionalKey<Schema.Boolean>;
    readonly openAsHidden: Schema.optionalKey<Schema.Boolean>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly args: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly type: Schema.optionalKey<Schema.Literals<readonly ["mainAppService", "agentService", "daemonService", "loginItemService"]>>;
    readonly serviceName: Schema.optionalKey<Schema.String>;
    readonly name: Schema.optionalKey<Schema.String>;
}>;
export type LoginItemSettings = typeof LoginItemSettings.Type;
export declare const Badge: Schema.Int;
/** A process exit code: an integer from 0 to 255, the range Electron's own `app.exit` accepts. */
export declare const ExitCode: Schema.Int;
/** One process of the application, as the operating system accounts for it. */
export declare const ProcessMetric: Schema.Struct<{
    readonly pid: Schema.Finite;
    readonly type: Schema.String;
    readonly name: Schema.optionalKey<Schema.String>;
    readonly serviceName: Schema.optionalKey<Schema.String>;
    /** Milliseconds since the Unix epoch. */
    readonly creationTime: Schema.Finite;
    readonly sandboxed: Schema.optionalKey<Schema.Boolean>;
    readonly cpu: Schema.Struct<{
        /** Percent of one core since the previous read; the first read answers zero. */
        readonly percentCPUUsage: Schema.Finite;
        /** Seconds of processor time since the process started. */
        readonly cumulativeCPUUsage: Schema.optionalKey<Schema.Finite>;
        readonly idleWakeupsPerSecond: Schema.Finite;
    }>;
    /** Kilobytes. */
    readonly memory: Schema.Struct<{
        readonly workingSetSize: Schema.Finite;
        readonly peakWorkingSetSize: Schema.Finite;
        readonly privateBytes: Schema.optionalKey<Schema.Finite>;
    }>;
}>;
export type ProcessMetric = typeof ProcessMetric.Type;
/** How the next instance starts: its arguments and, when not this one, its executable. */
export declare const Relaunch: Schema.Struct<{
    readonly args: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly execPath: Schema.optionalKey<Schema.String>;
}>;
export type Relaunch = typeof Relaunch.Type;
export declare const AboutPanel: Schema.Struct<{
    readonly applicationName: Schema.optionalKey<Schema.String>;
    readonly applicationVersion: Schema.optionalKey<Schema.String>;
    readonly copyright: Schema.optionalKey<Schema.String>;
    readonly version: Schema.optionalKey<Schema.String>;
    readonly credits: Schema.optionalKey<Schema.String>;
    readonly authors: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly website: Schema.optionalKey<Schema.String>;
    readonly iconPath: Schema.optionalKey<Schema.String>;
}>;
export type AboutPanel = typeof AboutPanel.Type;
export declare const Scheme: Schema.String;
export declare const ProtocolClient: Schema.Struct<{
    readonly scheme: Schema.String;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly args: Schema.optionalKey<Schema.$Array<Schema.String>>;
}>;
export type ProtocolClient = typeof ProtocolClient.Type;
/** A Chromium or Electron switch appended before readiness; the name carries no leading dashes. */
export declare const CommandLineSwitch: Schema.Struct<{
    readonly name: Schema.String;
    readonly value: Schema.optionalKey<Schema.String>;
}>;
export type CommandLineSwitch = typeof CommandLineSwitch.Type;
/** GPU settings that must precede readiness. */
export declare const Gpu: Schema.Struct<{
    readonly acceleration: Schema.Boolean;
    /**
     * `false` keeps WebGL and the other 3D APIs available to a domain after its GPU process has
     * crashed often; Chromium blocks them by default.
     */
    readonly domainBlockingFor3DAPIs: Schema.optionalKey<Schema.Boolean>;
}>;
export type Gpu = typeof Gpu.Type;
/** Facts about the application that must precede readiness. */
export declare const Identity: Schema.Struct<{
    /** The Windows application user model id. */
    readonly userModelId: Schema.optionalKey<Schema.String>;
    /** The application's name, which decides its default data directory. */
    readonly name: Schema.optionalKey<Schema.String>;
    /** The `.desktop` file the application is launched from, on Linux, such as `app.desktop`. */
    readonly desktopName: Schema.optionalKey<Schema.String>;
    /** `true` sandboxes every renderer the process creates, whatever a window asks for. */
    readonly sandbox: Schema.optionalKey<Schema.Boolean>;
}>;
export type Identity = typeof Identity.Type;
/** A fatal error with no window: `title` and `content` must both be non-empty strings. */
export declare const ErrorBox: Schema.Struct<{
    readonly title: Schema.String;
    readonly content: Schema.String;
}>;
export type ErrorBox = typeof ErrorBox.Type;
export declare const ChildProcessGone: Schema.Struct<{
    readonly type: Schema.Literals<readonly ["Utility", "Zygote", "Sandbox helper", "GPU", "Pepper Plugin", "Pepper Plugin Broker", "Unknown"]>;
    readonly reason: Schema.Literals<readonly ["clean-exit", "abnormal-exit", "killed", "crashed", "oom", "launch-failed", "integrity-failure", "memory-eviction"]>;
    readonly exitCode: Schema.Finite;
    readonly serviceName: Schema.optionalKey<Schema.String>;
    readonly name: Schema.optionalKey<Schema.String>;
}>;
export type ChildProcessGone = typeof ChildProcessGone.Type;
/** Focus moved to or from a window; `window` is the Sewed window id, or null for a foreign window. */
export declare const WindowFocus: Schema.Struct<{
    readonly focused: Schema.Boolean;
    readonly window: Schema.NullOr<Schema.String>;
}>;
export type WindowFocus = typeof WindowFocus.Type;
export declare const WebContentsCreated: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly type: Schema.String;
}>;
export type WebContentsCreated = typeof WebContentsCreated.Type;
export declare const LoginChallenge: Schema.Struct<{
    readonly url: Schema.String;
    readonly isProxy: Schema.Boolean;
    readonly scheme: Schema.String;
    readonly host: Schema.String;
    readonly port: Schema.Finite;
    readonly realm: Schema.String;
    readonly isRequestForNavigation: Schema.Boolean;
}>;
export type LoginChallenge = typeof LoginChallenge.Type;
/** The answer to an HTTP authentication challenge; the password stays redacted until Electron sends it. */
export declare const LoginResponse: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"cancel">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"credentials">;
    readonly username: Schema.String;
    readonly password: Schema.Redacted<Schema.String>;
}>]>;
export type LoginResponse = typeof LoginResponse.Type;
export declare const Task: Schema.Struct<{
    readonly program: Schema.String;
    readonly arguments: Schema.String;
    readonly title: Schema.String;
    readonly description: Schema.String;
    readonly iconPath: Schema.String;
    readonly iconIndex: Schema.Int;
    readonly workingDirectory: Schema.optionalKey<Schema.String>;
}>;
export type Task = typeof Task.Type;
export declare const JumpListItem: Schema.Struct<{
    readonly type: Schema.optionalKey<Schema.Literals<readonly ["task", "separator", "file"]>>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly program: Schema.optionalKey<Schema.String>;
    readonly args: Schema.optionalKey<Schema.String>;
    readonly title: Schema.optionalKey<Schema.String>;
    readonly description: Schema.optionalKey<Schema.String>;
    readonly iconPath: Schema.optionalKey<Schema.String>;
    readonly iconIndex: Schema.optionalKey<Schema.Int>;
    readonly workingDirectory: Schema.optionalKey<Schema.String>;
}>;
export type JumpListItem = typeof JumpListItem.Type;
export declare const JumpListCategory: Schema.Struct<{
    readonly type: Schema.optionalKey<Schema.Literals<readonly ["tasks", "frequent", "recent", "custom"]>>;
    readonly name: Schema.optionalKey<Schema.String>;
    readonly items: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly type: Schema.optionalKey<Schema.Literals<readonly ["task", "separator", "file"]>>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly program: Schema.optionalKey<Schema.String>;
        readonly args: Schema.optionalKey<Schema.String>;
        readonly title: Schema.optionalKey<Schema.String>;
        readonly description: Schema.optionalKey<Schema.String>;
        readonly iconPath: Schema.optionalKey<Schema.String>;
        readonly iconIndex: Schema.optionalKey<Schema.Int>;
        readonly workingDirectory: Schema.optionalKey<Schema.String>;
    }>>>;
}>;
export type JumpListCategory = typeof JumpListCategory.Type;
export declare const DockBounce: Schema.Literals<readonly ["critical", "informational"]>;
export type DockBounce = typeof DockBounce.Type;
/** How the process resolves host names. Every field left out keeps Chromium's default. */
export declare const HostResolver: Schema.Struct<{
    /** Use Chromium's own resolver instead of the operating system's. */
    readonly enableBuiltInResolver: Schema.optionalKey<Schema.Boolean>;
    /** Race IPv4 and IPv6 connections; needs the built-in resolver. */
    readonly enableHappyEyeballs: Schema.optionalKey<Schema.Boolean>;
    readonly secureDnsMode: Schema.optionalKey<Schema.Literals<readonly ["off", "automatic", "secure"]>>;
    /** DNS-over-HTTPS server templates, such as `https://dns.example/dns-query{?dns}`. */
    readonly secureDnsServers: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly enableAdditionalDnsQueryTypes: Schema.optionalKey<Schema.Boolean>;
}>;
export type HostResolver = typeof HostResolver.Type;
export declare const FileIconSize: Schema.Literals<readonly ["small", "normal", "large"]>;
export type FileIconSize = typeof FileIconSize.Type;
/** A server asking for a client certificate, with the certificates the store offers. */
export declare const ClientCertificateRequest: Schema.Struct<{
    /** The server as Electron names it here: its host and port, such as `example.com:443`. */
    readonly url: Schema.String;
    readonly certificates: Schema.$Array<Schema.Struct<{
        readonly fingerprint: Schema.String;
        readonly subjectName: Schema.String;
        readonly issuerName: Schema.String;
        readonly validStart: Schema.Finite;
        readonly validExpiry: Schema.Finite;
    }>>;
}>;
export type ClientCertificateRequest = typeof ClientCertificateRequest.Type;
/**
 * Which client certificate a request is answered with: the store's first (`default`, what Electron
 * does by itself), one named by fingerprint, or none.
 */
export declare const ClientCertificateChoice: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"default">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"none">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"select">;
    readonly fingerprint: Schema.String;
}>]>;
export type ClientCertificateChoice = typeof ClientCertificateChoice.Type;
/**
 * A macOS Handoff activity: `type` is the reverse-DNS name declared in the application's
 * `NSUserActivityTypes`, `userInfo` its JSON state, and `webpageUrl` what to open where the
 * application is not installed.
 */
export declare const Activity: Schema.Struct<{
    readonly type: Schema.String;
    readonly userInfo: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly webpageUrl: Schema.optionalKey<Schema.String>;
}>;
export type Activity = typeof Activity.Type;
/** What happens to a Handoff activity; `userInfo` is `null` when it is not JSON. */
export declare const ActivityEvent: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"will-continue">;
    readonly type: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["continue", "was-continued", "update-state"]>;
    readonly type: Schema.String;
    readonly userInfo: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly webpageUrl: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"continue-error">;
    readonly type: Schema.String;
    readonly error: Schema.String;
}>]>;
export type ActivityEvent = typeof ActivityEvent.Type;
export declare const ActivationPolicy: Schema.Literals<readonly ["regular", "accessory", "prohibited"]>;
export type ActivationPolicy = typeof ActivationPolicy.Type;
/** What the user has removed from the Windows jump list, and how many items it shows at least. */
export declare const JumpListSettings: Schema.Struct<{
    readonly minItems: Schema.Finite;
    readonly removedItems: Schema.$Array<Schema.Struct<{
        readonly type: Schema.optionalKey<Schema.Literals<readonly ["task", "separator", "file"]>>;
        readonly path: Schema.optionalKey<Schema.String>;
        readonly program: Schema.optionalKey<Schema.String>;
        readonly args: Schema.optionalKey<Schema.String>;
        readonly title: Schema.optionalKey<Schema.String>;
        readonly description: Schema.optionalKey<Schema.String>;
        readonly iconPath: Schema.optionalKey<Schema.String>;
        readonly iconIndex: Schema.optionalKey<Schema.Int>;
        readonly workingDirectory: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export type JumpListSettings = typeof JumpListSettings.Type;
/** The application registered for a URL's scheme; `icon` is PNG bytes. */
export declare const ProtocolApplication: Schema.Struct<{
    readonly name: Schema.String;
    readonly path: Schema.String;
    readonly icon: Binary.Bytes;
}>;
export type ProtocolApplication = typeof ProtocolApplication.Type;
/** A PKCS#12 file to import into the platform certificate store, on Linux. */
export declare const CertificateImport: Schema.Struct<{
    readonly certificate: Schema.String;
    readonly password: Schema.Redacted<Schema.String>;
}>;
export type CertificateImport = typeof CertificateImport.Type;
/** A client certificate store asking for the password of a token. */
export declare const CertificatePasswordRequest: Schema.Struct<{
    readonly hostname: Schema.String;
    readonly tokenName: Schema.String;
    readonly isRetry: Schema.Boolean;
}>;
export type CertificatePasswordRequest = typeof CertificatePasswordRequest.Type;
export declare const CertificatePassword: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"cancel">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"password">;
    readonly password: Schema.Redacted<Schema.String>;
}>]>;
export type CertificatePassword = typeof CertificatePassword.Type;
/** One native window of the process; `id` is its Sewed id, or `null` for one Sewed did not create. */
export declare const WindowEntry: Schema.Struct<{
    readonly id: Schema.NullOr<Schema.String>;
    readonly nativeId: Schema.Finite;
    readonly title: Schema.String;
    readonly focused: Schema.Boolean;
    readonly visible: Schema.Boolean;
}>;
export type WindowEntry = typeof WindowEntry.Type;
/** One web contents of the process; `id` is its Sewed owner's id, or `null` for an unowned one. */
export declare const WebContentsEntry: Schema.Struct<{
    readonly id: Schema.NullOr<Schema.String>;
    readonly nativeId: Schema.Finite;
    readonly type: Schema.String;
    readonly url: Schema.String;
    readonly focused: Schema.Boolean;
}>;
export type WebContentsEntry = typeof WebContentsEntry.Type;
/**
 * Something that belongs to one web contents, to find that web contents by: a frame by its
 * routing id or its token, or a DevTools target by its id.
 */
export declare const ContentsPart: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"frame">;
    readonly processId: Schema.Finite;
    readonly routingId: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"frame-token">;
    readonly processId: Schema.Finite;
    readonly token: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"devtools-target">;
    readonly id: Schema.String;
}>]>;
export type ContentsPart = typeof ContentsPart.Type;
/** A session Electron created, described by where it stores its data. */
export declare const SessionCreated: Schema.Struct<{
    readonly persistent: Schema.Boolean;
    readonly storagePath: Schema.NullOr<Schema.String>;
}>;
export type SessionCreated = typeof SessionCreated.Type;
//# sourceMappingURL=Application.d.ts.map