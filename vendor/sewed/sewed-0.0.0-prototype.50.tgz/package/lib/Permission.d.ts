import { Schema } from "effect";
import * as Decision from "./Decision.ts";
export declare const Name: Schema.Literals<readonly ["notifications", "geolocation", "fullscreen", "pointerLock", "media", "clipboard-read", "clipboard-sanitized-write", "persistent-storage", "screen-wake-lock", "hid", "serial", "usb"]>;
export type Name = typeof Name.Type;
export declare const MediaType: Schema.Literals<readonly ["audio", "video"]>;
export type MediaType = typeof MediaType.Type;
export declare const Rule: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
    readonly permissions: Schema.NonEmptyArray<Schema.Literals<readonly ["notifications", "geolocation", "fullscreen", "pointerLock", "media", "clipboard-read", "clipboard-sanitized-write", "persistent-storage", "screen-wake-lock", "hid", "serial", "usb"]>>;
    readonly mediaTypes: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["audio", "video"]>>>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"document">;
    readonly url: Schema.String;
    readonly permissions: Schema.NonEmptyArray<Schema.Literals<readonly ["notifications", "geolocation", "fullscreen", "pointerLock", "media", "clipboard-read", "clipboard-sanitized-write", "persistent-storage", "screen-wake-lock", "hid", "serial", "usb"]>>;
    readonly mediaTypes: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["audio", "video"]>>>;
}>]>;
export declare const Rules: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
    readonly permissions: Schema.NonEmptyArray<Schema.Literals<readonly ["notifications", "geolocation", "fullscreen", "pointerLock", "media", "clipboard-read", "clipboard-sanitized-write", "persistent-storage", "screen-wake-lock", "hid", "serial", "usb"]>>;
    readonly mediaTypes: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["audio", "video"]>>>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"document">;
    readonly url: Schema.String;
    readonly permissions: Schema.NonEmptyArray<Schema.Literals<readonly ["notifications", "geolocation", "fullscreen", "pointerLock", "media", "clipboard-read", "clipboard-sanitized-write", "persistent-storage", "screen-wake-lock", "hid", "serial", "usb"]>>;
    readonly mediaTypes: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["audio", "video"]>>>;
}>]>>;
export type Rules = typeof Rules.Type;
/**
 * A permission policy: it names the least it needs from an event —
 * `{ name, origin, document, mediaTypes }`, the flat shape `Decidables.Session.Permission` shares
 * between a permission check and a device check. An **origin** rule is answered from `origin`
 * alone, and misses when it is `null` (an opaque origin — `file:`, `data:` — names nothing); a
 * **document** rule is answered only from `document`, so a device check (`document: null`) is
 * never granted by a document rule, even one whose document happens to key the same origin. This
 * is deliberately tighter than base, where a root-document rule granted a device check because its
 * origin URL happened to share that document key.
 *
 * A rule whose own `mediaTypes` is set grants a request only when every type the event asks for is
 * among them — `event.mediaTypes.every(...)`, vacuously true for a non-media event's empty list, so
 * it never blocks a permission the rule already names outside `media`. A rule with no `mediaTypes`
 * grants any media request, exactly as it did before this field existed.
 */
export declare const Policy: Decision.Policy<readonly ({
    readonly kind: "origin";
    readonly origin: string;
    readonly permissions: readonly ["clipboard-read" | "clipboard-sanitized-write" | "fullscreen" | "geolocation" | "hid" | "media" | "notifications" | "persistent-storage" | "pointerLock" | "screen-wake-lock" | "serial" | "usb", ...("clipboard-read" | "clipboard-sanitized-write" | "fullscreen" | "geolocation" | "hid" | "media" | "notifications" | "persistent-storage" | "pointerLock" | "screen-wake-lock" | "serial" | "usb")[]];
    readonly mediaTypes?: readonly ["audio" | "video", ...("audio" | "video")[]];
} | {
    readonly kind: "document";
    readonly url: string;
    readonly permissions: readonly ["clipboard-read" | "clipboard-sanitized-write" | "fullscreen" | "geolocation" | "hid" | "media" | "notifications" | "persistent-storage" | "pointerLock" | "screen-wake-lock" | "serial" | "usb", ...("clipboard-read" | "clipboard-sanitized-write" | "fullscreen" | "geolocation" | "hid" | "media" | "notifications" | "persistent-storage" | "pointerLock" | "screen-wake-lock" | "serial" | "usb")[]];
    readonly mediaTypes?: readonly ["audio" | "video", ...("audio" | "video")[]];
})[], {
    readonly name: string;
    readonly origin: string | null;
    readonly document: string | null;
    readonly mediaTypes: readonly MediaType[];
}, "allow">;
//# sourceMappingURL=Permission.d.ts.map