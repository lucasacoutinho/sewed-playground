import { Schema } from "effect";
export declare const Kind: Schema.Literals<readonly ["prevent-app-suspension", "prevent-display-sleep"]>;
export type Kind = typeof Kind.Type;
//# sourceMappingURL=PowerSaveBlocker.d.ts.map