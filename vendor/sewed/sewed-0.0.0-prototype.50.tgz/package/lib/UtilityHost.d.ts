import { Effect, Scope } from "effect";
import type { Rpc } from "effect/rpc";
import { type Bound, type Complete, type Owner } from "./Binding.ts";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
import type { Entry } from "./Utility.ts";
export { entry } from "./Utility.ts";
export type { Definition, Entry } from "./Utility.ts";
export interface Handle<Rpcs extends Rpc.Any> extends Owner<Rpcs> {
    readonly processId: number;
    readonly shutdown: Effect.Effect<void, SewedError, MainContext>;
    readonly terminate: Effect.Effect<void, SewedError, MainContext>;
    readonly awaitExit: Effect.Effect<number, never, MainContext>;
}
export declare const spawn: <Rpcs extends Rpc.Any, Keys extends string, const B extends readonly Bound<Keys>[] = []>(entry: Entry<Rpcs, Keys> & Complete<Keys, B>, options?: {
    readonly bindings: B;
}) => Effect.Effect<Handle<Rpcs>, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=UtilityHost.d.ts.map