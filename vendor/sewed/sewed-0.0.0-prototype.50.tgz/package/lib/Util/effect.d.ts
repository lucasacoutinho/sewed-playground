export declare const taggedFunction: <Tag extends object, Fn extends (...args: never[]) => unknown>(tag: Tag, fn: Fn) => Tag & Fn;
//# sourceMappingURL=effect.d.ts.map