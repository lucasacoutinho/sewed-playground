import { Schema } from "effect";
import * as Decision from "./Decision.ts";
/**
 * A navigation rule: an origin/document rule (`UrlRule.Rule`) or a Chromium match pattern
 * (`WebRequest.Pattern`, such as `https://*.example.com/*`). One shape replaces the two separate
 * navigation schemas `WebContents.NavigationPolicy` and `GuestView.NavigationPolicy` used to be,
 * so a policy compiled from it works identically wherever a navigation decidable is gated by one.
 */
export declare const Rules: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"document">;
    readonly url: Schema.String;
}>]>, Schema.String]>>;
export type Rules = typeof Rules.Type;
/**
 * Compiles validated rule data into URL predicates, in order. Each rule already validated itself at
 * decode time (`UrlRule.Rule`'s discriminated shapes, `WebRequest.Pattern`'s own filter), so this
 * never throws on a value that decoded successfully.
 */
export declare const compile: (rules: Rules) => readonly ((url: URL) => boolean)[];
/**
 * A navigation policy: it names the least it needs from an event — a `url` — so it installs on both
 * `WebContents.Navigation` (whose event also carries `kind`) and `WebContents.Popup`. An unparseable
 * URL is a miss, answered {@link Decision.Pass} like every other miss, per the policy rule in
 * `Decision.Policy`'s own doc.
 */
export declare const Policy: Decision.Policy<readonly (string | {
    readonly kind: "origin";
    readonly origin: string;
} | {
    readonly kind: "document";
    readonly url: string;
})[], {
    readonly url: string;
}, "allow">;
//# sourceMappingURL=Navigation.d.ts.map