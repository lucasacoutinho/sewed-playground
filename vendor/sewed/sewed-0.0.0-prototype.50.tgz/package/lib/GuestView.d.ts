import { Schema } from "effect";
import type { Effect, Stream } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import type * as Automation from "./Automation.ts";
import * as Binary from "./Binary.ts";
import * as Capability from "./Capability.ts";
import type * as Download from "./Download.ts";
import type { Handle as SessionHandle } from "./internal/Session.ts";
import type { Attachable } from "./internal/View.ts";
import type { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
import * as WebContents from "./WebContents.ts";
export declare const WebRtcPolicy: Schema.Literals<readonly ["default", "publicInterfaceOnly", "disableNonProxiedUdp"]>;
export type WebRtcPolicy = typeof WebRtcPolicy.Type;
/** Whether keyboard and mouse input reaches the guest page. */
export declare const InputPolicy: Schema.Literals<readonly ["allow", "block"]>;
export type InputPolicy = typeof InputPolicy.Type;
export declare const Settings: Schema.Struct<{
    readonly navigation: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.Struct<{
        readonly kind: Schema.Literal<"origin">;
        readonly origin: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"document">;
        readonly url: Schema.String;
    }>]>, Schema.String]>>;
    readonly webRtc: Schema.optionalKey<Schema.Literals<readonly ["default", "publicInterfaceOnly", "disableNonProxiedUdp"]>>;
    readonly input: Schema.optionalKey<Schema.Literals<readonly ["allow", "block"]>>;
    readonly backgroundThrottling: Schema.optionalKey<Schema.Boolean>;
    readonly automation: Schema.optionalKey<Schema.Struct<{
        readonly evaluate: Schema.optionalKey<Schema.Literal<true>>;
        readonly devtools: Schema.optionalKey<Schema.NonEmptyArray<Schema.String>>;
        readonly input: Schema.optionalKey<Schema.Literal<true>>;
    }>>;
}>;
export type Settings = typeof Settings.Type;
export interface Options<A extends Automation.Declaration> extends Omit<Settings, "automation"> {
    readonly session?: SessionHandle;
    readonly automation?: A;
}
/** What this capability serves beyond state, focus, zoom, find, and history. */
export declare const HostPolicy: Schema.Struct<{
    readonly navigate: Schema.Boolean;
    readonly capture: Schema.Boolean;
}>;
export type HostPolicy = typeof HostPolicy.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"back", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"capture", Schema.Struct<{
    readonly rect: Schema.optionalKey<Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>>;
    readonly stayHidden: Schema.optionalKey<Schema.Boolean>;
    readonly stayAwake: Schema.optionalKey<Schema.Boolean>;
}>, Schema.Struct<{
    readonly bytes: Binary.Bytes;
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
    readonly scaleFactor: Schema.Finite;
}>, typeof SewedError, never, never> | Rpc.Rpc<"find", Schema.Struct<{
    text: Schema.String;
    options: Schema.optionalKey<Schema.Struct<{
        readonly forward: Schema.optionalKey<Schema.Boolean>;
        readonly matchCase: Schema.optionalKey<Schema.Boolean>;
    }>>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly activeMatchOrdinal: Schema.Int;
    readonly matches: Schema.Int;
    readonly selectionArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly finalUpdate: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"findNext", Schema.Struct<{
    forward: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"focus", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"forward", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"history", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly index: Schema.Int;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly url: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"navigate", Schema.Struct<{
    url: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setZoom", Schema.Struct<{
    factor: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"idle">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"loading">;
    readonly url: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"gone">;
    readonly reason: Schema.String;
    readonly exitCode: Schema.Finite;
}>]>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"stopFind", Schema.Struct<{
    action: Schema.Literals<readonly ["clearSelection", "keepSelection", "activateSelection"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"zoom", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly factor: Schema.Finite;
}>, typeof SewedError>, Schema.Never, never, never>>;
/**
 * A guest's hosted tab as one capability. Like a window's controls, it belongs to an owner:
 * `GuestView.native(guest, policy)` in `sewed/main` carries the host policy for one acquired view,
 * and `Capability.client` reaches it from a document. The policy still decides `navigate` and
 * `capture`; everything else on the protocol is always served.
 */
export declare const tab: Capability.Capability<Rpc.Rpc<"back", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"capture", Schema.Struct<{
    readonly rect: Schema.optionalKey<Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>>;
    readonly stayHidden: Schema.optionalKey<Schema.Boolean>;
    readonly stayAwake: Schema.optionalKey<Schema.Boolean>;
}>, Schema.Struct<{
    readonly bytes: Binary.Bytes;
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
    readonly scaleFactor: Schema.Finite;
}>, typeof SewedError, never, never> | Rpc.Rpc<"find", Schema.Struct<{
    text: Schema.String;
    options: Schema.optionalKey<Schema.Struct<{
        readonly forward: Schema.optionalKey<Schema.Boolean>;
        readonly matchCase: Schema.optionalKey<Schema.Boolean>;
    }>>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly activeMatchOrdinal: Schema.Int;
    readonly matches: Schema.Int;
    readonly selectionArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly finalUpdate: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"findNext", Schema.Struct<{
    forward: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"focus", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"forward", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"history", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly index: Schema.Int;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly url: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"navigate", Schema.Struct<{
    url: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setZoom", Schema.Struct<{
    factor: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"idle">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"loading">;
    readonly url: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"gone">;
    readonly reason: Schema.String;
    readonly exitCode: Schema.Finite;
}>]>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"stopFind", Schema.Struct<{
    action: Schema.Literals<readonly ["clearSelection", "keepSelection", "activateSelection"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"zoom", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly factor: Schema.Finite;
}>, typeof SewedError>, Schema.Never, never, never>, "sewed/binding/guest-tab">;
/** A view that hosts a page the application does not own: no preload, no bridge, no bindings. */
export interface Handle<A extends Automation.Declaration = {}, Core = unknown> extends Attachable {
    readonly id: string;
    readonly webContents: Core;
    readonly navigate: (url: string) => Effect.Effect<void, SewedError, MainContext>;
    readonly blocked: Stream.Stream<WebContents.Blocked, SewedError, MainContext>;
    /** The downloads this guest's page started and a decider accepted; a denied one never appears here. */
    readonly downloads: Stream.Stream<Download.Handle, SewedError, MainContext>;
    readonly automation: Automation.Of<A>;
    readonly close: Effect.Effect<void, SewedError, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
//# sourceMappingURL=GuestView.d.ts.map