import { Effect, Scope } from "effect";
import { Rpc, RpcServer } from "effect/rpc";
import type { RpcGroup } from "effect/rpc";
import { SewedError } from "./SewedError.ts";
import { type Connection } from "./internal/Transport.ts";
export type HandlerServices<Rpcs extends Rpc.Any> = Rpc.ToHandler<Rpcs> | Rpc.Middleware<Rpcs> | Rpc.ServicesServer<Rpcs>;
export declare const server: <Rpcs extends Rpc.Any>(protocol: RpcGroup.RpcGroup<Rpcs>, options?: {
    readonly ownerId?: string;
    readonly maxPendingBytes?: number;
}) => Effect.Effect<{
    accept(connection: Connection): void;
}, never, Scope.Scope | Exclude<Exclude<Rpc.ToHandler<Rpcs>, RpcServer.Protocol>, never> | Rpc.ServicesServer<Rpcs>>;
export declare const scopedConnection: (connect: () => Connection) => Effect.Effect<Connection, SewedError, Scope.Scope>;
//# sourceMappingURL=Runtime.d.ts.map