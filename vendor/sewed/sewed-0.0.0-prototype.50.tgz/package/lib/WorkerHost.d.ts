import { Effect, Scope } from "effect";
import type { Rpc } from "effect/rpc";
import { type Bound, type Complete, type Owner } from "./Binding.ts";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
import type { Entry } from "./Worker.ts";
export { entry } from "./Worker.ts";
export type { Definition, Entry } from "./Worker.ts";
export interface Handle<Rpcs extends Rpc.Any> extends Owner<Rpcs> {
    readonly shutdown: Effect.Effect<void, never, MainContext>;
    readonly terminate: Effect.Effect<void, never, MainContext>;
    readonly awaitExit: Effect.Effect<number, never, MainContext>;
}
export declare const spawn: <Rpcs extends Rpc.Any, Keys extends string, const B extends readonly Bound<Keys>[] = []>(entry: Entry<Rpcs, Keys> & Complete<Keys, B>, options?: {
    readonly bindings: B;
}) => Effect.Effect<Handle<Rpcs>, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=WorkerHost.d.ts.map