import { Schema } from "effect";
import * as Binary from "./Binary.ts";
/**
 * A path or already-encoded image bytes (PNG, JPEG, and the other formats `nativeImage` reads) —
 * the one schema every icon door takes: a window's `setIcon` and `setOverlayIcon` in this wave,
 * the tray and the dock in the next.
 */
export declare const Source: Schema.Union<readonly [Schema.String, Binary.Bytes]>;
export type Source = typeof Source.Type;
/**
 * A decoded bitmap: BGRA, 4 bytes per pixel, row-major, premultiplied by alpha, exactly as
 * Electron's `nativeImage.toBitmap` lays them out — a color channel above a pixel's own alpha
 * comes back clamped down to it (a hand-built `[200, 100, 50, 128]` BGRA pixel round-trips
 * through `toBitmap`/`createFromBitmap` as `[128, 100, 50, 128]`). `compose` only ever copies
 * bytes, never blends them, so this bites a consumer who hand-builds a translucent bitmap and
 * later decodes it back through `nativeImage`, not `compose` itself. `bytes.byteLength` must
 * equal `width * height * 4`; nothing else about the pixel format is checked here, and nothing
 * here touches Electron — a `Bitmap` is inert data a test can build by hand.
 */
export declare const Bitmap: Schema.Struct<{
    readonly width: Schema.Int;
    readonly height: Schema.Int;
    readonly bytes: Binary.Bytes;
}>;
export type Bitmap = typeof Bitmap.Type;
/** One bitmap placed at a pixel offset onto a base; `compose` clips it at the base's own edges. */
export declare const Layer: Schema.Struct<{
    readonly bitmap: Schema.Struct<{
        readonly width: Schema.Int;
        readonly height: Schema.Int;
        readonly bytes: Binary.Bytes;
    }>;
    readonly x: Schema.Int;
    readonly y: Schema.Int;
}>;
export type Layer = typeof Layer.Type;
/**
 * Copies each layer's pixels onto a copy of `base` at its pixel offset, clipping whatever falls
 * outside the base's own edges; layers apply in order, so a later one overwrites an earlier one
 * where they overlap. Pure arithmetic over BGRA bytes: no Electron, no blend modes, no rotation,
 * no crop — the consumer's need is a composite screenshot, one capture laid over another.
 *
 * `base` and every layer's `bitmap` are validated against `Bitmap` first, so a wrong byte length
 * fails `Protocol` naming it rather than reading past the end of a buffer. An empty layer list
 * still returns a copy of `base`, never the same object.
 */
export declare const compose: (base: Bitmap, layers: readonly Layer[]) => Bitmap;
/** A bitmap's width over its height. */
export declare const aspectRatio: (bitmap: Bitmap) => number;
//# sourceMappingURL=Image.d.ts.map