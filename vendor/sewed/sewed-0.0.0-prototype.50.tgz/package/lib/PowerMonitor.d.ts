import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export declare const ThermalState: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
export type ThermalState = typeof ThermalState.Type;
export declare const IdleState: Schema.Literals<readonly ["active", "idle", "locked", "unknown"]>;
export type IdleState = typeof IdleState.Type;
export declare const IdleThreshold: Schema.Int;
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"suspend">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"resume">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"power-source">;
    readonly onBattery: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"screen">;
    readonly locked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"user">;
    readonly active: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"shutdown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"thermal">;
    readonly state: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"speed-limit">;
    readonly limit: Schema.Finite;
}>]>;
export type Event = typeof Event.Type;
export declare const State: Schema.Struct<{
    readonly onBattery: Schema.Boolean;
    readonly idleSeconds: Schema.Finite;
    readonly idleState: Schema.Literals<readonly ["active", "idle", "locked", "unknown"]>;
    readonly thermal: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>;
export type State = typeof State.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"events", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"suspend">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"resume">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"power-source">;
    readonly onBattery: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"screen">;
    readonly locked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"user">;
    readonly active: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"shutdown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"thermal">;
    readonly state: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"speed-limit">;
    readonly limit: Schema.Finite;
}>]>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"state", Schema.Struct<{
    idleThresholdSeconds: Schema.Int;
}>, Schema.Struct<{
    readonly onBattery: Schema.Boolean;
    readonly idleSeconds: Schema.Finite;
    readonly idleState: Schema.Literals<readonly ["active", "idle", "locked", "unknown"]>;
    readonly thermal: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>, typeof SewedError, never, never>>;
/**
 * The whole power surface as one capability: `PowerMonitor.native` in `sewed/main` provides it,
 * `Capability.client` reaches it from a document, and `Testing.PowerMonitor.memory` stands in for
 * tests. The surface carries no policy; the idle threshold is checked on every call.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"events", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"suspend">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"resume">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"power-source">;
    readonly onBattery: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"screen">;
    readonly locked: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"user">;
    readonly active: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"shutdown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"thermal">;
    readonly state: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"speed-limit">;
    readonly limit: Schema.Finite;
}>]>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"state", Schema.Struct<{
    idleThresholdSeconds: Schema.Int;
}>, Schema.Struct<{
    readonly onBattery: Schema.Boolean;
    readonly idleSeconds: Schema.Finite;
    readonly idleState: Schema.Literals<readonly ["active", "idle", "locked", "unknown"]>;
    readonly thermal: Schema.Literals<readonly ["unknown", "nominal", "fair", "serious", "critical"]>;
}>, typeof SewedError, never, never>, "sewed/binding/power-monitor">;
//# sourceMappingURL=PowerMonitor.d.ts.map