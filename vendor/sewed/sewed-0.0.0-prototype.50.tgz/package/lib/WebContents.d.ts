import { Schema } from "effect";
import type { Effect, Stream } from "effect";
import * as Binary from "./Binary.ts";
import type { MainContext } from "./RuntimeContext.ts";
import type { SewedError } from "./SewedError.ts";
export declare const DevToolsOptions: Schema.Struct<{
    readonly mode: Schema.optionalKey<Schema.Literals<readonly ["left", "right", "bottom", "undocked", "detach"]>>;
    readonly activate: Schema.optionalKey<Schema.Boolean>;
}>;
export type DevToolsOptions = typeof DevToolsOptions.Type;
/** What `openDevToolsIn` takes: the hosting view decides where DevTools are, so no `mode`. */
export declare const DevToolsHostOptions: Schema.Struct<{
    readonly activate: Schema.optionalKey<Schema.Boolean>;
}>;
export type DevToolsHostOptions = typeof DevToolsHostOptions.Type;
export declare const State: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"idle">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"loading">;
    readonly url: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"gone">;
    readonly reason: Schema.String;
    readonly exitCode: Schema.Finite;
}>]>;
export type State = typeof State.Type;
/**
 * What `back`, `forward`, and `go` answer once the navigation they started has settled — the
 * state stream's `Ready` or `Failed` branch, never `idle`, `loading`, or `gone`. A history move
 * cannot itself crash the renderer or leave the page unstarted.
 */
export declare const Settled: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>;
export type Settled = typeof Settled.Type;
export declare const Responsiveness: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"unknown">;
}>, Schema.Struct<{
    readonly status: Schema.Literals<readonly ["responsive", "unresponsive"]>;
    readonly processId: Schema.Int;
}>]>;
export type Responsiveness = typeof Responsiveness.Type;
/** A console message a page logged; the stream is main-only and never served to renderers. */
export declare const ConsoleMessage: Schema.Struct<{
    readonly level: Schema.Literals<readonly ["debug", "info", "warning", "error"]>;
    readonly message: Schema.String;
    readonly lineNumber: Schema.Finite;
    readonly sourceId: Schema.String;
}>;
export type ConsoleMessage = typeof ConsoleMessage.Type;
/** A window, webview, navigation, redirect, or download a policy denied. */
export declare const Blocked: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["navigation", "redirect", "popup", "webview", "download"]>;
    readonly url: Schema.String;
}>;
export type Blocked = typeof Blocked.Type;
/** A named page size or custom dimensions in microns. */
export declare const PrintPageSize: Schema.Union<readonly [Schema.Literals<readonly ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "Legal", "Letter", "Tabloid"]>, Schema.Struct<{
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
}>]>;
export type PrintPageSize = typeof PrintPageSize.Type;
/** A named page size, including Ledger, or custom dimensions in inches. */
export declare const PdfPageSize: Schema.Union<readonly [Schema.Literals<readonly ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "Legal", "Letter", "Tabloid", "Ledger"]>, Schema.Struct<{
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
}>]>;
export type PdfPageSize = typeof PdfPageSize.Type;
export declare const PrintOptions: Schema.Struct<{
    readonly silent: Schema.optionalKey<Schema.Boolean>;
    readonly printBackground: Schema.optionalKey<Schema.Boolean>;
    readonly deviceName: Schema.optionalKey<Schema.String>;
    readonly color: Schema.optionalKey<Schema.Boolean>;
    readonly landscape: Schema.optionalKey<Schema.Boolean>;
    readonly scaleFactor: Schema.optionalKey<Schema.Finite>;
    readonly pagesPerSheet: Schema.optionalKey<Schema.Int>;
    readonly collate: Schema.optionalKey<Schema.Boolean>;
    readonly copies: Schema.optionalKey<Schema.Int>;
    readonly pageRanges: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly from: Schema.Int;
        readonly to: Schema.Int;
    }>>>;
    readonly duplexMode: Schema.optionalKey<Schema.Literals<readonly ["simplex", "shortEdge", "longEdge"]>>;
    readonly header: Schema.optionalKey<Schema.String>;
    readonly footer: Schema.optionalKey<Schema.String>;
    readonly pageSize: Schema.optionalKey<Schema.Union<readonly [Schema.Literals<readonly ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "Legal", "Letter", "Tabloid"]>, Schema.Struct<{
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>]>>;
    readonly margins: Schema.optionalKey<Schema.Struct<{
        readonly marginType: Schema.optionalKey<Schema.Literals<readonly ["default", "none", "printableArea", "custom"]>>;
        readonly top: Schema.optionalKey<Schema.Int>;
        readonly bottom: Schema.optionalKey<Schema.Int>;
        readonly left: Schema.optionalKey<Schema.Int>;
        readonly right: Schema.optionalKey<Schema.Int>;
    }>>;
}>;
export type PrintOptions = typeof PrintOptions.Type;
export declare const PdfOptions: Schema.Struct<{
    readonly landscape: Schema.optionalKey<Schema.Boolean>;
    readonly displayHeaderFooter: Schema.optionalKey<Schema.Boolean>;
    readonly printBackground: Schema.optionalKey<Schema.Boolean>;
    readonly scale: Schema.optionalKey<Schema.Finite>;
    readonly pageSize: Schema.optionalKey<Schema.Union<readonly [Schema.Literals<readonly ["A0", "A1", "A2", "A3", "A4", "A5", "A6", "Legal", "Letter", "Tabloid", "Ledger"]>, Schema.Struct<{
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>]>>;
    readonly margins: Schema.optionalKey<Schema.Struct<{
        readonly top: Schema.optionalKey<Schema.Finite>;
        readonly bottom: Schema.optionalKey<Schema.Finite>;
        readonly left: Schema.optionalKey<Schema.Finite>;
        readonly right: Schema.optionalKey<Schema.Finite>;
    }>>;
    readonly pageRanges: Schema.optionalKey<Schema.String>;
    readonly headerTemplate: Schema.optionalKey<Schema.String>;
    readonly footerTemplate: Schema.optionalKey<Schema.String>;
    readonly preferCSSPageSize: Schema.optionalKey<Schema.Boolean>;
    readonly generateTaggedPDF: Schema.optionalKey<Schema.Boolean>;
    readonly generateDocumentOutline: Schema.optionalKey<Schema.Boolean>;
}>;
export type PdfOptions = typeof PdfOptions.Type;
export declare const CaptureOptions: Schema.Struct<{
    readonly rect: Schema.optionalKey<Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>>;
    readonly stayHidden: Schema.optionalKey<Schema.Boolean>;
    readonly stayAwake: Schema.optionalKey<Schema.Boolean>;
}>;
export type CaptureOptions = typeof CaptureOptions.Type;
/**
 * What a capture answers instead of bare bytes: the PNG, its pixel size as the native image
 * itself reports it, and the display's scale factor for the area it captured. `width` and
 * `height` are always pixels, never DIPs — a consumer who wants bytes alone reads one field.
 */
export declare const Capture: Schema.Struct<{
    readonly bytes: Binary.Bytes;
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
    readonly scaleFactor: Schema.Finite;
}>;
export type Capture = typeof Capture.Type;
export declare const ZoomFactor: Schema.Finite;
export declare const Zoom: Schema.Struct<{
    readonly factor: Schema.Finite;
}>;
export type Zoom = typeof Zoom.Type;
export declare const Audio: Schema.Struct<{
    readonly muted: Schema.Boolean;
    readonly audible: Schema.Boolean;
}>;
export type Audio = typeof Audio.Type;
export declare const FindText: Schema.String;
export declare const FindOptions: Schema.Struct<{
    readonly forward: Schema.optionalKey<Schema.Boolean>;
    readonly matchCase: Schema.optionalKey<Schema.Boolean>;
}>;
export type FindOptions = typeof FindOptions.Type;
export declare const FindResult: Schema.Struct<{
    readonly activeMatchOrdinal: Schema.Int;
    readonly matches: Schema.Int;
    readonly selectionArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly finalUpdate: Schema.Boolean;
}>;
export type FindResult = typeof FindResult.Type;
export declare const FindStop: Schema.Literals<readonly ["clearSelection", "keepSelection", "activateSelection"]>;
export type FindStop = typeof FindStop.Type;
/** One search over a document: its results end when it stops or a new search replaces it. */
export interface Search {
    readonly results: Stream.Stream<FindResult, SewedError, MainContext>;
    readonly next: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
    readonly stop: (action?: FindStop) => Effect.Effect<void, SewedError, MainContext>;
}
export declare const HistoryEntry: Schema.Struct<{
    readonly url: Schema.String;
    readonly title: Schema.String;
}>;
export type HistoryEntry = typeof HistoryEntry.Type;
export declare const History: Schema.Struct<{
    readonly index: Schema.Int;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly url: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
}>;
export type History = typeof History.Type;
export declare const SaveType: Schema.Literals<readonly ["HTMLOnly", "HTMLComplete", "MHTML"]>;
export type SaveType = typeof SaveType.Type;
export declare const StyleOptions: Schema.Struct<{
    readonly origin: Schema.optionalKey<Schema.Literals<readonly ["author", "user"]>>;
}>;
export type StyleOptions = typeof StyleOptions.Type;
/**
 * `webContents.current`'s own answer: the same six values its streams (`state`, `history`,
 * `title`, `favicons`, `zoom`, `audio`) last published, read fresh at the callback rather than
 * waited for — the one-shot precedent `internal/Window.ts`'s own `current` already ships.
 */
export declare const Snapshot: Schema.Struct<{
    readonly state: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"idle">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"loading">;
        readonly url: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"ready">;
        readonly url: Schema.String;
        readonly processId: Schema.Finite;
        readonly httpStatus: Schema.Finite;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"failed">;
        readonly url: Schema.String;
        readonly code: Schema.Finite;
        readonly description: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"gone">;
        readonly reason: Schema.String;
        readonly exitCode: Schema.Finite;
    }>]>;
    readonly history: Schema.Struct<{
        readonly index: Schema.Int;
        readonly entries: Schema.$Array<Schema.Struct<{
            readonly url: Schema.String;
            readonly title: Schema.String;
        }>>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
    }>;
    readonly title: Schema.String;
    readonly favicons: Schema.$Array<Schema.String>;
    readonly zoom: Schema.Struct<{
        readonly factor: Schema.Finite;
    }>;
    readonly audio: Schema.Struct<{
        readonly muted: Schema.Boolean;
        readonly audible: Schema.Boolean;
    }>;
}>;
export type Snapshot = typeof Snapshot.Type;
/** What the page says can be done with the selection or field a context menu was opened on. */
export declare const EditFlags: Schema.Struct<{
    readonly canUndo: Schema.Boolean;
    readonly canRedo: Schema.Boolean;
    readonly canCut: Schema.Boolean;
    readonly canCopy: Schema.Boolean;
    readonly canPaste: Schema.Boolean;
    readonly canDelete: Schema.Boolean;
    readonly canSelectAll: Schema.Boolean;
}>;
export type EditFlags = typeof EditFlags.Type;
/** A request for a context menu, with what was under the pointer. Coordinates are in the page. */
export declare const ContextMenu: Schema.Struct<{
    readonly kind: Schema.Literal<"context-menu">;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly pageUrl: Schema.String;
    readonly frameUrl: Schema.String;
    readonly linkUrl: Schema.String;
    readonly linkText: Schema.String;
    readonly sourceUrl: Schema.String;
    readonly mediaType: Schema.String;
    readonly hasImageContents: Schema.Boolean;
    readonly isEditable: Schema.Boolean;
    readonly selectionText: Schema.String;
    readonly misspelledWord: Schema.String;
    readonly dictionarySuggestions: Schema.$Array<Schema.String>;
    readonly source: Schema.String;
    readonly editFlags: Schema.Struct<{
        readonly canUndo: Schema.Boolean;
        readonly canRedo: Schema.Boolean;
        readonly canCut: Schema.Boolean;
        readonly canCopy: Schema.Boolean;
        readonly canPaste: Schema.Boolean;
        readonly canDelete: Schema.Boolean;
        readonly canSelectAll: Schema.Boolean;
    }>;
}>;
export type ContextMenu = typeof ContextMenu.Type;
/** One frame of the page, named by the process it runs in and its routing id inside it. */
export declare const FrameIdentity: Schema.Struct<{
    readonly processId: Schema.Finite;
    readonly routingId: Schema.Finite;
    readonly isMainFrame: Schema.Boolean;
}>;
export type FrameIdentity = typeof FrameIdentity.Type;
/**
 * Something the page did that main may want to react to. Each observer owns its own native
 * listeners, so a web contents nobody observes pays nothing for these.
 */
export declare const PageEvent: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"context-menu">;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly pageUrl: Schema.String;
    readonly frameUrl: Schema.String;
    readonly linkUrl: Schema.String;
    readonly linkText: Schema.String;
    readonly sourceUrl: Schema.String;
    readonly mediaType: Schema.String;
    readonly hasImageContents: Schema.Boolean;
    readonly isEditable: Schema.Boolean;
    readonly selectionText: Schema.String;
    readonly misspelledWord: Schema.String;
    readonly dictionarySuggestions: Schema.$Array<Schema.String>;
    readonly source: Schema.String;
    readonly editFlags: Schema.Struct<{
        readonly canUndo: Schema.Boolean;
        readonly canRedo: Schema.Boolean;
        readonly canCut: Schema.Boolean;
        readonly canCopy: Schema.Boolean;
        readonly canPaste: Schema.Boolean;
        readonly canDelete: Schema.Boolean;
        readonly canSelectAll: Schema.Boolean;
    }>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"cursor">;
    readonly type: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"target-url">;
    readonly url: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"theme-color">;
    readonly color: Schema.NullOr<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"html-full-screen">;
    readonly active: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"dom-ready">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"preload-error">;
    readonly path: Schema.String;
    readonly message: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"frame">;
    readonly change: Schema.Literals<readonly ["created", "navigated", "loaded"]>;
    readonly frame: Schema.Struct<{
        readonly processId: Schema.Finite;
        readonly routingId: Schema.Finite;
        readonly isMainFrame: Schema.Boolean;
    }>;
    /** The frame's URL, where Electron reports one: on `created` and `navigated`. */
    readonly url: Schema.optionalKey<Schema.String>;
    /** The response status of a `navigated` frame; `-1` for a navigation that is not HTTP. */
    readonly httpStatus: Schema.optionalKey<Schema.Finite>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"devtools">;
    readonly change: Schema.Literals<readonly ["opened", "closed", "focused"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"devtools-open-url">;
    readonly url: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"devtools-reload-page">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"devtools-search-query">;
    readonly query: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"content-bounds-updated">;
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"preferred-size">;
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"input">;
    readonly type: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"webview-attached">;
    readonly nativeId: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"frame-will-navigate">;
    readonly url: Schema.String;
    readonly isMainFrame: Schema.Boolean;
    readonly isSameDocument: Schema.Boolean;
}>]>;
export type PageEvent = typeof PageEvent.Type;
export declare const DevToolsState: Schema.Struct<{
    readonly opened: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly title: Schema.String;
}>;
export type DevToolsState = typeof DevToolsState.Type;
/** What the page is doing right now, read once. */
export declare const Activity: Schema.Struct<{
    readonly loading: Schema.Boolean;
    readonly waitingForResponse: Schema.Boolean;
    readonly crashed: Schema.Boolean;
    readonly beingCaptured: Schema.Boolean;
    readonly backgroundThrottling: Schema.Boolean;
}>;
export type Activity = typeof Activity.Type;
/** Emulates a device's screen for the page, as DevTools' device toolbar does. */
export declare const DeviceEmulation: Schema.Struct<{
    readonly screenPosition: Schema.Literals<readonly ["desktop", "mobile"]>;
    readonly screenSize: Schema.Struct<{
        readonly width: Schema.Int;
        readonly height: Schema.Int;
    }>;
    readonly viewPosition: Schema.Struct<{
        readonly x: Schema.Int;
        readonly y: Schema.Int;
    }>;
    /** `0` keeps the display's own scale factor. */
    readonly deviceScaleFactor: Schema.Finite;
    readonly viewSize: Schema.Struct<{
        readonly width: Schema.Int;
        readonly height: Schema.Int;
    }>;
    readonly scale: Schema.Finite;
}>;
export type DeviceEmulation = typeof DeviceEmulation.Type;
/** An editing command the focused frame runs, as a menu item or a key press would. */
export declare const EditCommand: Schema.Literals<readonly ["undo", "redo", "cut", "copy", "paste", "pasteAndMatchStyle", "delete", "selectAll", "unselect", "centerSelection", "scrollToTop", "scrollToBottom"]>;
export type EditCommand = typeof EditCommand.Type;
/** How far to move the selection's ends, in characters; a negative number moves backwards. */
export declare const SelectionAdjustment: Schema.Struct<{
    readonly start: Schema.optionalKey<Schema.Int>;
    readonly end: Schema.optionalKey<Schema.Int>;
}>;
export type SelectionAdjustment = typeof SelectionAdjustment.Type;
export declare const PagePoint: Schema.Struct<{
    readonly x: Schema.Int;
    readonly y: Schema.Int;
}>;
export type PagePoint = typeof PagePoint.Type;
/** Pinch-zoom limits, as scale factors: `1` to `1` disables pinch zoom. */
export declare const VisualZoomLimits: Schema.Struct<{
    readonly minimum: Schema.Finite;
    readonly maximum: Schema.Finite;
}>;
export type VisualZoomLimits = typeof VisualZoomLimits.Type;
export declare const ImageAnimationPolicy: Schema.Literals<readonly ["animate", "animateOnce", "noAnimation"]>;
export type ImageAnimationPolicy = typeof ImageAnimationPolicy.Type;
/**
 * One rendered frame: the whole frame as a BGRA bitmap, and the rectangle that changed since the
 * frame before, in device-independent pixels.
 */
export declare const Frame: Schema.Struct<{
    readonly bitmap: Schema.Struct<{
        readonly width: Schema.Int;
        readonly height: Schema.Int;
        readonly bytes: Binary.Bytes;
    }>;
    readonly dirty: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
}>;
export type Frame = typeof Frame.Type;
export declare const FrameOptions: Schema.Struct<{
    /**
     * For a page that is not rendered offscreen: deliver only the rectangle that changed, as its
     * own bitmap, instead of the whole frame.
     */
    readonly onlyDirty: Schema.optionalKey<Schema.Boolean>;
}>;
export type FrameOptions = typeof FrameOptions.Type;
/** Frames per second for an offscreen page. */
export declare const FrameRate: Schema.Int;
export type FrameRate = typeof FrameRate.Type;
/** How an offscreen page is rendering. */
export declare const Painting: Schema.Struct<{
    readonly offscreen: Schema.Boolean;
    readonly painting: Schema.Boolean;
    readonly frameRate: Schema.Finite;
}>;
export type Painting = typeof Painting.Type;
/** Files dragged out of a page, by absolute path, and the image shown under the pointer. */
export declare const Drag: Schema.Struct<{
    readonly files: Schema.NonEmptyArray<Schema.String>;
    readonly icon: Schema.Union<readonly [Schema.String, Binary.Bytes]>;
}>;
export type Drag = typeof Drag.Type;
/** A shared worker the page started. */
export declare const SharedWorker: Schema.Struct<{
    readonly id: Schema.String;
    readonly url: Schema.String;
}>;
export type SharedWorker = typeof SharedWorker.Type;
/** A printer the system offers. */
export declare const Printer: Schema.Struct<{
    readonly name: Schema.String;
    readonly displayName: Schema.String;
    readonly description: Schema.String;
}>;
export type Printer = typeof Printer.Type;
export declare const WebRtcIpHandlingPolicy: Schema.Literals<readonly ["default", "default_public_interface_only", "default_public_and_private_interfaces", "disable_non_proxied_udp"]>;
export type WebRtcIpHandlingPolicy = typeof WebRtcIpHandlingPolicy.Type;
/** The UDP ports WebRTC may use; both zero lifts the restriction. */
export declare const UdpPortRange: Schema.Struct<{
    readonly min: Schema.Int;
    readonly max: Schema.Int;
}>;
export type UdpPortRange = typeof UdpPortRange.Type;
export declare const WebRtc: Schema.Struct<{
    readonly ipHandlingPolicy: Schema.String;
    readonly udpPortRange: Schema.Struct<{
        readonly min: Schema.Int;
        readonly max: Schema.Int;
    }>;
}>;
export type WebRtc = typeof WebRtc.Type;
/** One frame of the page as it is now. `parent` is the routing id of the frame that embeds it. */
export declare const FrameInfo: Schema.Struct<{
    readonly processId: Schema.Finite;
    readonly routingId: Schema.Finite;
    readonly frameTreeNodeId: Schema.Finite;
    readonly token: Schema.String;
    readonly osProcessId: Schema.Finite;
    readonly isMainFrame: Schema.Boolean;
    readonly parent: Schema.NullOr<Schema.Finite>;
    readonly url: Schema.String;
    readonly origin: Schema.String;
    readonly name: Schema.String;
    readonly visibilityState: Schema.String;
}>;
export type FrameInfo = typeof FrameInfo.Type;
/** How a page's zoom is scoped: per origin (`default`), per page, set by the application, or off. */
export declare const ZoomMode: Schema.Literals<readonly ["default", "isolated", "manual", "disabled"]>;
export type ZoomMode = typeof ZoomMode.Type;
/** Chromium's zoom level: `0` is 100%, and each step up or down scales by 20%. */
export declare const ZoomLevel: Schema.Finite;
export type ZoomLevel = typeof ZoomLevel.Type;
//# sourceMappingURL=WebContents.d.ts.map