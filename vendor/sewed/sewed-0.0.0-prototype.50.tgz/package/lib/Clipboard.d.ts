import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Binary from "./Binary.ts";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export declare const Format: Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>;
export type Format = typeof Format.Type;
/**
 * PNG bytes, checked by signature so malformed images never reach the clipboard.
 *
 * A check is a runtime filter and rebuilds the same schema type, so naming that type here loses
 * nothing and keeps every protocol carrying this field readable.
 */
export declare const Png: Binary.Bytes;
export declare const Content: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"text">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"html">;
    readonly html: Schema.String;
    readonly text: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"rtf">;
    readonly rtf: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"image">;
    readonly png: Binary.Bytes;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"bookmark">;
    readonly title: Schema.String;
    readonly url: Schema.String;
}>]>;
export type Content = typeof Content.Type;
/** Formats this capability may read and write; anything omitted is denied. */
export declare const Policy: Schema.Struct<{
    readonly read: Schema.$Array<Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>>;
    readonly write: Schema.$Array<Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>>;
}>;
export type Policy = typeof Policy.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"clear", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"formats", Schema.Void, Schema.$Array<Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>>, typeof SewedError, never, never> | Rpc.Rpc<"read", Schema.Struct<{
    format: Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>;
}>, Schema.NullOr<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"text">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"html">;
    readonly html: Schema.String;
    readonly text: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"rtf">;
    readonly rtf: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"image">;
    readonly png: Binary.Bytes;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"bookmark">;
    readonly title: Schema.String;
    readonly url: Schema.String;
}>]>>, typeof SewedError, never, never> | Rpc.Rpc<"write", Schema.Struct<{
    content: Schema.Union<readonly [Schema.Struct<{
        readonly kind: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"html">;
        readonly html: Schema.String;
        readonly text: Schema.optionalKey<Schema.String>;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"rtf">;
        readonly rtf: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"image">;
        readonly png: Binary.Bytes;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"bookmark">;
        readonly title: Schema.String;
        readonly url: Schema.String;
    }>]>;
}>, Schema.Void, typeof SewedError, never, never>>;
/**
 * The whole clipboard surface as one capability: `Clipboard.native` in `sewed/main` carries the
 * format policy, `Capability.client` reaches it from a document, and `Testing.Clipboard.memory`
 * stands in for tests.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"clear", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"formats", Schema.Void, Schema.$Array<Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>>, typeof SewedError, never, never> | Rpc.Rpc<"read", Schema.Struct<{
    format: Schema.Literals<readonly ["text", "html", "rtf", "image", "bookmark"]>;
}>, Schema.NullOr<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"text">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"html">;
    readonly html: Schema.String;
    readonly text: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"rtf">;
    readonly rtf: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"image">;
    readonly png: Binary.Bytes;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"bookmark">;
    readonly title: Schema.String;
    readonly url: Schema.String;
}>]>>, typeof SewedError, never, never> | Rpc.Rpc<"write", Schema.Struct<{
    content: Schema.Union<readonly [Schema.Struct<{
        readonly kind: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"html">;
        readonly html: Schema.String;
        readonly text: Schema.optionalKey<Schema.String>;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"rtf">;
        readonly rtf: Schema.String;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"image">;
        readonly png: Binary.Bytes;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"bookmark">;
        readonly title: Schema.String;
        readonly url: Schema.String;
    }>]>;
}>, Schema.Void, typeof SewedError, never, never>, "sewed/binding/clipboard">;
//# sourceMappingURL=Clipboard.d.ts.map