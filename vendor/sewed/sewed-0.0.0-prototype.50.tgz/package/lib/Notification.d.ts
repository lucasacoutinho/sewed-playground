import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export declare const Urgency: Schema.Literals<readonly ["normal", "critical", "low"]>;
export type Urgency = typeof Urgency.Type;
export declare const Timeout: Schema.Literals<readonly ["default", "never"]>;
export type Timeout = typeof Timeout.Type;
export declare const Action: Schema.Struct<{
    readonly id: Schema.String;
    readonly text: Schema.String;
}>;
export type Action = typeof Action.Type;
export declare const Options: Schema.Struct<{
    readonly title: Schema.String;
    readonly body: Schema.optionalKey<Schema.String>;
    readonly subtitle: Schema.optionalKey<Schema.String>;
    readonly silent: Schema.optionalKey<Schema.Boolean>;
    readonly urgency: Schema.optionalKey<Schema.Literals<readonly ["normal", "critical", "low"]>>;
    readonly timeout: Schema.optionalKey<Schema.Literals<readonly ["default", "never"]>>;
    readonly icon: Schema.optionalKey<Schema.String>;
    readonly actions: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>>>;
    readonly reply: Schema.optionalKey<Schema.Struct<{
        readonly placeholder: Schema.String;
    }>>;
    readonly closeButtonText: Schema.optionalKey<Schema.String>;
    /** An identifier that survives the notification object, on macOS and Windows. */
    readonly id: Schema.optionalKey<Schema.String>;
    /** Groups notifications in Notification Center and the Action Center. */
    readonly groupId: Schema.optionalKey<Schema.String>;
    /** The header a Windows group is shown under. */
    readonly groupTitle: Schema.optionalKey<Schema.String>;
    /** The name of a sound to play, on macOS. */
    readonly sound: Schema.optionalKey<Schema.String>;
    /** A whole Windows toast as XML, replacing the fields above. */
    readonly toastXml: Schema.optionalKey<Schema.String>;
}>;
export type Options = typeof Options.Type;
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"shown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"clicked">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"action">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"replied">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"closed">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"failed">;
    readonly message: Schema.String;
}>]>;
export type Event = typeof Event.Type;
/** A notification still delivered in the macOS Notification Center. */
export declare const Delivered: Schema.Struct<{
    readonly id: Schema.String;
    readonly groupId: Schema.String;
    readonly title: Schema.String;
    readonly subtitle: Schema.String;
    readonly body: Schema.String;
}>;
export type Delivered = typeof Delivered.Type;
/**
 * A Windows toast the user acted on, including one that launched the application: the toast's own
 * `arguments` string, the action's index when a button was pressed, and what the user typed.
 */
export declare const Activation: Schema.Struct<{
    readonly type: Schema.String;
    readonly arguments: Schema.String;
    readonly actionIndex: Schema.optionalKey<Schema.Finite>;
    readonly reply: Schema.optionalKey<Schema.String>;
    readonly userInputs: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
}>;
export type Activation = typeof Activation.Type;
/** One request is one notification: its stream ends when the notification closes, and interrupting the request closes it. */
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"show", Schema.Struct<{
    readonly title: Schema.String;
    readonly body: Schema.optionalKey<Schema.String>;
    readonly subtitle: Schema.optionalKey<Schema.String>;
    readonly silent: Schema.optionalKey<Schema.Boolean>;
    readonly urgency: Schema.optionalKey<Schema.Literals<readonly ["normal", "critical", "low"]>>;
    readonly timeout: Schema.optionalKey<Schema.Literals<readonly ["default", "never"]>>;
    readonly icon: Schema.optionalKey<Schema.String>;
    readonly actions: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>>>;
    readonly reply: Schema.optionalKey<Schema.Struct<{
        readonly placeholder: Schema.String;
    }>>;
    readonly closeButtonText: Schema.optionalKey<Schema.String>;
    /** An identifier that survives the notification object, on macOS and Windows. */
    readonly id: Schema.optionalKey<Schema.String>;
    /** Groups notifications in Notification Center and the Action Center. */
    readonly groupId: Schema.optionalKey<Schema.String>;
    /** The header a Windows group is shown under. */
    readonly groupTitle: Schema.optionalKey<Schema.String>;
    /** The name of a sound to play, on macOS. */
    readonly sound: Schema.optionalKey<Schema.String>;
    /** A whole Windows toast as XML, replacing the fields above. */
    readonly toastXml: Schema.optionalKey<Schema.String>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"shown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"clicked">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"action">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"replied">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"closed">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"failed">;
    readonly message: Schema.String;
}>]>, typeof SewedError>, Schema.Never, never, never>>;
/**
 * The whole notification surface as one capability: `Notification.native` in `sewed/main` provides
 * it, `Capability.client` reaches it from a document, and `Testing.Notification.memory` stands in
 * for tests. The surface carries no policy; the options are checked on every call.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"show", Schema.Struct<{
    readonly title: Schema.String;
    readonly body: Schema.optionalKey<Schema.String>;
    readonly subtitle: Schema.optionalKey<Schema.String>;
    readonly silent: Schema.optionalKey<Schema.Boolean>;
    readonly urgency: Schema.optionalKey<Schema.Literals<readonly ["normal", "critical", "low"]>>;
    readonly timeout: Schema.optionalKey<Schema.Literals<readonly ["default", "never"]>>;
    readonly icon: Schema.optionalKey<Schema.String>;
    readonly actions: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>>>;
    readonly reply: Schema.optionalKey<Schema.Struct<{
        readonly placeholder: Schema.String;
    }>>;
    readonly closeButtonText: Schema.optionalKey<Schema.String>;
    /** An identifier that survives the notification object, on macOS and Windows. */
    readonly id: Schema.optionalKey<Schema.String>;
    /** Groups notifications in Notification Center and the Action Center. */
    readonly groupId: Schema.optionalKey<Schema.String>;
    /** The header a Windows group is shown under. */
    readonly groupTitle: Schema.optionalKey<Schema.String>;
    /** The name of a sound to play, on macOS. */
    readonly sound: Schema.optionalKey<Schema.String>;
    /** A whole Windows toast as XML, replacing the fields above. */
    readonly toastXml: Schema.optionalKey<Schema.String>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"shown">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"clicked">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"action">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"replied">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"closed">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"failed">;
    readonly message: Schema.String;
}>]>, typeof SewedError>, Schema.Never, never, never>, "sewed/binding/notification">;
//# sourceMappingURL=Notification.d.ts.map