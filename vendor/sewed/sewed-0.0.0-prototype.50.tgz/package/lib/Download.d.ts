import { Schema } from "effect";
import type { Effect, Stream } from "effect";
import type { MainContext } from "./RuntimeContext.ts";
import type { SewedError } from "./SewedError.ts";
export declare const Options: Schema.Struct<{
    readonly url: Schema.String;
    readonly savePath: Schema.String;
    readonly headers: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
}>;
export type Options = typeof Options.Type;
export declare const State: Schema.Union<readonly [Schema.Struct<{
    readonly receivedBytes: Schema.Finite;
    readonly totalBytes: Schema.Finite;
    readonly percent: Schema.Finite;
    readonly currentBytesPerSecond: Schema.Finite;
    readonly canResume: Schema.Boolean;
    readonly paused: Schema.Boolean;
    readonly status: Schema.Literal<"pending">;
}>, Schema.Struct<{
    readonly receivedBytes: Schema.Finite;
    readonly totalBytes: Schema.Finite;
    readonly percent: Schema.Finite;
    readonly currentBytesPerSecond: Schema.Finite;
    readonly canResume: Schema.Boolean;
    readonly paused: Schema.Boolean;
    readonly status: Schema.Literal<"active">;
    readonly phase: Schema.Literals<readonly ["progressing", "interrupted"]>;
}>, Schema.Struct<{
    readonly receivedBytes: Schema.Finite;
    readonly totalBytes: Schema.Finite;
    readonly percent: Schema.Finite;
    readonly currentBytesPerSecond: Schema.Finite;
    readonly canResume: Schema.Boolean;
    readonly paused: Schema.Boolean;
    readonly status: Schema.Literal<"terminal">;
    readonly outcome: Schema.Literals<readonly ["completed", "cancelled", "interrupted"]>;
}>]>;
export type State = typeof State.Type;
export declare const Outcome: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"completed">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"cancelled">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"interrupted">;
}>]>;
export type Outcome = typeof Outcome.Type;
/** A download a document started; `sourceId` names the Sewed window, view, or guest that started it. */
export declare const Offer: Schema.Struct<{
    readonly url: Schema.String;
    readonly filename: Schema.String;
    readonly mimeType: Schema.String;
    readonly totalBytes: Schema.Finite;
    readonly sourceId: Schema.String;
    /** Every URL the request passed through, the first being the one asked for and the last `url`. */
    readonly urlChain: Schema.$Array<Schema.String>;
    /** Whether a user gesture started the download, as opposed to the page on its own. */
    readonly userGesture: Schema.Boolean;
    /** The response's `Content-Disposition` header, empty when it sent none. */
    readonly contentDisposition: Schema.String;
}>;
export type Offer = typeof Offer.Type;
/**
 * What happens to an offered download: `deny` cancels it, `save` writes to a path without a
 * dialog, and `prompt` lets Electron show its save dialog, with these options when given.
 */
export declare const Decision: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"deny">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"save">;
    readonly path: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"prompt">;
    readonly dialog: Schema.optionalKey<Schema.Struct<{
        readonly title: Schema.optionalKey<Schema.String>;
        readonly defaultPath: Schema.optionalKey<Schema.String>;
        readonly buttonLabel: Schema.optionalKey<Schema.String>;
        readonly filters: Schema.optionalKey<Schema.NonEmptyArray<Schema.Struct<{
            readonly name: Schema.String;
            readonly extensions: Schema.NonEmptyArray<Schema.String>;
        }>>>;
        readonly properties: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["showHiddenFiles", "createDirectory", "treatPackageAsDirectory", "showOverwriteConfirmation", "dontAddToRecent"]>>>;
    }>>;
}>]>;
export type Decision = typeof Decision.Type;
/**
 * What a download knows about its file and its response: where it is being saved, when it started
 * and ended (seconds since the epoch; `endTime` is zero until it ends), and the validators a
 * server needs to resume it. `savePath` is empty until a path is chosen.
 */
export declare const Details: Schema.Struct<{
    readonly savePath: Schema.String;
    readonly startTime: Schema.Finite;
    readonly endTime: Schema.Finite;
    readonly eTag: Schema.String;
    readonly lastModified: Schema.String;
}>;
export type Details = typeof Details.Type;
/**
 * A download interrupted in an earlier run, described well enough to continue it: the partial
 * file at `path`, the URLs it came through, how many bytes are there (`offset`) and how many the
 * whole file has (`length`), and the validators the server sent.
 */
export declare const Resume: Schema.Struct<{
    readonly path: Schema.String;
    readonly urlChain: Schema.NonEmptyArray<Schema.String>;
    readonly mimeType: Schema.optionalKey<Schema.String>;
    readonly offset: Schema.Int;
    readonly length: Schema.Int;
    readonly lastModified: Schema.optionalKey<Schema.String>;
    readonly eTag: Schema.optionalKey<Schema.String>;
    readonly startTime: Schema.optionalKey<Schema.Finite>;
}>;
export type Resume = typeof Resume.Type;
export interface Handle {
    readonly snapshot: Effect.Effect<State, SewedError, MainContext>;
    /** The file and response facts of the download; see {@link Details}. */
    readonly details: Effect.Effect<Details, SewedError, MainContext>;
    readonly progress: Stream.Stream<State, SewedError, MainContext>;
    readonly awaitDone: Effect.Effect<Outcome, SewedError, MainContext>;
    readonly pause: Effect.Effect<void, SewedError, MainContext>;
    readonly resume: Effect.Effect<void, SewedError, MainContext>;
    readonly cancel: Effect.Effect<void, SewedError, MainContext>;
}
//# sourceMappingURL=Download.d.ts.map