import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Binary from "./Binary.ts";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export { Bounds } from "./internal/Geometry.ts";
export declare const BoundsUpdate: Schema.Struct<{
    readonly x: Schema.optionalKey<Schema.Finite>;
    readonly y: Schema.optionalKey<Schema.Finite>;
    readonly width: Schema.optionalKey<Schema.Finite>;
    readonly height: Schema.optionalKey<Schema.Finite>;
}>;
export type BoundsUpdate = typeof BoundsUpdate.Type;
/** A width and height in pixels. As a maximum, zero in a dimension leaves it unlimited. */
export declare const Size: Schema.Struct<{
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
}>;
export type Size = typeof Size.Type;
/** The smallest and largest size the user may resize the window to. */
export declare const SizeLimits: Schema.Struct<{
    readonly minimum: Schema.Struct<{
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly maximum: Schema.Struct<{
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
}>;
export type SizeLimits = typeof SizeLimits.Type;
/** Width divided by height that resizing keeps; zero removes the constraint. */
export declare const AspectRatio: Schema.Finite;
export declare const Opacity: Schema.Finite;
/** Taskbar progress from 0 to 1; a negative value removes the indicator. */
export declare const Progress: Schema.Finite;
export declare const ProgressMode: Schema.Literals<readonly ["none", "normal", "indeterminate", "error", "paused"]>;
export type ProgressMode = typeof ProgressMode.Type;
export declare const AlwaysOnTopLevel: Schema.Literals<readonly ["normal", "floating", "torn-off-menu", "modal-panel", "main-menu", "status", "pop-up-menu", "screen-saver"]>;
export type AlwaysOnTopLevel = typeof AlwaysOnTopLevel.Type;
export declare const State: Schema.Struct<{
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly normalBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    /** The content area, excluding the frame; attached views are positioned within it. */
    readonly contentBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly visible: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly minimized: Schema.Boolean;
    readonly maximized: Schema.Boolean;
    readonly fullScreen: Schema.Boolean;
    /**
     * macOS's pre-Lion fullscreen: it does not create a Space, which is why a window minimizing to
     * the tray leaves it first. Probed on Linux: `setSimpleFullScreen` is honoured there too — both
     * this and `fullScreen` answer true afterwards — so the field is not macOS-only, even though its
     * distinct behavior (no Space) is.
     */
    readonly simpleFullScreen: Schema.Boolean;
    readonly title: Schema.String;
    readonly alwaysOnTop: Schema.Boolean;
    readonly opacity: Schema.Finite;
    readonly resizable: Schema.Boolean;
    readonly movable: Schema.Boolean;
    readonly minimizable: Schema.Boolean;
    readonly maximizable: Schema.Boolean;
    readonly closable: Schema.Boolean;
    readonly fullScreenable: Schema.Boolean;
    readonly menuBarVisible: Schema.Boolean;
    readonly kiosk: Schema.Boolean;
}>;
export type State = typeof State.Type;
/** Colors and height of the native window controls drawn over a frameless window's content. */
export declare const TitleBarOverlay: Schema.Struct<{
    readonly color: Schema.optionalKey<Schema.String>;
    readonly symbolColor: Schema.optionalKey<Schema.String>;
    readonly height: Schema.optionalKey<Schema.Int>;
}>;
export type TitleBarOverlay = typeof TitleBarOverlay.Type;
/**
 * Something that happened to a window that is not part of its state: it is ready to be shown
 * without a flash, a media or browser key was pressed (`app-command`, on Linux and Windows), or the
 * system context menu was requested on its non-client area (on Linux and Windows).
 */
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"ready-to-show">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"persisted-state-restored">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"app-command">;
    readonly command: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["moved", "resized"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["will-move", "will-resize"]>;
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly edge: Schema.optionalKey<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"swipe">;
    readonly direction: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"rotate-gesture">;
    readonly rotation: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["sheet-begin", "sheet-end"]>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"new-window-for-tab">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"session-end">;
    readonly reasons: Schema.$Array<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"system-context-menu">;
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
}>]>;
export type Event = typeof Event.Type;
/** A macOS material drawn behind a window's content; `null` removes it. */
export declare const Vibrancy: Schema.NullOr<Schema.Literals<readonly ["titlebar", "selection", "menu", "popover", "sidebar", "header", "sheet", "window", "hud", "fullscreen-ui", "tooltip", "content", "under-window", "under-page"]>>;
export type Vibrancy = typeof Vibrancy.Type;
/** A Windows 11 system material drawn behind a window's content. */
export declare const BackgroundMaterial: Schema.Literals<readonly ["auto", "none", "mica", "acrylic", "tabbed"]>;
export type BackgroundMaterial = typeof BackgroundMaterial.Type;
/**
 * The Windows frame accent: `true` uses the system accent color, `false` none, a color string
 * that color, and `null` the system default.
 */
export declare const AccentColor: Schema.NullOr<Schema.Union<readonly [Schema.Boolean, Schema.String]>>;
export type AccentColor = typeof AccentColor.Type;
/** How Windows groups and relaunches a window in the taskbar. */
export declare const AppDetails: Schema.Struct<{
    readonly appId: Schema.optionalKey<Schema.String>;
    readonly appIconPath: Schema.optionalKey<Schema.String>;
    readonly appIconIndex: Schema.optionalKey<Schema.Int>;
    readonly relaunchCommand: Schema.optionalKey<Schema.String>;
    readonly relaunchDisplayName: Schema.optionalKey<Schema.String>;
}>;
export type AppDetails = typeof AppDetails.Type;
/** One button of a Windows taskbar thumbnail toolbar; `id` names it in `thumbarClicks`. */
export declare const ThumbarButton: Schema.Struct<{
    readonly id: Schema.String;
    readonly icon: Schema.Union<readonly [Schema.String, Binary.Bytes, Schema.Struct<{
        readonly representations: Schema.NonEmptyArray<Schema.Struct<{
            readonly scaleFactor: Schema.Finite;
            readonly bytes: Binary.Bytes;
        }>>;
    }>]>;
    readonly tooltip: Schema.optionalKey<Schema.String>;
    readonly flags: Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["enabled", "disabled", "dismissonclick", "nobackground", "hidden", "noninteractive"]>>>;
}>;
export type ThumbarButton = typeof ThumbarButton.Type;
/** A raw Windows message delivered to a window, with its parameters as bytes. */
export declare const WindowMessage: Schema.Struct<{
    readonly wParam: Binary.Bytes;
    readonly lParam: Binary.Bytes;
}>;
export type WindowMessage = typeof WindowMessage.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"audio", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly muted: Schema.Boolean;
    readonly audible: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"back", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"changes", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly normalBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    /** The content area, excluding the frame; attached views are positioned within it. */
    readonly contentBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly visible: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly minimized: Schema.Boolean;
    readonly maximized: Schema.Boolean;
    readonly fullScreen: Schema.Boolean;
    /**
     * macOS's pre-Lion fullscreen: it does not create a Space, which is why a window minimizing to
     * the tray leaves it first. Probed on Linux: `setSimpleFullScreen` is honoured there too — both
     * this and `fullScreen` answer true afterwards — so the field is not macOS-only, even though its
     * distinct behavior (no Space) is.
     */
    readonly simpleFullScreen: Schema.Boolean;
    readonly title: Schema.String;
    readonly alwaysOnTop: Schema.Boolean;
    readonly opacity: Schema.Finite;
    readonly resizable: Schema.Boolean;
    readonly movable: Schema.Boolean;
    readonly minimizable: Schema.Boolean;
    readonly maximizable: Schema.Boolean;
    readonly closable: Schema.Boolean;
    readonly fullScreenable: Schema.Boolean;
    readonly menuBarVisible: Schema.Boolean;
    readonly kiosk: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"close", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"find", Schema.Struct<{
    text: Schema.String;
    options: Schema.optionalKey<Schema.Struct<{
        readonly forward: Schema.optionalKey<Schema.Boolean>;
        readonly matchCase: Schema.optionalKey<Schema.Boolean>;
    }>>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly activeMatchOrdinal: Schema.Int;
    readonly matches: Schema.Int;
    readonly selectionArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly finalUpdate: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"findNext", Schema.Struct<{
    forward: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"flash", Schema.Struct<{
    flash: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"focus", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"forward", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"hide", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"history", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly index: Schema.Int;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly url: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"maximize", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"minimize", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"restore", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setAlwaysOnTop", Schema.Struct<{
    alwaysOnTop: Schema.Boolean;
    level: Schema.optionalKey<Schema.Literals<readonly ["normal", "floating", "torn-off-menu", "modal-panel", "main-menu", "status", "pop-up-menu", "screen-saver"]>>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setAudioMuted", Schema.Struct<{
    muted: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setBounds", Schema.Struct<{
    readonly x: Schema.optionalKey<Schema.Finite>;
    readonly y: Schema.optionalKey<Schema.Finite>;
    readonly width: Schema.optionalKey<Schema.Finite>;
    readonly height: Schema.optionalKey<Schema.Finite>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setFullScreen", Schema.Struct<{
    fullScreen: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setOpacity", Schema.Struct<{
    opacity: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setProgress", Schema.Struct<{
    progress: Schema.Finite;
    mode: Schema.optionalKey<Schema.Literals<readonly ["none", "normal", "indeterminate", "error", "paused"]>>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setSimpleFullScreen", Schema.Struct<{
    simpleFullScreen: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setTitle", Schema.Struct<{
    title: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setZoom", Schema.Struct<{
    factor: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"show", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"showInactive", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, Schema.Struct<{
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly normalBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    /** The content area, excluding the frame; attached views are positioned within it. */
    readonly contentBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly visible: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly minimized: Schema.Boolean;
    readonly maximized: Schema.Boolean;
    readonly fullScreen: Schema.Boolean;
    /**
     * macOS's pre-Lion fullscreen: it does not create a Space, which is why a window minimizing to
     * the tray leaves it first. Probed on Linux: `setSimpleFullScreen` is honoured there too — both
     * this and `fullScreen` answer true afterwards — so the field is not macOS-only, even though its
     * distinct behavior (no Space) is.
     */
    readonly simpleFullScreen: Schema.Boolean;
    readonly title: Schema.String;
    readonly alwaysOnTop: Schema.Boolean;
    readonly opacity: Schema.Finite;
    readonly resizable: Schema.Boolean;
    readonly movable: Schema.Boolean;
    readonly minimizable: Schema.Boolean;
    readonly maximizable: Schema.Boolean;
    readonly closable: Schema.Boolean;
    readonly fullScreenable: Schema.Boolean;
    readonly menuBarVisible: Schema.Boolean;
    readonly kiosk: Schema.Boolean;
}>, typeof SewedError, never, never> | Rpc.Rpc<"stopFind", Schema.Struct<{
    action: Schema.Literals<readonly ["clearSelection", "keepSelection", "activateSelection"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"zoom", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly factor: Schema.Finite;
}>, typeof SewedError>, Schema.Never, never, never>>;
/**
 * One window's controls as one capability. Unlike the ambient surfaces, this one belongs to an
 * owner: `WindowControls.native(window)` in `sewed/main` carries the window it was built for, so
 * every operation reaches that window and no other. `Capability.client` reaches it from a
 * document, and serving it twice for two windows gives two owners over this one protocol.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"audio", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly muted: Schema.Boolean;
    readonly audible: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"back", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"changes", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly normalBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    /** The content area, excluding the frame; attached views are positioned within it. */
    readonly contentBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly visible: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly minimized: Schema.Boolean;
    readonly maximized: Schema.Boolean;
    readonly fullScreen: Schema.Boolean;
    /**
     * macOS's pre-Lion fullscreen: it does not create a Space, which is why a window minimizing to
     * the tray leaves it first. Probed on Linux: `setSimpleFullScreen` is honoured there too — both
     * this and `fullScreen` answer true afterwards — so the field is not macOS-only, even though its
     * distinct behavior (no Space) is.
     */
    readonly simpleFullScreen: Schema.Boolean;
    readonly title: Schema.String;
    readonly alwaysOnTop: Schema.Boolean;
    readonly opacity: Schema.Finite;
    readonly resizable: Schema.Boolean;
    readonly movable: Schema.Boolean;
    readonly minimizable: Schema.Boolean;
    readonly maximizable: Schema.Boolean;
    readonly closable: Schema.Boolean;
    readonly fullScreenable: Schema.Boolean;
    readonly menuBarVisible: Schema.Boolean;
    readonly kiosk: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"close", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"find", Schema.Struct<{
    text: Schema.String;
    options: Schema.optionalKey<Schema.Struct<{
        readonly forward: Schema.optionalKey<Schema.Boolean>;
        readonly matchCase: Schema.optionalKey<Schema.Boolean>;
    }>>;
}>, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly activeMatchOrdinal: Schema.Int;
    readonly matches: Schema.Int;
    readonly selectionArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly finalUpdate: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"findNext", Schema.Struct<{
    forward: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"flash", Schema.Struct<{
    flash: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"focus", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"forward", Schema.Void, Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly url: Schema.String;
    readonly processId: Schema.Finite;
    readonly httpStatus: Schema.Finite;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly url: Schema.String;
    readonly code: Schema.Finite;
    readonly description: Schema.String;
}>]>, typeof SewedError, never, never> | Rpc.Rpc<"hide", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"history", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly index: Schema.Int;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly url: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
}>, typeof SewedError>, Schema.Never, never, never> | Rpc.Rpc<"maximize", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"minimize", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"restore", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setAlwaysOnTop", Schema.Struct<{
    alwaysOnTop: Schema.Boolean;
    level: Schema.optionalKey<Schema.Literals<readonly ["normal", "floating", "torn-off-menu", "modal-panel", "main-menu", "status", "pop-up-menu", "screen-saver"]>>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setAudioMuted", Schema.Struct<{
    muted: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setBounds", Schema.Struct<{
    readonly x: Schema.optionalKey<Schema.Finite>;
    readonly y: Schema.optionalKey<Schema.Finite>;
    readonly width: Schema.optionalKey<Schema.Finite>;
    readonly height: Schema.optionalKey<Schema.Finite>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setFullScreen", Schema.Struct<{
    fullScreen: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setOpacity", Schema.Struct<{
    opacity: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setProgress", Schema.Struct<{
    progress: Schema.Finite;
    mode: Schema.optionalKey<Schema.Literals<readonly ["none", "normal", "indeterminate", "error", "paused"]>>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setSimpleFullScreen", Schema.Struct<{
    simpleFullScreen: Schema.Boolean;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setTitle", Schema.Struct<{
    title: Schema.String;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"setZoom", Schema.Struct<{
    factor: Schema.Finite;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"show", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"showInactive", Schema.Void, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, Schema.Struct<{
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly normalBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    /** The content area, excluding the frame; attached views are positioned within it. */
    readonly contentBounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly visible: Schema.Boolean;
    readonly focused: Schema.Boolean;
    readonly minimized: Schema.Boolean;
    readonly maximized: Schema.Boolean;
    readonly fullScreen: Schema.Boolean;
    /**
     * macOS's pre-Lion fullscreen: it does not create a Space, which is why a window minimizing to
     * the tray leaves it first. Probed on Linux: `setSimpleFullScreen` is honoured there too — both
     * this and `fullScreen` answer true afterwards — so the field is not macOS-only, even though its
     * distinct behavior (no Space) is.
     */
    readonly simpleFullScreen: Schema.Boolean;
    readonly title: Schema.String;
    readonly alwaysOnTop: Schema.Boolean;
    readonly opacity: Schema.Finite;
    readonly resizable: Schema.Boolean;
    readonly movable: Schema.Boolean;
    readonly minimizable: Schema.Boolean;
    readonly maximizable: Schema.Boolean;
    readonly closable: Schema.Boolean;
    readonly fullScreenable: Schema.Boolean;
    readonly menuBarVisible: Schema.Boolean;
    readonly kiosk: Schema.Boolean;
}>, typeof SewedError, never, never> | Rpc.Rpc<"stopFind", Schema.Struct<{
    action: Schema.Literals<readonly ["clearSelection", "keepSelection", "activateSelection"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"zoom", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly factor: Schema.Finite;
}>, typeof SewedError>, Schema.Never, never, never>, "sewed/binding/window-controls">;
//# sourceMappingURL=WindowControls.d.ts.map