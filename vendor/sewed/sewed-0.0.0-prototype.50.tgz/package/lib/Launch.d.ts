import { Schema } from "effect";
/** How this process was launched: its own arguments, or a file or URL the platform handed it. */
export declare const Request: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"initial">;
    readonly arguments: Schema.$Array<Schema.String>;
    readonly workingDirectory: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"file">;
    readonly path: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"url">;
    readonly url: Schema.String;
}>]>;
export type Request = typeof Request.Type;
/**
 * A later launch of the application while this process holds the single-instance lock: the other
 * process's arguments and working directory, and the JSON `data` it claimed with (`null` when it
 * claimed with none). Delivered on `App.Instance`'s `launches`, never on `App.launches`.
 */
export declare const SecondInstance: Schema.Struct<{
    readonly arguments: Schema.$Array<Schema.String>;
    readonly workingDirectory: Schema.String;
    readonly additionalData: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>;
export type SecondInstance = typeof SecondInstance.Type;
//# sourceMappingURL=Launch.d.ts.map