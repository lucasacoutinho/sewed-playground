import { Schema } from "effect";
export declare const CaptureMode: Schema.Literals<readonly ["default", "includeSensitive", "everything"]>;
export type CaptureMode = typeof CaptureMode.Type;
export declare const Options: Schema.Struct<{
    readonly captureMode: Schema.optionalKey<Schema.Literals<readonly ["default", "includeSensitive", "everything"]>>;
    readonly maxFileSize: Schema.optionalKey<Schema.Int>;
}>;
export type Options = typeof Options.Type;
//# sourceMappingURL=NetLog.d.ts.map