import { Schema } from "effect";
import * as Decision from "./Decision.ts";
/** How a host's certificate is judged: Chromium's verdict, unconditional trust, or one pinned fingerprint. */
export declare const Trust: Schema.Union<readonly [Schema.Literal<"system">, Schema.Literal<"always">, Schema.Struct<{
    readonly fingerprint: Schema.String;
}>]>;
export type Trust = typeof Trust.Type;
/**
 * Hostnames are exact or a `*.` suffix; hosts without a rule keep Chromium's verdict. A pattern
 * {@link canonicalPattern} cannot resolve to a real host is refused at decode: write a bare
 * hostname with no scheme, port, or path; an internationalized host in its punycode (`xn--`) form,
 * since Chromium reports a host that way and a Unicode spelling would never match it; or an IPv6
 * address in brackets; and within DNS's own length bounds, which the host parser does not apply.
 * A malformed *grant* fails closed: it matches nothing, so nothing new is trusted. A malformed
 * **pin** fails open instead, and that asymmetry is why this is checked at decode rather than left
 * silently inert: `{ hostname: "api.example.com ", trust: { fingerprint } }` — one pasted trailing
 * space — would otherwise never match, so the pin contributes nothing, Chromium's ordinary verdict
 * stands, and the author believes the host is pinned.
 *
 * Two differences from base, deliberate: a pin now also fires for the trailing-dot form of its
 * host — at base, a request to `example.com.` missed a rule for `example.com`, so appending a dot
 * was a pin bypass, and both sides now drop one trailing dot before comparing — and an IPv6
 * pattern matches whether the event's own hostname arrives bracketed or not, because
 * `Session.Certificate`'s event brackets one (`URL.hostname` does) while `App.CertificateError`'s
 * need not.
 */
export declare const Rule: Schema.Struct<{
    readonly hostname: Schema.String;
    readonly trust: Schema.Union<readonly [Schema.Literal<"system">, Schema.Literal<"always">, Schema.Struct<{
        readonly fingerprint: Schema.String;
    }>]>;
}>;
export type Rule = typeof Rule.Type;
export declare const Rules: Schema.$Array<Schema.Struct<{
    readonly hostname: Schema.String;
    readonly trust: Schema.Union<readonly [Schema.Literal<"system">, Schema.Literal<"always">, Schema.Struct<{
        readonly fingerprint: Schema.String;
    }>]>;
}>>;
export type Rules = typeof Rules.Type;
/**
 * What Electron's `certificate-error` callback hands over about the offending certificate, narrowed
 * to the fields a trust decision actually needs: the fingerprint a rule pins against, the subject and
 * issuer names a decider can show or match, and the validity window. Electron's own `Certificate`
 * carries more (the PEM data, the full principal objects, a recursive issuer certificate, and the
 * serial number); none of it is needed to answer "trust" or "reject", so it stays out of the
 * decidable's event.
 */
export declare const Presented: Schema.Struct<{
    readonly fingerprint: Schema.String;
    readonly subjectName: Schema.String;
    readonly issuerName: Schema.String;
    /** Seconds since the epoch, as Electron's `Certificate.validStart` reports it. */
    readonly validStart: Schema.Finite;
    /** Seconds since the epoch, as Electron's `Certificate.validExpiry` reports it. */
    readonly validExpiry: Schema.Finite;
}>;
export type Presented = typeof Presented.Type;
/**
 * A certificate policy: it names the least it needs from an event — `{ hostname, certificate:
 * { fingerprint } }` — and answers `"trust" | "reject" | Pass`. The first matching rule within one
 * policy wins; hostnames compare lowercased; a `*.` pattern matches the bare suffix and any
 * subdomain. `trust: "system"` and no match both answer {@link Decision.Pass}, which is why the same
 * policy installs on `Session.Certificate` (a three-answer decidable: `"reject" | "system" |
 * "trust"`) and on `App.CertificateError` (two: `"reject" | "trust"`) alike. `"always"` trusts; a
 * `{ fingerprint }` rule trusts on equality and rejects on mismatch. An empty `hostname` — what
 * `App.CertificateError`'s event carries for a URL Chromium could not parse — always answers
 * {@link Decision.Pass}, ahead of matching any rule: `Rule`'s own schema already refuses every
 * malformed pattern that could otherwise match it, but this is the belt to that schema's braces —
 * it covers the event this compiles against, not the rules.
 */
export declare const Policy: Decision.Policy<readonly {
    readonly hostname: string;
    readonly trust: "always" | "system" | {
        readonly fingerprint: string;
    };
}[], {
    readonly hostname: string;
    readonly certificate: {
        readonly fingerprint: string;
    };
}, "reject" | "trust">;
//# sourceMappingURL=Certificate.d.ts.map