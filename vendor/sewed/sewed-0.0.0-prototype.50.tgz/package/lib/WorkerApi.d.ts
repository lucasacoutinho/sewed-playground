export { define, entry, threadId } from "./Worker.ts";
export type { Definition, Entry } from "./Worker.ts";
//# sourceMappingURL=WorkerApi.d.ts.map