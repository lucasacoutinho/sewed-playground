import { Schema } from "effect";
export declare const Info: Schema.Struct<{
    readonly versionId: Schema.Finite;
    readonly scriptUrl: Schema.String;
    readonly scope: Schema.String;
    readonly renderProcessId: Schema.Finite;
}>;
export type Info = typeof Info.Type;
export declare const Status: Schema.Literals<readonly ["starting", "running", "stopping", "stopped"]>;
export type Status = typeof Status.Type;
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"registered">;
    readonly scope: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"status">;
    readonly versionId: Schema.Finite;
    readonly status: Schema.Literals<readonly ["starting", "running", "stopping", "stopped"]>;
}>]>;
export type Event = typeof Event.Type;
//# sourceMappingURL=ServiceWorker.d.ts.map