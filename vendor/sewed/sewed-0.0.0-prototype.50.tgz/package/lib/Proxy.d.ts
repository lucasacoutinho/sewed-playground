import { Schema } from "effect";
/** A session's proxy configuration, one mode at a time. */
export declare const Config: Schema.Union<readonly [Schema.Struct<{
    readonly mode: Schema.Literal<"direct">;
}>, Schema.Struct<{
    readonly mode: Schema.Literal<"system">;
}>, Schema.Struct<{
    readonly mode: Schema.Literal<"auto_detect">;
}>, Schema.Struct<{
    readonly mode: Schema.Literal<"pac_script">;
    readonly pacScript: Schema.String;
}>, Schema.Struct<{
    readonly mode: Schema.Literal<"fixed_servers">;
    readonly proxyRules: Schema.String;
    readonly proxyBypassRules: Schema.optionalKey<Schema.String>;
}>]>;
export type Config = typeof Config.Type;
//# sourceMappingURL=Proxy.d.ts.map