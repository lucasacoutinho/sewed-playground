import * as Decision from "./Decision.ts";
import * as WebRequest from "./WebRequest.ts";
export declare const App: {
    /**
     * Asked before the application quits; a denial keeps it running. Nobody objecting allows the
     * quit, but a *broken* quit guard denies it: a decider that throws, dies, or answers off-schema
     * decided nothing, and quitting on the strength of that would lose whatever it was guarding.
     */
    Quit: Decision.Decidable<{}, "allow" | "deny", "async", "restrictive", "app">;
    /**
     * Asked when the last window closes. The fallback preserves today's platform default
     * (`options.quitOnLastWindowClosed ?? process.platform !== "darwin"`): a constant would silently
     * change macOS behavior, and a library-installed darwin decider would out-rank every consumer
     * decider under `first` composition, since it would install before any of them.
     */
    LastWindowClosed: Decision.Decidable<{}, "quit" | "stay", "sync", "first", "app">;
    /** Asked for each HTTP authentication challenge; without an answer the challenge is cancelled. */
    Login: Decision.Decidable<{
        readonly url: string;
        readonly isProxy: boolean;
        readonly scheme: string;
        readonly host: string;
        readonly port: number;
        readonly realm: string;
        readonly isRequestForNavigation: boolean;
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "credentials";
        readonly username: string;
        readonly password: import("effect/Redacted").Redacted<string>;
    }, "async", "first", "app">;
    /**
     * Asked for each TLS error; without an answer Chromium's rejection stands. The event carries only
     * what a trust decision needs from the presented certificate — see {@link Certificate.Presented}
     * — plus `hostname` (`URL.parse(url)?.hostname ?? ""` in `App.ts`'s builder), so `Certificate.Policy`
     * installs here the same way it installs on `Session.Certificate`.
     */
    CertificateError: Decision.Decidable<{
        readonly url: string;
        readonly hostname: string;
        readonly certificate: {
            readonly fingerprint: string;
            readonly subjectName: string;
            readonly issuerName: string;
            readonly validStart: number;
            readonly validExpiry: number;
        };
    }, "reject" | "trust", "async", "restrictive", "app">;
    /**
     * Asked when a server requests a client certificate, with the certificates the store offers.
     * `default` sends the store's first, which is what Electron does by itself and so the fallback;
     * `select` sends the one named by fingerprint, and `none` sends none. It composes restrictively,
     * `none` first, and a decider that fails sends none: a broken chooser must not present an
     * identity nobody chose. A fingerprint the request did not offer sends none.
     */
    ClientCertificate: Decision.Decidable<{
        readonly url: string;
        readonly certificates: readonly {
            readonly fingerprint: string;
            readonly subjectName: string;
            readonly issuerName: string;
            readonly validStart: number;
            readonly validExpiry: number;
        }[];
    }, {
        readonly kind: "default";
    } | {
        readonly kind: "none";
    } | {
        readonly kind: "select";
        readonly fingerprint: string;
    }, "async", "restrictive", "app">;
    /**
     * Asked when a client certificate store needs the password of a token to answer a request, on
     * Linux. Without an answer, and when a decider fails, the request goes on without a password.
     */
    ClientCertificatePassword: Decision.Decidable<{
        readonly hostname: string;
        readonly tokenName: string;
        readonly isRetry: boolean;
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "password";
        readonly password: import("effect/Redacted").Redacted<string>;
    }, "async", "first", "app">;
};
export declare const Window: {
    /**
     * Asked before a window closes; a denial keeps it open. The decider sees which window. Nobody
     * objecting closes the window, but a *broken* guard keeps it open: an unsaved-changes decider that
     * throws has not established that there is nothing to lose.
     */
    Close: Decision.Decidable<{
        readonly windowId: string;
    }, "allow" | "deny", "async", "restrictive", "window">;
    /**
     * Asked on Windows when the user's session is about to end (shutdown, restart or log off) and
     * the system asks each window whether it may. A denial asks the system to wait, which it shows
     * the user and may override. Nobody objecting allows it.
     */
    SessionEnd: Decision.Decidable<{
        readonly windowId: string;
        readonly reasons: readonly ("close-app" | "critical" | "logoff" | "shutdown")[];
    }, "allow" | "deny", "sync", "restrictive", "window">;
};
export declare const WebContents: {
    /**
     * Asked for each main-frame navigation or redirect the page starts. `kind` also admits
     * `"webview"` in its type, reserved for the day webview attachment becomes decidable — nothing
     * dispatches that kind today: webview attach is denied unconditionally and never resolves this
     * decidable.
     */
    Navigation: Decision.Decidable<{
        readonly url: string;
        readonly kind: "navigation" | "redirect" | "webview";
    }, "allow" | "deny", "sync", "restrictive", "contents">;
    /** Asked when the page requests a new window; without an answer the popup is denied. */
    Popup: Decision.Decidable<{
        readonly url: string;
    }, "allow" | "deny", "sync", "restrictive", "contents">;
    /** Asked when the page sets its title; the fallback keeps whatever title main last set. */
    TitleUpdate: Decision.Decidable<{
        readonly title: string;
    }, "accept" | "keep", "sync", "first", "contents">;
    /** Asked when the page tries to prevent its own unload; the fallback honors the page's request. */
    Unload: Decision.Decidable<{
        readonly url: string;
    }, "honor" | "override", "sync", "first", "contents">;
    /**
     * Asked for each keyboard or mouse event; without an answer input reaches the page. Deliberately
     * declares no `failure`, unlike the guards that close a window or quit the application: its closed
     * answer is `block`, asked of every keystroke and every click, so a buggy input decider that
     * contributed it would brick the application. A failing decider here contributes the fallback and
     * input keeps reaching the page — the one place in this catalog where a broken decider is the
     * lesser hazard.
     */
    Input: Decision.Decidable<{
        readonly kind: "key" | "mouse";
    }, "allow" | "block", "sync", "restrictive", "contents">;
    /**
     * Asked for each download a document starts. The catalog fallback is `deny`, the safe end for any
     * owner that declares nothing; a guest's own registry keeps it, and a plain web contents' registry
     * overrides it to `prompt` — see `internal/GuestView.ts` and `internal/WebContents.ts`, where each
     * owner's `Registry.make({ fallbacks })` makes its own posture visible at its construction site.
     *
     * The failure is declared rather than left to that fallback, which is what makes this decidable
     * unlike the other two-posture cases: an undeclared failure *is* the effective fallback, per-owner
     * override included, so on a window a decider that throws, dies, or answers off-schema would
     * contribute `prompt` and hand the file to Electron's save dialog. A download guard that vets a
     * file and crashes has established nothing about that file, on either owner — the same reasoning
     * `Window.Close` and `App.Quit` declare a failure for, on the one decidable whose fallback is not
     * the same answer for everyone who resolves it.
     */
    Download: Decision.Decidable<{
        readonly url: string;
        readonly filename: string;
        readonly mimeType: string;
        readonly totalBytes: number;
        readonly sourceId: string;
        readonly urlChain: readonly string[];
        readonly userGesture: boolean;
        readonly contentDisposition: string;
    }, {
        readonly kind: "deny";
    } | {
        readonly kind: "save";
        readonly path: string;
    } | {
        readonly kind: "prompt";
        readonly dialog?: {
            readonly title?: string;
            readonly defaultPath?: string;
            readonly buttonLabel?: string;
            readonly filters?: readonly [{
                readonly name: string;
                readonly extensions: readonly [string, ...string[]];
            }, ...{
                readonly name: string;
                readonly extensions: readonly [string, ...string[]];
            }[]];
            readonly properties?: readonly ("createDirectory" | "dontAddToRecent" | "showHiddenFiles" | "showOverwriteConfirmation" | "treatPackageAsDirectory")[];
        };
    }, "sync", "restrictive", "contents">;
    /**
     * Asked each time a page's `navigator.bluetooth.requestDevice` scan reports the devices found so
     * far. `select` gives the page one of them, `cancel` ends the request, and `wait` keeps scanning:
     * the next report asks again, and interrupts a decider still deciding on the older list. Without
     * an answer the request is cancelled, which is also what Electron does with no listener; the
     * native listener exists only while a decider is installed.
     */
    BluetoothDevice: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly devices: readonly {
            readonly deviceId: string;
            readonly deviceName: string;
        }[];
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "select";
        readonly id: string;
    } | {
        readonly kind: "wait";
    }, "async", "first", "contents">;
};
export declare const Session: {
    /**
     * Asked for each permission check or request, and for each HID, serial, or USB device check,
     * which shares this same decidable: `name` is the permission or device type Electron reports.
     * `document` is the requesting document's key for a permission check, and `null` for a device
     * check, which Electron identifies by origin only — `allowed`/`deviceAllowed` in
     * `internal/Session.ts` compute both fields, gated on the same main-frame, same-document, and
     * origin checks the old rule engine made unconditionally. `document: null` makes a decider that has
     * not handled the device case a compile error at the first `document.startsWith(...)` it writes,
     * rather than a same-shaped string that silently widens a document-scoped grant to the whole
     * origin — the same reasoning applies to `origin`, one level down: `URL.origin` is the literal
     * string `"null"`, not the value `null`, for `file:`, `data:`, and any other opaque-origin
     * document, so `file:///a.html` and `file:///b.html` would otherwise reach a decider with the
     * identical, non-identifying `origin: "null"`. `origin: null` here means exactly that — the
     * document has no origin to grant by — so a decider must key an opaque document by `document`
     * instead; a `document`-keyed grant is unaffected, since `document` stays exact for every request.
     *
     * `mediaTypes` names which of `audio`/`video` a `media` request actually asks for: Electron's
     * request handler reports the array `MediaAccessPermissionRequest.mediaTypes` carries, and its
     * check handler — consulted once per requested type, probed on Linux — reports its own singular
     * `mediaType` as a one-element list. Every other permission, and a check whose `mediaType` is
     * `unknown` or absent, carries an empty list: `mediaTypes` only says which media types a request
     * asks for once `name` already says `"media"`; it never distinguishes a media request from any
     * other.
     * The fallback denies.
     */
    Permission: Decision.Decidable<{
        readonly name: string;
        readonly origin: string | null;
        readonly document: string | null;
        readonly mediaTypes: readonly ("audio" | "video")[];
    }, "allow" | "deny", "sync", "restrictive", "session">;
    /**
     * Asked for each of the renderer's speculative preconnections; the fallback allows them, matching
     * a session's previous default. A failing decider denies instead, which costs a preconnection's
     * latency and nothing else.
     */
    Preconnect: Decision.Decidable<{
        readonly url: string;
    }, "allow" | "deny", "sync", "restrictive", "session">;
    /**
     * Asked for each server certificate verification; without an answer Chromium's own verdict stands.
     * A decider that *fails* rejects instead: a broken fingerprint pin must not silently become no pin
     * by deferring to the CA validity the pin exists to distrust. `trust`, `reject`, and `system` map
     * onto `setCertificateVerifyProc`'s numeric `0`, `-2`, and `-3` — see `internal/Session.ts`.
     */
    Certificate: Decision.Decidable<{
        readonly hostname: string;
        readonly certificate: {
            readonly fingerprint: string;
            readonly subjectName: string;
            readonly issuerName: string;
            readonly validStart: number;
            readonly validExpiry: number;
        };
    }, "reject" | "system" | "trust", "async", "restrictive", "session">;
    /**
     * Asked for each screen-share request; without an answer, or when a decider fails, it is denied.
     * `order`'s two entries are `DesktopCapturer.Decision`'s own discriminants — it has no `"grant"`
     * member.
     */
    DisplayMedia: Decision.Decidable<{
        readonly origin: string | null;
        readonly videoRequested: boolean;
        readonly audioRequested: boolean;
        readonly userGesture: boolean;
    }, {
        readonly kind: "deny";
    } | {
        readonly kind: "source";
        readonly id: string;
        readonly audio?: "loopback" | "loopbackWithMute";
    }, "async", "restrictive", "session">;
    /**
     * Asked when a page uses the File System Access API on a file or directory Chromium treats as
     * sensitive, such as the home directory. `allow` gives the page the path, `tryAgain` reopens the
     * picker, and `deny` refuses. Without an answer, and when a decider fails, the path is denied.
     */
    FileSystemAccess: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly path: string;
        readonly isDirectory: boolean;
    }, "allow" | "deny" | "tryAgain", "async", "restrictive", "session">;
    /**
     * Asked when a page calls `navigator.hid.requestDevice`, with the devices that match its filters.
     * Without an answer the request is cancelled, which is also what Electron does with no listener;
     * a selected id the request did not offer cancels it too. The native listener exists only while a
     * decider is installed. Whether the page may then use the device is still
     * {@link Session.Permission}'s to say.
     */
    HidDevice: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly devices: readonly {
            readonly deviceId: string;
            readonly name: string;
            readonly vendorId: number;
            readonly productId: number;
            readonly serialNumber?: string;
            readonly guid?: string;
        }[];
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "select";
        readonly id: string;
    }, "async", "first", "session">;
    /** Asked when a page calls `navigator.usb.requestDevice`; behaves as {@link Session.HidDevice}. */
    UsbDevice: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly devices: readonly {
            readonly deviceId: string;
            readonly vendorId: number;
            readonly productId: number;
            readonly deviceClass: number;
            readonly deviceSubclass: number;
            readonly deviceProtocol: number;
            readonly productName?: string;
            readonly manufacturerName?: string;
            readonly serialNumber?: string;
        }[];
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "select";
        readonly id: string;
    }, "async", "first", "session">;
    /**
     * Asked when a page calls `navigator.serial.requestPort`; behaves as {@link Session.HidDevice}.
     * Electron names the requesting web contents rather than a frame, so `origin` and `document` are
     * its top-level document's.
     */
    SerialPort: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly ports: readonly {
            readonly portId: string;
            readonly portName: string;
            readonly displayName?: string;
            readonly vendorId?: string;
            readonly productId?: string;
            readonly serialNumber?: string;
        }[];
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "select";
        readonly id: string;
    }, "async", "first", "session">;
    /**
     * Asked when `navigator.credentials.get()` finds several discoverable WebAuthn credentials and
     * one must be chosen. Without an answer the request is cancelled and the page receives a
     * `NotAllowedError`; a credential id the request did not offer cancels it too.
     */
    WebAuthnAccount: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly relyingPartyId: string;
        readonly accounts: readonly {
            readonly credentialId: string;
            readonly name?: string;
            readonly displayName?: string;
            readonly userHandle?: string;
        }[];
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "select";
        readonly id: string;
    }, "async", "first", "session">;
    /**
     * Asked when a Bluetooth device needs confirmation or a pin before it pairs, on Linux and Windows;
     * macOS pairs by itself and never asks. Without an answer the pairing is cancelled, and so is an
     * answer of the wrong kind for its prompt.
     */
    BluetoothPairing: Decision.Decidable<{
        readonly origin: string | null;
        readonly document: string | null;
        readonly deviceId: string;
        readonly kind: "confirm" | "confirmPin" | "providePin";
        readonly pin?: string;
    }, {
        readonly kind: "cancel";
    } | {
        readonly kind: "confirm";
    } | {
        readonly kind: "pin";
        readonly pin: string;
    }, "async", "first", "session">;
    /**
     * Asked before each request the filter selects leaves the session. Nobody objecting allows it,
     * and a *broken* decider blocks it: a tracker gate that throws has not established that the
     * request is safe to make, and a filter narrow enough to be worth installing is narrow enough
     * that failing its requests closed costs one feature rather than the application.
     *
     * `body` on this stage's filter is what makes `body` reach a decider here eagerly, capped in
     * bytes and assembled per install — see `session.intercept`. The event's own `readBody(options?)`
     * assembles lazily instead, under the options given or the install's own `body` filter when it
     * named one, so an install over `<all_urls>` pays for a body only on the request whose decider
     * asks. This is the only one of the three stages that carries upload data at all, and the other
     * two refuse a filter that asks for it — and so have no `readBody` on their own events.
     *
     * A decider that *fails* blocks; a decider that never **settles** leaves its request unanswered,
     * and the page waits. Liveness is the decider's own, and closing the installing scope does not
     * release a request already in flight: bound a decider that can wait on anything with
     * `Effect.timeout`, and let the timeout fail so it blocks.
     */
    Request: Decision.Decidable<{
        readonly id: number;
        readonly url: string;
        readonly method: string;
        readonly resourceType: "cspReport" | "font" | "image" | "mainFrame" | "media" | "object" | "other" | "ping" | "script" | "stylesheet" | "subFrame" | "webSocket" | "xhr";
        readonly referrer: string;
        readonly timestamp: number;
        readonly webContentsId?: number;
        readonly sourceId?: string;
        readonly body?: {
            readonly parts: readonly ({
                readonly kind: "bytes";
                readonly bytes: Uint8Array<ArrayBufferLike>;
            } | {
                readonly kind: "file";
                readonly path: string;
                readonly offset?: number;
                readonly length?: number;
                readonly modificationTime?: number;
            } | {
                readonly kind: "blob";
                readonly id: string;
                readonly bytes?: Uint8Array<ArrayBufferLike>;
            })[];
            readonly bytes: number;
            readonly truncated: boolean;
        };
        readonly readBody: WebRequest.ReadBody;
    }, {
        readonly kind: "allow";
    } | {
        readonly kind: "block";
    } | {
        readonly kind: "redirect";
        readonly url: string;
    }, "async", "restrictive", "requests">;
    /**
     * Asked before the request headers are sent, and it **chains** rather than ranks: each decider is
     * handed the headers the previous one produced, so one feature adding an authorization header and
     * another adding a trace header both land. A ranking cannot express that — two `headers` answers
     * rank equal, so the first-installed would win and the second feature's headers would silently
     * vanish, which is Electron's own single-listener clobbering reintroduced one level up. A `block`
     * from any decider ends the chain and cancels the request, later deciders unconsulted, and a
     * broken decider contributes that same `block`.
     *
     * A decider that *fails* blocks; a decider that never **settles** leaves its request unanswered,
     * and the page waits. Liveness is the decider's own, and closing the installing scope does not
     * release a request already in flight: bound a decider that can wait on anything with
     * `Effect.timeout`, and let the timeout fail so it blocks.
     */
    RequestHeaders: Decision.Decidable<{
        readonly id: number;
        readonly url: string;
        readonly method: string;
        readonly resourceType: "cspReport" | "font" | "image" | "mainFrame" | "media" | "object" | "other" | "ping" | "script" | "stylesheet" | "subFrame" | "webSocket" | "xhr";
        readonly referrer: string;
        readonly timestamp: number;
        readonly webContentsId?: number;
        readonly sourceId?: string;
        readonly headers: {
            readonly [x: string]: string;
        };
    }, {
        readonly kind: "allow";
    } | {
        readonly kind: "block";
    } | {
        readonly kind: "headers";
        readonly headers: {
            readonly [x: string]: string;
        };
    }, "async", "chain", "requests">;
    /**
     * Asked when the response headers arrive, chaining exactly as {@link RequestHeaders} does. Its
     * `advance` spreads `statusLine` back only when the answer carried one, so a status line set by
     * one decider survives a later decider that rewrites headers alone — the cumulative `statusLine`
     * the hand-rolled listener this replaces tracked by hand.
     *
     * A decider that *fails* blocks; a decider that never **settles** leaves its request unanswered,
     * and the page waits. Liveness is the decider's own, and closing the installing scope does not
     * release a request already in flight: bound a decider that can wait on anything with
     * `Effect.timeout`, and let the timeout fail so it blocks.
     */
    ResponseHeaders: Decision.Decidable<{
        readonly id: number;
        readonly url: string;
        readonly method: string;
        readonly resourceType: "cspReport" | "font" | "image" | "mainFrame" | "media" | "object" | "other" | "ping" | "script" | "stylesheet" | "subFrame" | "webSocket" | "xhr";
        readonly referrer: string;
        readonly timestamp: number;
        readonly webContentsId?: number;
        readonly sourceId?: string;
        readonly statusLine: string;
        readonly statusCode: number;
        readonly headers: {
            readonly [x: string]: readonly string[];
        };
    }, {
        readonly kind: "allow";
    } | {
        readonly kind: "block";
    } | {
        readonly kind: "headers";
        readonly headers: {
            readonly [x: string]: readonly string[];
        };
        readonly statusLine?: string;
    }, "async", "chain", "requests">;
};
//# sourceMappingURL=Decidables.d.ts.map