import * as Native from "./internal/ImageView.ts";
export type { Handle, Options } from "./internal/ImageView.ts";
export declare const make: typeof Native.make;
//# sourceMappingURL=ImageView.d.ts.map