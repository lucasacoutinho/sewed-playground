import * as Effect from "effect/Effect";
/**
 * @returns Hex-encoded instance ID (16 random bytes)
 */
export declare const generateInstanceId: () => Effect.Effect<string, never, never>;
//# sourceMappingURL=InstanceId.d.ts.map