import { Effect } from "effect";
import type { Rpc, RpcGroup } from "effect/rpc";
import { MainContext } from "./RuntimeContext.ts";
import { type HandlerLayer } from "./internal/HandlerLayer.ts";
export declare const host: <Rpcs extends Rpc.Any, E, R>(protocol: RpcGroup.RpcGroup<Rpcs>, handlers: HandlerLayer<Rpcs, E, R>) => Effect.Effect<import("./Binding.ts").Owner<Rpcs>, E, R | MainContext | import("effect/Scope").Scope>;
//# sourceMappingURL=Host.d.ts.map