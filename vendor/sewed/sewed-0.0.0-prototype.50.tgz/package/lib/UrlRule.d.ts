import { Schema } from "effect";
export declare const Origin: Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
}>;
export declare const Document: Schema.Struct<{
    readonly kind: Schema.Literal<"document">;
    readonly url: Schema.String;
}>;
export declare const Rule: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"origin">;
    readonly origin: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"document">;
    readonly url: Schema.String;
}>]>;
export type Rule = typeof Rule.Type;
/**
 * The origin of a URL. Node reports an opaque origin for custom schemes, so a scheme `App.run`
 * registered as standard uses its scheme and host instead.
 */
export declare const originOf: (url: URL) => string;
export declare const documentKey: (url: URL) => string;
export declare const compile: (rule: Rule) => ((url: URL) => boolean);
//# sourceMappingURL=UrlRule.d.ts.map