import { Effect, Schema, Stream } from "effect";
import type { Scope } from "effect";
import * as Application from "./Application.ts";
import type * as Decision from "./Decision.ts";
import * as Declaration from "./Declaration.ts";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
import type * as MenuSchema from "./Menu.ts";
import type { Source as ImageSource } from "./Image.ts";
import * as ApplicationMenu from "./internal/ApplicationMenu.ts";
import * as Instance from "./internal/Instance.ts";
import type * as Launch from "./Launch.ts";
export declare const info: Effect.Effect<Application.Info, SewedError, MainContext>;
/**
 * The OS's own preferred languages, in the order it reports them — read directly, with no Effect,
 * because this is meant to run as an input to a declaration thunk, before any Effect runs and
 * before Electron is ready. `getPreferredSystemLanguages` is safe pre-readiness; `getSystemLocale`
 * throws there and `getLocale` answers `""`. The values are the OS's own and unmapped — a POSIX
 * `C` locale answers `["c"]` — turning one into a `--lang` value is the application's decision.
 */
export declare const preferredSystemLanguages: () => readonly string[];
/** The application's own path, as Electron reports it before readiness, for an entry's first pass. */
export declare const appPath: () => string;
/**
 * The path Electron uses for `name` with nothing declared — read before readiness, as an input to a
 * declaration. A pre-readiness `Paths.declare` of `userData` moves `sessionData`, `logs` and
 * `crashDumps` with it, so once a declaration has applied this reader reflects it; inside the
 * program, {@link path} is the reader. An invalid name throws `Protocol`; a name Electron cannot
 * answer on this platform (`recent` outside Windows) throws `Native`.
 */
export declare const defaultPath: (name: Application.PathName) => string;
/**
 * Shows a fatal error with no window: a title and a message, for an entry that cannot yet build one
 * — before `App.run`, or when a window has nothing to attach it to. Probed on Linux:
 * before readiness the call prints `title` and `content` to stderr and returns at once, whether or
 * not a display is present, because GTK is not yet up; after readiness with a display it shows a
 * blocking native modal. Electron documents a native box before readiness on Windows and macOS too
 * (not probed here). A window with something to attach a message to uses `window.dialog.message`
 * instead — this is for the case where nothing can. `title` and `content` must both be non-empty
 * strings; either empty throws `Protocol`.
 */
export declare const showErrorBox: (options: Application.ErrorBox) => void;
export declare const path: (name: Application.PathName) => Effect.Effect<string, SewedError, MainContext>;
export declare const setPath: (name: Application.PathName, directory: string) => Effect.Effect<void, SewedError, MainContext>;
export declare const gpu: (kind?: Application.GpuInfoKind) => Effect.Effect<Schema.Json, SewedError, MainContext>;
export declare const gpuFeatures: Effect.Effect<Record<string, string>, SewedError, MainContext>;
export declare const loginItems: Effect.Effect<Application.LoginItems, SewedError, MainContext>;
export declare const setLoginItems: (settings: Application.LoginItemSettings) => Effect.Effect<void, SewedError, MainContext>;
export declare const badge: Effect.Effect<number, SewedError, MainContext>;
/** Changes how the process resolves host names, for every session. */
export declare const configureHostResolver: (options: Application.HostResolver) => Effect.Effect<void, SewedError, MainContext>;
/** The icon the operating system shows for a file, as PNG bytes; the path must be absolute. */
export declare const fileIcon: (path: string, size?: Application.FileIconSize) => Effect.Effect<Uint8Array, SewedError, MainContext>;
/**
 * The name of the application that opens a URL's scheme, or an empty string when none is
 * registered or the platform cannot say.
 */
export declare const applicationNameForProtocol: (url: string) => Effect.Effect<string, SewedError, MainContext>;
/** The user agent sessions use when they set none of their own. */
export declare const userAgentFallback: Effect.Effect<string, SewedError, MainContext>;
export declare const setUserAgentFallback: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
/** Emits each time the GPU information changes; read it with {@link gpu}. */
export declare const gpuInfoUpdates: Stream.Stream<void, SewedError, MainContext>;
/**
 * Memory and processor use of every process the application runs. Processor percentages measure
 * the time since the previous read, so the first read of a process answers zero.
 */
export declare const metrics: Effect.Effect<ReadonlyArray<Application.ProcessMetric>, SewedError, MainContext>;
/** Whether this instance holds the single-instance lock. */
export declare const hasSingleInstanceLock: Effect.Effect<boolean, SewedError, MainContext>;
/**
 * Arranges for a new instance to start when this one exits. It does not end this instance:
 * follow it with {@link quit} or {@link exit}. Called more than once, every call starts an
 * instance.
 */
export declare const relaunch: (options?: Application.Relaunch) => Effect.Effect<void, SewedError, MainContext>;
/** Sets the dock or taskbar badge count; zero clears it. Fails with Native where unsupported. */
export declare const setBadge: (count: number) => Effect.Effect<void, SewedError, MainContext>;
export declare const setAboutPanel: (options: Application.AboutPanel) => Effect.Effect<void, SewedError, MainContext>;
export declare const showAboutPanel: Effect.Effect<void, SewedError, MainContext>;
export declare const isDefaultProtocolClient: (client: Application.ProtocolClient) => Effect.Effect<boolean, SewedError, MainContext>;
export declare const setDefaultProtocolClient: (client: Application.ProtocolClient) => Effect.Effect<boolean, SewedError, MainContext>;
export declare const removeDefaultProtocolClient: (client: Application.ProtocolClient) => Effect.Effect<boolean, SewedError, MainContext>;
export declare const secureKeyboardEntry: Effect.Effect<boolean, SewedError, MainContext>;
export declare const setSecureKeyboardEntry: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
/** Focus entering or leaving windows; Sewed windows are named by their id, others are null. */
export declare const windowFocus: Stream.Stream<Application.WindowFocus, SewedError, MainContext>;
export declare const childProcesses: Stream.Stream<Application.ChildProcessGone, SewedError, MainContext>;
export declare const webContentsCreated: Stream.Stream<Application.WebContentsCreated, SewedError, MainContext>;
/** macOS dock operations; every operation fails with Native elsewhere. */
export declare const dock: {
    /** Bounces the Downloads stack for a file that finished downloading, by absolute path. */
    downloadFinished: (path: string) => Effect.Effect<void, SewedError, MainContext>;
    badge: Effect.Effect<string, SewedError, MainContext>;
    setBadge: (text: string) => Effect.Effect<void, SewedError, MainContext>;
    /** A path or already-encoded bytes, over wave 3's `Image.Source`; `Native` where there is no dock. */
    setIcon: (image: ImageSource) => Effect.Effect<void, SewedError, MainContext>;
    bounce: (kind?: Application.DockBounce) => Effect.Effect<number, SewedError, MainContext>;
    cancelBounce: (id: number) => Effect.Effect<void, SewedError, MainContext>;
    hide: Effect.Effect<void, SewedError, MainContext>;
    show: Effect.Effect<void, SewedError, MainContext>;
    visible: Effect.Effect<boolean, SewedError, MainContext>;
};
/** Windows taskbar operations; every operation fails with Native elsewhere. */
export declare const taskbar: {
    /** What the user removed from the jump list, and its minimum size. */
    jumpListSettings: Effect.Effect<{
        readonly minItems: number;
        readonly removedItems: readonly {
            readonly type?: "file" | "separator" | "task";
            readonly path?: string;
            readonly program?: string;
            readonly args?: string;
            readonly title?: string;
            readonly description?: string;
            readonly iconPath?: string;
            readonly iconIndex?: number;
            readonly workingDirectory?: string;
        }[];
    }, SewedError, MainContext>;
    setUserTasks: (tasks: readonly Application.Task[]) => Effect.Effect<void, SewedError, MainContext>;
    setJumpList: (categories: readonly Application.JumpListCategory[] | null) => Effect.Effect<void, SewedError, MainContext>;
};
export type Menu = ApplicationMenu.Handle;
/**
 * Installs the application menu for the caller's scope and returns its handle: `replace` swaps
 * the menu, `selections` streams custom selections. One menu at a time; a second fails `Limit`.
 * Release stops the menu's callbacks without restoring or clearing the native menu. Step 4 of the
 * platform redesign replaces this with contributions.
 */
export declare const menu: (options: MenuSchema.ApplicationOptions) => Effect.Effect<Menu, SewedError, MainContext | Scope.Scope>;
export declare const launches: Stream.Stream<Launch.Request, SewedError, MainContext>;
export { SecondaryInstance } from "./internal/Instance.ts";
export { accessibility, active, activeChanges, activity, applicationsFolder, configureWebAuthn, emojiPanelSupported, hidden, newWindowForTab, recentDocuments, runningUnderArm64Translation, securityScopedResource, sendActionToFirstResponder, showCertificateTrustDialog, setActivationPolicy, setToastActivatorClsid, showEmojiPanel, toastActivatorClsid, } from "./internal/AppPlatform.ts";
export type { Instance } from "./internal/Instance.ts";
export type { Options as ClaimOptions } from "./internal/Instance.ts";
/**
 * Claims the single instance for the caller's scope, when the program chooses — after any
 * launcher or handoff checks it wants to run first. A second process's claim fails
 * {@link SecondaryInstance} once Electron has forwarded its arguments to this one, and that
 * process's program decides how to exit. Later launches arrive on the instance's `launches`; the
 * lock is released when the scope closes. One claim may be held at a time; a second fails `Limit`.
 */
export declare const claimInstance: (options?: Instance.Options) => Effect.Effect<Instance.Instance, SewedError | Instance.SecondaryInstance, MainContext | Scope.Scope>;
/**
 * Installs a decider for one of `Decidables.App`'s decidables against the running application's own
 * registry, for the caller's scope. This is {@link Decision.Owner}'s method: any number of deciders
 * may be installed, and the decidable's own composition (declared in `Decidables.ts`) decides among
 * them. Without a running application owner, this fails `Closed` rather than installing a decider
 * nothing will ever consult.
 */
export declare const decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: Decision.Decidable<Event, Answer, Timing, Decision.Composition, "app">, decider: Decision.DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, MainContext | Scope.Scope | R>;
export interface Activation {
    readonly hasVisibleWindows: boolean;
}
export declare const activations: Stream.Stream<Activation, SewedError, MainContext>;
export declare const quit: Effect.Effect<void, SewedError, MainContext>;
/**
 * Ends the application with exactly this exit code, once the application scope has closed and
 * its finalizers have run. It does not consult `Decidables.App.Quit`: Electron's own `app.exit`
 * fires no quit event, and a launcher that must answer a code cannot be vetoed by a feature.
 * Use {@link quit} for a quit a feature may refuse. `code` is an integer from 0 to 255. The first
 * request wins: once an exit or an accepted quit is already in progress, a further call fails
 * `Closed` and the code already requested stands — so call it from the program, not from a
 * finalizer, which runs only once a shutdown has begun.
 */
export declare const exit: (code: number) => Effect.Effect<never, SewedError, MainContext>;
/**
 * Ends the process now with exactly this code, running nothing: no finalizer, no listener, no quit
 * decider, and nothing after the call. It is for a harness whose program may hang — a timeout that
 * must answer the shell even when the program's finalizers would never finish. Everything else
 * uses {@link exit}, which closes the application scope first. `code` is an integer from 0 to 255;
 * an invalid one throws `Protocol` before anything ends.
 */
export declare const terminate: (code: number) => never;
/** Declares facts about the application that must precede readiness, such as the Windows user model id. */
export declare const declare: (options: Application.Identity) => Declaration.Declaration;
/**
 * Runs the application: installs the launch and quit listeners, applies every declaration in
 * order — failing `Startup` on the first that cannot apply — waits for Electron readiness, and
 * runs `program` under `MainContext` in the application scope until quit. A declaration is applied
 * synchronously and before readiness; asynchronous work belongs in `program`. A non-empty
 * declaration list fails `Startup` immediately, applying nothing, if Electron is already ready —
 * call `App.run` in the entry module's first synchronous pass, or after a top-level await in an
 * ES-module entry.
 */
export declare const run: <E>(declarations: readonly Declaration.Entry[], program: Effect.Effect<unknown, E, MainContext | Scope.Scope>) => import("effect/Fiber").Fiber<number | undefined, E | SewedError>;
//# sourceMappingURL=App.d.ts.map