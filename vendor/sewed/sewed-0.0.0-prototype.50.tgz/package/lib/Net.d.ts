import { Schema } from "effect";
export declare const Endpoint: Schema.Struct<{
    readonly address: Schema.String;
    readonly family: Schema.Literals<readonly ["ipv4", "ipv6", "unspec"]>;
}>;
export type Endpoint = typeof Endpoint.Type;
export declare const ResolvedHost: Schema.Struct<{
    readonly endpoints: Schema.$Array<Schema.Struct<{
        readonly address: Schema.String;
        readonly family: Schema.Literals<readonly ["ipv4", "ipv6", "unspec"]>;
    }>>;
}>;
export type ResolvedHost = typeof ResolvedHost.Type;
/** Options for resolving a host through a session's resolver. */
export declare const ResolveHostOptions: Schema.Struct<{
    readonly queryType: Schema.optionalKey<Schema.Literals<readonly ["A", "AAAA"]>>;
    readonly source: Schema.optionalKey<Schema.Literals<readonly ["any", "system", "dns", "mdns", "localOnly"]>>;
    readonly cacheUsage: Schema.optionalKey<Schema.Literals<readonly ["allowed", "staleAllowed", "disallowed"]>>;
    readonly secureDnsPolicy: Schema.optionalKey<Schema.Literals<readonly ["allow", "disable"]>>;
}>;
export type ResolveHostOptions = typeof ResolveHostOptions.Type;
/**
 * Network conditions a session emulates. `offline` cuts the session off; `latency` is the round
 * trip in milliseconds and the throughputs are in bytes per second, where zero leaves that
 * dimension unthrottled.
 */
export declare const Emulation: Schema.Struct<{
    readonly offline: Schema.optionalKey<Schema.Boolean>;
    readonly latency: Schema.optionalKey<Schema.Finite>;
    readonly downloadThroughput: Schema.optionalKey<Schema.Finite>;
    readonly uploadThroughput: Schema.optionalKey<Schema.Finite>;
}>;
export type Emulation = typeof Emulation.Type;
/** A 16-bit TLS cipher suite identifier, as in `0xC002`. */
export declare const CipherSuite: Schema.Int;
/**
 * The TLS versions and cipher suites a session accepts for new connections. TLS 1.3 suites cannot
 * be disabled this way.
 */
export declare const SSLConfig: Schema.Struct<{
    readonly minVersion: Schema.optionalKey<Schema.Literals<readonly ["tls1", "tls1.1", "tls1.2", "tls1.3"]>>;
    readonly maxVersion: Schema.optionalKey<Schema.Literals<readonly ["tls1.2", "tls1.3"]>>;
    readonly disabledCipherSuites: Schema.optionalKey<Schema.$Array<Schema.Int>>;
}>;
export type SSLConfig = typeof SSLConfig.Type;
/** How a main-process WebSocket connects: sub-protocols, extra handshake headers, and an origin. */
export declare const WebSocketOptions: Schema.Struct<{
    readonly protocols: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly headers: Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>;
    readonly origin: Schema.optionalKey<Schema.String>;
}>;
export type WebSocketOptions = typeof WebSocketOptions.Type;
/** Why a WebSocket closed. */
export declare const WebSocketClose: Schema.Struct<{
    readonly code: Schema.Finite;
    readonly reason: Schema.String;
    readonly wasClean: Schema.Boolean;
}>;
export type WebSocketClose = typeof WebSocketClose.Type;
//# sourceMappingURL=Net.d.ts.map