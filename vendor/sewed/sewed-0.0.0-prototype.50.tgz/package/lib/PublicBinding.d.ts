export { slot, to, client, deferred, pending, layer, clientContext } from "./Binding.ts";
export type { Slot, Owner, Bound, Client, Connection } from "./Binding.ts";
//# sourceMappingURL=PublicBinding.d.ts.map