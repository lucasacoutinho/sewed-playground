import { Schema } from "effect";
import type { Effect } from "effect";
import * as Binary from "./Binary.ts";
import type { SewedError } from "./SewedError.ts";
export declare const ResourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
export type ResourceType = typeof ResourceType.Type;
/**
 * Compiles a Chromium match pattern such as `https://*.example.com/api/*` or `<all_urls>` into
 * a URL predicate. A wildcard scheme matches http and https; a `*.` host prefix matches the host
 * and its subdomains; a `*` in the path matches any characters. Numeric ports must be within
 * 0-65535; explicit default ports match URLs whose parser has omitted that port.
 */
export declare const compilePattern: (pattern: string) => ((url: URL) => boolean);
export declare const Pattern: Schema.String;
/**
 * One piece of a request's upload data; file parts are metadata the library never reads. A blob
 * part keeps its `id` whether or not it was resolved: `blobs: "resolve"` fills `bytes` in beside
 * it, `blobs: "reference"` leaves `bytes` absent, and either way a rule that reads `id` can still
 * recognize the same blob after resolution instead of losing its identity to a bare `"bytes"` kind.
 */
export declare const UploadPart: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"bytes">;
    readonly bytes: Binary.Bytes;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"file">;
    readonly path: Schema.String;
    readonly offset: Schema.optionalKey<Schema.Finite>;
    readonly length: Schema.optionalKey<Schema.Finite>;
    readonly modificationTime: Schema.optionalKey<Schema.Finite>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"blob">;
    readonly id: Schema.String;
    readonly bytes: Schema.optionalKey<Binary.Bytes>;
}>]>;
export type UploadPart = typeof UploadPart.Type;
/** The upload data a request carried, kept within the filter's byte cap. */
export declare const Body: Schema.Struct<{
    readonly parts: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly kind: Schema.Literal<"bytes">;
        readonly bytes: Binary.Bytes;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"file">;
        readonly path: Schema.String;
        readonly offset: Schema.optionalKey<Schema.Finite>;
        readonly length: Schema.optionalKey<Schema.Finite>;
        readonly modificationTime: Schema.optionalKey<Schema.Finite>;
    }>, Schema.Struct<{
        readonly kind: Schema.Literal<"blob">;
        readonly id: Schema.String;
        readonly bytes: Schema.optionalKey<Binary.Bytes>;
    }>]>>;
    readonly bytes: Schema.Finite;
    readonly truncated: Schema.Boolean;
}>;
export type Body = typeof Body.Type;
/** Asks the request stage for upload data, capped in bytes; blobs are read or referenced. */
export declare const BodyFilter: Schema.Struct<{
    readonly maxBytes: Schema.Int;
    readonly blobs: Schema.Literals<readonly ["resolve", "reference"]>;
}>;
export type BodyFilter = typeof BodyFilter.Type;
/** Which requests a set of deciders sees; patterns follow Chromium's match pattern syntax. */
export declare const Filter: Schema.Struct<{
    readonly urls: Schema.NonEmptyArray<Schema.String>;
    readonly types: Schema.optionalKey<Schema.NonEmptyArray<Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>>>;
    readonly body: Schema.optionalKey<Schema.Struct<{
        readonly maxBytes: Schema.Int;
        readonly blobs: Schema.Literals<readonly ["resolve", "reference"]>;
    }>>;
}>;
export type Filter = typeof Filter.Type;
export declare const Request: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly body: Schema.optionalKey<Schema.Struct<{
        readonly parts: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly kind: Schema.Literal<"bytes">;
            readonly bytes: Binary.Bytes;
        }>, Schema.Struct<{
            readonly kind: Schema.Literal<"file">;
            readonly path: Schema.String;
            readonly offset: Schema.optionalKey<Schema.Finite>;
            readonly length: Schema.optionalKey<Schema.Finite>;
            readonly modificationTime: Schema.optionalKey<Schema.Finite>;
        }>, Schema.Struct<{
            readonly kind: Schema.Literal<"blob">;
            readonly id: Schema.String;
            readonly bytes: Schema.optionalKey<Binary.Bytes>;
        }>]>>;
        readonly bytes: Schema.Finite;
        readonly truncated: Schema.Boolean;
    }>>;
}>;
export type Request = typeof Request.Type;
/**
 * What `request.readBody(options?)` assembles under, all optional: a field left out takes the
 * install's own `body` filter option when it named one, else `{ maxBytes: 3_000_000, blobs:
 * "reference" }`. See `internal/WebRequest.ts`'s `readBodyFor` for where that default is chosen —
 * per install, not per request, since two installs on the same request may have asked differently.
 */
export declare const ReadBodyOptions: Schema.Struct<{
    readonly maxBytes: Schema.optionalKey<Schema.Int>;
    readonly blobs: Schema.optionalKey<Schema.Literals<readonly ["resolve", "reference"]>>;
}>;
export type ReadBodyOptions = typeof ReadBodyOptions.Type;
/**
 * Reads the body a request carried, assembled lazily so one install over `<all_urls>` pays for it
 * only on the request whose decider actually calls this. Fails `Limit` when the assembled body
 * would exceed its own `maxBytes` — unlike the install-time `body` option, which truncates rather
 * than fails, because a decider that explicitly asked should not silently receive less than it
 * asked for and mistake it for the whole body.
 */
export interface ReadBody {
    (options?: ReadBodyOptions): Effect.Effect<Body, SewedError>;
}
/**
 * The request stage's own event: everything {@link Request} carries, plus the lazy `readBody`.
 * Only this stage carries upload data — the two header stages refuse a filter that asks for a
 * `body` at all — so only this event schema, `Decidables.Session.Request`'s own, gains the field.
 */
export declare const RequestEvent: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly body: Schema.optionalKey<Schema.Struct<{
        readonly parts: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly kind: Schema.Literal<"bytes">;
            readonly bytes: Binary.Bytes;
        }>, Schema.Struct<{
            readonly kind: Schema.Literal<"file">;
            readonly path: Schema.String;
            readonly offset: Schema.optionalKey<Schema.Finite>;
            readonly length: Schema.optionalKey<Schema.Finite>;
            readonly modificationTime: Schema.optionalKey<Schema.Finite>;
        }>, Schema.Struct<{
            readonly kind: Schema.Literal<"blob">;
            readonly id: Schema.String;
            readonly bytes: Schema.optionalKey<Binary.Bytes>;
        }>]>>;
        readonly bytes: Schema.Finite;
        readonly truncated: Schema.Boolean;
    }>>;
    readonly readBody: Schema.declare<ReadBody, ReadBody>;
}>;
export type RequestEvent = typeof RequestEvent.Type;
export declare const RequestDecision: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"allow">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"block">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"redirect">;
    readonly url: Schema.String;
}>]>;
export type RequestDecision = typeof RequestDecision.Type;
export declare const RequestHeaders: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly headers: Schema.$Record<Schema.String, Schema.String>;
}>;
export type RequestHeaders = typeof RequestHeaders.Type;
export declare const RequestHeadersDecision: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"allow">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"block">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"headers">;
    readonly headers: Schema.$Record<Schema.String, Schema.String>;
}>]>;
export type RequestHeadersDecision = typeof RequestHeadersDecision.Type;
export declare const Response: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly statusLine: Schema.String;
    readonly statusCode: Schema.Finite;
    readonly headers: Schema.$Record<Schema.String, Schema.$Array<Schema.String>>;
}>;
export type Response = typeof Response.Type;
export declare const ResponseDecision: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"allow">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"block">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"headers">;
    readonly headers: Schema.$Record<Schema.String, Schema.$Array<Schema.String>>;
    readonly statusLine: Schema.optionalKey<Schema.String>;
}>]>;
export type ResponseDecision = typeof ResponseDecision.Type;
/** Observation-only stages of a request's life; deciders never see these. */
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly stage: Schema.Literal<"sent">;
    readonly headers: Schema.$Record<Schema.String, Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly fromCache: Schema.Boolean;
    readonly stage: Schema.Literal<"response">;
    readonly statusCode: Schema.Finite;
    readonly statusLine: Schema.String;
    readonly headers: Schema.$Record<Schema.String, Schema.$Array<Schema.String>>;
}>, Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly fromCache: Schema.Boolean;
    readonly stage: Schema.Literal<"redirect">;
    readonly statusCode: Schema.Finite;
    readonly redirectUrl: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly fromCache: Schema.Boolean;
    readonly stage: Schema.Literal<"completed">;
    readonly statusCode: Schema.Finite;
    readonly statusLine: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.Finite;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["mainFrame", "subFrame", "stylesheet", "script", "image", "font", "object", "xhr", "ping", "cspReport", "media", "webSocket", "other"]>;
    readonly referrer: Schema.String;
    readonly timestamp: Schema.Finite;
    readonly webContentsId: Schema.optionalKey<Schema.Finite>;
    readonly sourceId: Schema.optionalKey<Schema.String>;
    readonly fromCache: Schema.Boolean;
    readonly stage: Schema.Literal<"error">;
    readonly error: Schema.String;
}>]>;
export type Event = typeof Event.Type;
//# sourceMappingURL=WebRequest.d.ts.map