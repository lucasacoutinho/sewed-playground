import { Effect } from "effect";
import * as Application from "./Application.ts";
import type * as Declaration from "./Declaration.ts";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
/** Declares one Chromium command-line switch, appended before readiness. One switch per declaration. */
export declare const declare: (flag: Application.CommandLineSwitch) => Declaration.Declaration;
/** Whether the process was started with a switch, named without its leading dashes. */
export declare const has: (name: string) => Effect.Effect<boolean, SewedError, MainContext>;
/** A switch's value; empty when the switch is absent or carries none. */
export declare const value: (name: string) => Effect.Effect<string, SewedError, MainContext>;
//# sourceMappingURL=CommandLine.d.ts.map