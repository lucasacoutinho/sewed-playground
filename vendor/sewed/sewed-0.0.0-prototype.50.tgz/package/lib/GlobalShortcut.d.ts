import { Schema } from "effect";
export declare const Accelerator: Schema.String;
export type Accelerator = typeof Accelerator.Type;
//# sourceMappingURL=GlobalShortcut.d.ts.map