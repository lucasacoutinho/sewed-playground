import { Schema } from "effect";
export declare const IconPosition: Schema.Literals<readonly ["left", "right", "overlay"]>;
export declare const SpacerSize: Schema.Literals<readonly ["small", "large", "flexible"]>;
export declare const SegmentedMode: Schema.Literals<readonly ["single", "multiple", "buttons"]>;
export declare const SegmentStyle: Schema.Literals<readonly ["automatic", "rounded", "textured-rounded", "round-rect", "textured-square", "capsule", "small-square", "separated"]>;
export interface Button {
    readonly kind: "button";
    readonly id: string;
    readonly label?: string;
    readonly accessibilityLabel?: string;
    readonly backgroundColor?: string;
    readonly icon?: string;
    readonly iconPosition?: typeof IconPosition.Type;
    readonly enabled?: boolean;
}
export interface Label {
    readonly kind: "label";
    readonly label: string;
    readonly textColor?: string;
}
export interface Spacer {
    readonly kind: "spacer";
    readonly size?: typeof SpacerSize.Type;
}
export interface Slider {
    readonly kind: "slider";
    readonly id: string;
    readonly label?: string;
    readonly value?: number;
    readonly minValue?: number;
    readonly maxValue?: number;
}
export interface SegmentedControl {
    readonly kind: "segmented";
    readonly id: string;
    readonly segments: readonly [Segment, ...Segment[]];
    readonly selectedIndex?: number;
    readonly mode?: typeof SegmentedMode.Type;
    readonly segmentStyle?: typeof SegmentStyle.Type;
}
export interface Segment {
    readonly label?: string;
    readonly enabled?: boolean;
}
export interface ColorPicker {
    readonly kind: "color-picker";
    readonly id: string;
    readonly availableColors?: readonly string[];
    readonly selectedColor?: string;
}
/** A scrollable strip of items; selecting or passing over one reports its index. */
export interface Scrubber {
    readonly kind: "scrubber";
    readonly id: string;
    readonly items: readonly {
        readonly label?: string;
    }[];
    readonly selectedStyle?: "background" | "outline" | "none";
    readonly overlayStyle?: "background" | "outline" | "none";
    readonly showArrowButtons?: boolean;
    readonly mode?: "fixed" | "free";
    readonly continuous?: boolean;
}
/** Where the system's own items go, such as the Control Strip; at most one per bar. */
export interface OtherItemsProxy {
    readonly kind: "other-items-proxy";
}
export interface Popover {
    readonly kind: "popover";
    readonly id: string;
    readonly label?: string;
    readonly showCloseButton?: boolean;
    readonly items: readonly Item[];
}
export interface Group {
    readonly kind: "group";
    readonly items: readonly Item[];
}
export type Item = Button | Label | Spacer | Slider | SegmentedControl | ColorPicker | Popover | Group | Scrubber | OtherItemsProxy;
declare const ItemSchema: Schema.Codec<Item>;
export { ItemSchema as Item };
/** A whole touch bar: item ids are unique across nested popovers and groups. */
export declare const Options: Schema.Struct<{
    readonly items: Schema.$Array<Schema.Codec<Item, Item, never, never>>;
    readonly escapeItem: Schema.optionalKey<Schema.Codec<Item, Item, never, never>>;
}>;
export type Options = typeof Options.Type;
export declare const Interaction: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"click">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"slider">;
    readonly id: Schema.String;
    readonly value: Schema.Finite;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"segment">;
    readonly id: Schema.String;
    readonly index: Schema.Int;
    readonly selected: Schema.Boolean;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"color">;
    readonly id: Schema.String;
    readonly color: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"scrubber">;
    readonly id: Schema.String;
    readonly index: Schema.Int;
    readonly change: Schema.Literals<readonly ["select", "highlight"]>;
}>]>;
export type Interaction = typeof Interaction.Type;
//# sourceMappingURL=TouchBar.d.ts.map