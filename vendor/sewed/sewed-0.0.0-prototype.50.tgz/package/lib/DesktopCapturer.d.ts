import { Schema } from "effect";
import * as Binary from "./Binary.ts";
export declare const SourceType: Schema.Literals<readonly ["screen", "window"]>;
export type SourceType = typeof SourceType.Type;
export declare const Options: Schema.Struct<{
    readonly types: Schema.NonEmptyArray<Schema.Literals<readonly ["screen", "window"]>>;
    readonly thumbnailSize: Schema.optionalKey<Schema.Struct<{
        readonly width: Schema.Int;
        readonly height: Schema.Int;
    }>>;
    readonly fetchWindowIcons: Schema.optionalKey<Schema.Boolean>;
}>;
export type Options = typeof Options.Type;
/** A capturable screen or window; thumbnails and icons are PNG bytes, empty when not fetched. */
export declare const Source: Schema.Struct<{
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly displayId: Schema.String;
    readonly thumbnail: Binary.Bytes;
    readonly icon: Schema.NullOr<Binary.Bytes>;
}>;
export type Source = typeof Source.Type;
/**
 * `origin` is `null` when the requesting document's origin is opaque (`file:`, `data:`, an
 * unregistered scheme): `URL.origin` reports the literal string `"null"` for every such document,
 * which is Chromium's own spelling for "this document has no origin", not a real identity — the same
 * reasoning `Decidables.Session.Permission`'s own doc gives for its `origin` field. See
 * `internal/DisplayMedia.ts`'s event builder.
 */
export declare const Request: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly videoRequested: Schema.Boolean;
    readonly audioRequested: Schema.Boolean;
    readonly userGesture: Schema.Boolean;
}>;
export type Request = typeof Request.Type;
/** What a display media request receives: nothing, or one capture source with optional system audio. */
export declare const Decision: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"deny">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"source">;
    readonly id: Schema.String;
    readonly audio: Schema.optionalKey<Schema.Literals<readonly ["loopback", "loopbackWithMute"]>>;
}>]>;
export type Decision = typeof Decision.Type;
//# sourceMappingURL=DesktopCapturer.d.ts.map