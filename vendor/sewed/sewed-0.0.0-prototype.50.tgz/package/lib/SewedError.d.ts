import { Schema } from "effect";
declare const SewedError_base: Schema.Class<SewedError, Schema.TaggedStruct<"SewedError", {
    readonly code: Schema.Literals<readonly ["Closed", "Protocol", "Limit", "Startup", "Native", "Unknown"]>;
    readonly message: Schema.String;
    readonly cause: Schema.optionalKey<Schema.decodeTo<Schema.Unknown, Schema.Codec<Schema.Json, Schema.Json, never, never>, never, never>>;
    /**
     * A stable identifier for why this error occurred, set only at the sites that document one
     * (`docs/api.md`'s "Reasons" list is the index). Most failures carry no `reason`: the field
     * exists for a caller that must branch on the specific cause, not on `code` or `message` alone.
     */
    readonly reason: Schema.optionalKey<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class SewedError extends SewedError_base {
}
export {};
//# sourceMappingURL=SewedError.d.ts.map