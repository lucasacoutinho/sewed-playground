import { Effect } from "effect";
import { MainContext } from "./RuntimeContext.ts";
import { SewedError } from "./SewedError.ts";
import * as Native from "./internal/Session.ts";
import type { Handle } from "./internal/Session.ts";
export type { Handle };
export type { Handle as Cookies } from "./internal/Cookies.ts";
export type { SpellChecker } from "./internal/SessionSettings.ts";
export type { ServiceWorkers } from "./internal/ServiceWorkers.ts";
export { addSpellCheckerWord, cacheSize, clearAuthCache, clearCache, clearCodeCaches, clearHostResolverCache, clearNetworkEmulation, flushStorage, forceReloadProxyConfig, removeSpellCheckerWord, resolveProxy, setDownloadPath, setNetworkEmulation, setProxy, setSpellChecker, setSSLConfig, setUserAgent, spellChecker, spellCheckerWords, storagePath, userAgent, } from "./internal/SessionSettings.ts";
export { deviceChanges, setUsbProtectedClasses } from "./internal/SessionDevices.ts";
export { resumeDownload } from "./internal/SessionDownloads.ts";
export { allowNtlmCredentialsForDomains, clearData, clearSharedDictionaries, extensionEvents, extensions, isProtocolHandled, preloadScripts, registerPreloadScript, setCodeCachePath, setSpellCheckerDictionaryDownloadUrl, sharedDictionaries, sharedDictionaryUsage, spellCheckerDictionaries, } from "./internal/SessionData.ts";
export { loadExtension } from "./internal/Extensions.ts";
export { serviceWorkers } from "./internal/ServiceWorkers.ts";
export type Partition = Native.Partition;
/**
 * Selects a native browser session by kind and name. `cookies`, `clearStorage`,
 * `closeAllConnections`, `resolveHost`, `blobData`, `requests`, `decide`, and `intercept` are
 * methods on the returned handle, matching how a window and a web contents already read; the
 * settings below stay free functions taking the handle, since they are not moving in this wave.
 */
export declare const fromPartition: (partition: Partition) => Effect.Effect<Handle, SewedError, MainContext>;
/**
 * A persistent session stored at an absolute directory of the application's choosing, instead of
 * under the user data directory by partition name. `cache: false` keeps its HTTP cache off disk.
 */
export declare const fromPath: (directory: string, options?: {
    readonly cache?: boolean;
}) => Effect.Effect<Handle, SewedError, MainContext>;
export declare const defaultSession: Effect.Effect<Handle, SewedError, MainContext>;
//# sourceMappingURL=Session.d.ts.map