import type { BrowserWindow, MenuItemConstructorOptions } from "electron";
import { Effect } from "effect";
import * as Menu from "../Menu.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export declare const template: (items: readonly (Menu.Item | Menu.ApplicationItem)[], select: (result: Menu.Selection) => void) => MenuItemConstructorOptions[];
export declare const menus: (parent: BrowserWindow) => {
    /** Opens the macOS share sheet for the item; `Native` on other platforms. */
    share: (item: Menu.SharingItem, position?: {
        readonly x: number;
        readonly y: number;
    }) => Effect.Effect<void, SewedError, MainContext>;
    popup: (options: Menu.PopupOptions) => Effect.Effect<Menu.PopupResult, SewedError, MainContext>;
};
//# sourceMappingURL=Menu.d.ts.map