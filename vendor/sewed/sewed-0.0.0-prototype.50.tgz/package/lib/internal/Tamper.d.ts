import type { Connection } from "./Transport.ts";
/**
 * Which messages a test corrupts on purpose, by the operation's tag. A corrupted message still
 * parses and still names its request, so the call fails exactly as a genuinely undecodable one
 * does and every other call on the connection continues.
 */
export interface Tamper {
    /**
     * Corrupts the answer to each request on an operation this selects, owner to client: its `Exit`,
     * its first stream value, or its first bulk-answer part. The handler ran; the call fails
     * `Protocol` with `reason: "transport/undecodable-answer"`.
     */
    readonly answer?: (tag: string) => boolean;
    /**
     * Corrupts each request on an operation this selects, client to owner, or a bulk request's
     * first part. The handler does not run; the call fails `Protocol` with
     * `reason: "transport/undecodable-request"`.
     */
    readonly request?: (tag: string) => boolean;
}
/** `connection` with the messages `tamper` selects corrupted on their way through. */
export declare const tampered: (tamper: Tamper) => (connection: Connection) => Connection;
//# sourceMappingURL=Tamper.d.ts.map