import type { BaseWindow as NativeBaseWindow, WebContents as NativeWebContents } from "electron";
import { Deferred, Effect, Scope, Stream } from "effect";
import type { Source as ImageSource } from "../Image.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as View from "./View.ts";
import * as TouchBar from "./TouchBar.ts";
import * as WindowControls from "../WindowControls.ts";
import { Options as OptionsSchema } from "./WindowOptions.ts";
export type AttachOptions = View.AttachOptions;
/** Any Sewed window handle; the registry resolves it to its native window. */
export interface Parent {
    readonly id: string;
}
export type Options = OptionsSchema;
export declare const register: (handle: {
    readonly id: string;
}, native: NativeBaseWindow) => void;
/** Whether the native window behind a handle still exists. */
export declare const isOpen: (handle: object) => boolean;
/** The Sewed id of a native window, or undefined for windows the library did not create. */
export declare const idOf: (native: NativeBaseWindow) => string | undefined;
/** Validates plain options and resolves the parent handle into Electron's constructor options. */
export declare const nativeOptions: (options: Options, parent: Parent | undefined) => {
    readonly title?: string;
    readonly width?: number;
    readonly height?: number;
    readonly x?: number;
    readonly y?: number;
    readonly minWidth?: number;
    readonly minHeight?: number;
    readonly maxWidth?: number;
    readonly maxHeight?: number;
    readonly show?: boolean;
    readonly frame?: boolean;
    readonly transparent?: boolean;
    readonly backgroundColor?: string;
    readonly alwaysOnTop?: boolean;
    readonly resizable?: boolean;
    readonly movable?: boolean;
    readonly minimizable?: boolean;
    readonly maximizable?: boolean;
    readonly closable?: boolean;
    readonly fullScreenable?: boolean;
    readonly skipTaskbar?: boolean;
    readonly kiosk?: boolean;
    readonly autoHideMenuBar?: boolean;
    readonly opacity?: number;
    readonly icon?: string;
    readonly modal?: boolean;
    readonly titleBarStyle?: "customButtonsOnHover" | "default" | "hidden" | "hiddenInset";
    readonly useContentSize?: boolean;
    readonly center?: boolean;
    readonly focusable?: boolean;
    readonly hasShadow?: boolean;
    readonly darkTheme?: boolean;
    readonly roundedCorners?: boolean;
    readonly thickFrame?: boolean;
    readonly titleBarOverlay?: boolean | {
        readonly color?: string;
        readonly symbolColor?: string;
        readonly height?: number;
    };
    readonly vibrancy?: "content" | "fullscreen-ui" | "header" | "hud" | "menu" | "popover" | "selection" | "sheet" | "sidebar" | "titlebar" | "tooltip" | "under-page" | "under-window" | "window";
    readonly visualEffectState?: "active" | "followWindow" | "inactive";
    readonly backgroundMaterial?: "acrylic" | "auto" | "mica" | "none" | "tabbed";
    readonly tabbingIdentifier?: string;
    readonly hiddenInMissionControl?: boolean;
    readonly acceptFirstMouse?: boolean;
    readonly type?: string;
    readonly name?: string;
    readonly windowStatePersistence?: boolean | {
        readonly bounds?: boolean;
        readonly displayMode?: boolean;
    };
    readonly trafficLightPosition?: {
        readonly x: number;
        readonly y: number;
    };
} | {
    title?: string;
    width?: number;
    height?: number;
    x?: number;
    y?: number;
    minWidth?: number;
    minHeight?: number;
    maxWidth?: number;
    maxHeight?: number;
    show?: boolean;
    frame?: boolean;
    transparent?: boolean;
    backgroundColor?: string;
    alwaysOnTop?: boolean;
    resizable?: boolean;
    movable?: boolean;
    minimizable?: boolean;
    maximizable?: boolean;
    closable?: boolean;
    fullScreenable?: boolean;
    skipTaskbar?: boolean;
    kiosk?: boolean;
    autoHideMenuBar?: boolean;
    opacity?: number;
    icon?: string;
    modal?: boolean;
    titleBarStyle?: "customButtonsOnHover" | "default" | "hidden" | "hiddenInset";
    useContentSize?: boolean;
    center?: boolean;
    focusable?: boolean;
    hasShadow?: boolean;
    darkTheme?: boolean;
    roundedCorners?: boolean;
    thickFrame?: boolean;
    titleBarOverlay?: boolean | {
        readonly color?: string;
        readonly symbolColor?: string;
        readonly height?: number;
    };
    vibrancy?: "content" | "fullscreen-ui" | "header" | "hud" | "menu" | "popover" | "selection" | "sheet" | "sidebar" | "titlebar" | "tooltip" | "under-page" | "under-window" | "window";
    visualEffectState?: "active" | "followWindow" | "inactive";
    backgroundMaterial?: "acrylic" | "auto" | "mica" | "none" | "tabbed";
    tabbingIdentifier?: string;
    hiddenInMissionControl?: boolean;
    acceptFirstMouse?: boolean;
    type?: string;
    name?: string;
    windowStatePersistence?: boolean | {
        readonly bounds?: boolean;
        readonly displayMode?: boolean;
    };
    trafficLightPosition?: {
        readonly x: number;
        readonly y: number;
    };
    parent: NativeBaseWindow;
};
export declare const make: (native: NativeBaseWindow, primary?: NativeWebContents) => Effect.Effect<{
    setFocusable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    focusable: Effect.Effect<boolean, SewedError, MainContext>;
    contentProtected: Effect.Effect<boolean, SewedError, MainContext>;
    setRepresentedFilename: (path: string) => Effect.Effect<void, SewedError, MainContext>;
    representedFilename: Effect.Effect<string, SewedError, MainContext>;
    setDocumentEdited: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    documentEdited: Effect.Effect<boolean, SewedError, MainContext>;
    setVibrancy: (vibrancy: WindowControls.Vibrancy) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonPosition: (position: import("./Geometry.ts").Point | null) => Effect.Effect<void, SewedError, MainContext>;
    windowButtonPosition: Effect.Effect<{
        x: number;
        y: number;
    } | null, SewedError, MainContext>;
    setSheetOffset: (offset: {
        readonly y: number;
        readonly x?: number;
    }) => Effect.Effect<void, SewedError, MainContext>;
    previewFile: (path: string, displayName?: string) => Effect.Effect<void, SewedError, MainContext>;
    closeFilePreview: Effect.Effect<void, SewedError, MainContext>;
    setHiddenInMissionControl: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    hiddenInMissionControl: Effect.Effect<boolean, SewedError, MainContext>;
    setAutoHideCursor: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    invalidateShadow: Effect.Effect<void, SewedError, MainContext>;
    setExcludedFromShownWindowsMenu: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    excludedFromShownWindowsMenu: Effect.Effect<boolean, SewedError, MainContext>;
    tabs: {
        identifier: Effect.Effect<string | null, SewedError, MainContext>;
        selectNext: Effect.Effect<void, SewedError, MainContext>;
        selectPrevious: Effect.Effect<void, SewedError, MainContext>;
        showAll: Effect.Effect<void, SewedError, MainContext>;
        mergeAll: Effect.Effect<void, SewedError, MainContext>;
        moveToNewWindow: Effect.Effect<void, SewedError, MainContext>;
        toggleBar: Effect.Effect<void, SewedError, MainContext>;
        add: (window: {
            readonly id: string;
        }) => Effect.Effect<void, SewedError, MainContext>;
    };
    setAccentColor: (color: WindowControls.AccentColor) => Effect.Effect<void, SewedError, MainContext>;
    setAppDetails: (details: WindowControls.AppDetails) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundMaterial: (material: WindowControls.BackgroundMaterial) => Effect.Effect<void, SewedError, MainContext>;
    setThumbarButtons: (buttons: ReadonlyArray<WindowControls.ThumbarButton>) => Effect.Effect<void, SewedError, MainContext>;
    thumbarClicks: Stream.Stream<string, SewedError, MainContext>;
    setThumbnailClip: (region: WindowControls.Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setThumbnailToolTip: (text: string) => Effect.Effect<void, SewedError, MainContext>;
    snapped: Effect.Effect<boolean, SewedError, MainContext>;
    tabletMode: Effect.Effect<boolean, SewedError, MainContext>;
    windowMessages: (message: number) => Stream.Stream<WindowControls.WindowMessage, SewedError, MainContext>;
    native: NativeBaseWindow;
    closed: Deferred.Deferred<void, never>;
    webContents: {
        frames: (options?: import("../WebContents.ts").FrameOptions) => Stream.Stream<import("../WebContents.ts").Frame, SewedError, MainContext>;
        painting: Effect.Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, SewedError, MainContext>;
        setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setFrameRate: (rate: import("../WebContents.ts").FrameRate) => Effect.Effect<void, SewedError, MainContext>;
        invalidate: Effect.Effect<void, SewedError, MainContext>;
        frameTree: Effect.Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], SewedError, MainContext>;
        opener: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        focusedFrame: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        hostId: Effect.Effect<string | null, SewedError, MainContext>;
        devToolsContentsId: Effect.Effect<number | null, SewedError, MainContext>;
        collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        zoomLevel: Effect.Effect<number, SewedError, MainContext>;
        setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => Effect.Effect<void, SewedError, MainContext>;
        zoomMode: Effect.Effect<"default" | "disabled" | "isolated" | "manual", SewedError, MainContext>;
        setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => Effect.Effect<void, SewedError, MainContext>;
        rendererProcessId: Effect.Effect<number, SewedError, MainContext>;
        sharedWorkers: Effect.Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], SewedError, MainContext>;
        inspectSharedWorker: (id: string) => Effect.Effect<void, SewedError, MainContext>;
        devToolsTargetId: Effect.Effect<string, SewedError, MainContext>;
        addDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        removeDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        printers: Effect.Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], SewedError, MainContext>;
        webRtc: Effect.Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, SewedError, MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => Effect.Effect<void, SewedError, MainContext>;
        setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => Effect.Effect<void, SewedError, MainContext>;
        caretBrowsing: Effect.Effect<boolean, SewedError, MainContext>;
        setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
        events: Stream.Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, SewedError, MainContext>;
        activity: Effect.Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, SewedError, MainContext>;
        devTools: Effect.Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, SewedError, MainContext>;
        toggleDevTools: Effect.Effect<void, SewedError, MainContext>;
        setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
        inspectElement: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, MainContext>;
        enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => Effect.Effect<void, SewedError, MainContext>;
        disableDeviceEmulation: Effect.Effect<void, SewedError, MainContext>;
        edit: (command: import("../WebContents.ts").EditCommand) => Effect.Effect<void, SewedError, MainContext>;
        replace: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => Effect.Effect<void, SewedError, MainContext>;
        copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        copyImageAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => Effect.Effect<void, SewedError, MainContext>;
        setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => Effect.Effect<void, SewedError, MainContext>;
        startDrag: (drag: import("../WebContents.ts").Drag) => Effect.Effect<void, SewedError, MainContext>;
        showDefinitionForSelection: Effect.Effect<void, SewedError, MainContext>;
        takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        blocked: Stream.Stream<{
            readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
            readonly url: string;
        }, SewedError, MainContext>;
        webviews: Stream.Stream<import("./ContentsWebviews.ts").Handle, SewedError, MainContext>;
        load: <Keys extends string, const B extends readonly import("../Binding.ts").Bound<Keys>[]>(entry: import("../Renderer.ts").Entry<Keys> & import("../Binding.ts").Complete<Keys, B>, options: {
            readonly bindings: B;
        }) => Effect.Effect<undefined, SewedError, MainContext>;
        reload: Effect.Effect<void, SewedError, MainContext>;
        reloadIgnoringCache: Effect.Effect<void, SewedError, MainContext>;
        stopLoading: Effect.Effect<void, SewedError, MainContext>;
        downloads: Stream.Stream<import("./Download.ts").Handle, SewedError, MainContext>;
        print: (options?: import("../WebContents.ts").PrintOptions) => Effect.Effect<void, SewedError, MainContext>;
        pdf: (options?: import("../WebContents.ts").PdfOptions) => Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
        capture: (options?: import("../WebContents.ts").CaptureOptions) => Effect.Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, SewedError, MainContext>;
        zoom: Stream.Stream<{
            readonly factor: number;
        }, never, MainContext>;
        setZoom: (factor: number) => Effect.Effect<void, SewedError, MainContext>;
        audio: Stream.Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, MainContext>;
        setAudioMuted: (muted: boolean) => Effect.Effect<void, SewedError, MainContext>;
        userAgent: Effect.Effect<string, SewedError, MainContext>;
        setUserAgent: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
        insertText: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        savePage: (path: string, type?: import("../WebContents.ts").SaveType) => Effect.Effect<void, SewedError, MainContext>;
        setBackgroundThrottling: (allowed: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
        find: (text: string, options?: import("../WebContents.ts").FindOptions) => Effect.Effect<import("../WebContents.ts").Search, SewedError, MainContext | Scope.Scope>;
        findNext: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
        stopFind: (action?: import("../WebContents.ts").FindStop) => Effect.Effect<void, SewedError, MainContext>;
        style: (css: string, options?: import("../WebContents.ts").StyleOptions) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
        history: Stream.Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, MainContext>;
        back: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        forward: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        go: (index: number) => Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        removeHistoryEntry: (index: number) => Effect.Effect<void, SewedError, MainContext>;
        clearHistory: Effect.Effect<void, SewedError, MainContext>;
        openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => Effect.Effect<void, SewedError, MainContext>;
        openDevToolsIn: (host: import("./WebContentsView.ts").Handle, options?: import("../WebContents.ts").DevToolsHostOptions) => Effect.Effect<void, SewedError, MainContext>;
        closeDevTools: Effect.Effect<void, SewedError, MainContext>;
        focus: Effect.Effect<void, SewedError, MainContext>;
        console: Stream.Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, SewedError, MainContext>;
        state: Stream.Stream<{
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, MainContext>;
        responsiveness: Stream.Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, MainContext>;
        favicons: Stream.Stream<readonly string[], never, MainContext>;
        title: Stream.Stream<string, never, MainContext>;
        current: Effect.Effect<{
            readonly state: {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, SewedError, MainContext>;
        terminate: Effect.Effect<void, SewedError, MainContext>;
        recover: Effect.Effect<void, SewedError, MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | Scope.Scope>;
    } | undefined;
    id: string;
    current: Effect.Effect<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, SewedError, MainContext>;
    show: Effect.Effect<void, SewedError, MainContext>;
    showInactive: Effect.Effect<void, SewedError, MainContext>;
    hide: Effect.Effect<void, SewedError, MainContext>;
    focus: Effect.Effect<void, SewedError, MainContext>;
    setBounds: (bounds: WindowControls.BoundsUpdate) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreen: (fullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSimpleFullScreen: (simpleFullScreen: boolean) => Effect.Effect<void, SewedError, MainContext>;
    minimize: Effect.Effect<void, SewedError, MainContext>;
    maximize: Effect.Effect<void, SewedError, MainContext>;
    restore: Effect.Effect<void, SewedError, MainContext>;
    close: Effect.Effect<void, SewedError, MainContext>;
    setTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    setAlwaysOnTop: (alwaysOnTop: boolean, level?: WindowControls.AlwaysOnTopLevel) => Effect.Effect<void, SewedError, MainContext>;
    setOpacity: (opacity: number) => Effect.Effect<void, SewedError, MainContext>;
    setResizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMovable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMaximizable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setClosable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setFullScreenable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMenuBarVisibility: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setKiosk: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setSkipTaskbar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setContentProtection: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    flash: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setWindowButtonVisibility: (visible: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setProgress: (progress: number, mode?: WindowControls.ProgressMode) => Effect.Effect<void, SewedError, MainContext>;
    setOverlayIcon: (icon: ImageSource | null, description: string) => Effect.Effect<void, SewedError, MainContext>;
    setIcon: (icon: ImageSource) => Effect.Effect<void, SewedError, MainContext>;
    setParent: (parent: Parent | null) => Effect.Effect<void, SewedError, MainContext>;
    /** Whether the window takes input; a disabled window ignores mouse and keyboard. */
    setEnabled: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    /** Lets mouse events pass through the window to whatever is beneath it. */
    setIgnoreMouseEvents: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setAutoHideMenuBar: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setVisibleOnAllWorkspaces: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setMinimumSize: (size: WindowControls.Size) => Effect.Effect<void, SewedError, MainContext>;
    /** Zero in a dimension leaves that dimension unlimited. */
    setMaximumSize: (size: WindowControls.Size) => Effect.Effect<void, SewedError, MainContext>;
    /** Keeps `ratio` (width over height) while resizing, not counting `extra`; zero removes it. */
    setAspectRatio: (ratio: number, extra?: WindowControls.Size) => Effect.Effect<void, SewedError, MainContext>;
    setBackgroundColor: (color: string) => Effect.Effect<void, SewedError, MainContext>;
    setHasShadow: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
    /** Places the content area, not the frame, at `bounds`. */
    setContentBounds: (bounds: WindowControls.Bounds) => Effect.Effect<void, SewedError, MainContext>;
    setContentSize: (size: WindowControls.Size) => Effect.Effect<void, SewedError, MainContext>;
    /** Raises the window just above another, named by its media source id (`mediaSourceId`). */
    moveAbove: (mediaSourceId: string) => Effect.Effect<void, SewedError, MainContext>;
    /** The title assistive technology reads instead of the window's own. */
    setAccessibleTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
    /** Restyles the native controls of a window created with a title bar overlay. */
    setTitleBarOverlay: (overlay: WindowControls.TitleBarOverlay) => Effect.Effect<void, SewedError, MainContext>;
    /** Makes only the given rectangles of the window drawn and clickable, on Linux and Windows. */
    setShape: (rectangles: ReadonlyArray<WindowControls.Bounds>) => Effect.Effect<void, SewedError, MainContext>;
    /** Removes the window's menu bar, on Linux and Windows. */
    removeMenu: Effect.Effect<void, SewedError, MainContext>;
    /** What happens to the window outside its state: see `WindowControls.Event`. */
    events: Stream.Stream<{
        readonly kind: "ready-to-show";
    } | {
        readonly kind: "persisted-state-restored";
    } | {
        readonly kind: "app-command";
        readonly command: string;
    } | {
        readonly kind: "moved" | "resized";
    } | {
        readonly kind: "will-move" | "will-resize";
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly edge?: string;
    } | {
        readonly kind: "swipe";
        readonly direction: string;
    } | {
        readonly kind: "rotate-gesture";
        readonly rotation: number;
    } | {
        readonly kind: "sheet-begin" | "sheet-end";
    } | {
        readonly kind: "new-window-for-tab";
    } | {
        readonly kind: "session-end";
        readonly reasons: readonly string[];
    } | {
        readonly kind: "system-context-menu";
        readonly x: number;
        readonly y: number;
    }, SewedError, MainContext>;
    /** Moves the window to the center of its display. */
    center: Effect.Effect<void, SewedError, MainContext>;
    /** Raises the window above the others without focusing it. */
    moveTop: Effect.Effect<void, SewedError, MainContext>;
    /**
     * Installs a decider for `Decidables.Window.Close` against this window's own registry, for
     * the caller's scope. Any number of deciders may be installed, and the decidable's own
     * composition decides among them. The decider sees the window's own id.
     */
    decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "window">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | Scope.Scope>;
    state: Stream.Stream<{
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly normalBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly contentBounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
        readonly visible: boolean;
        readonly focused: boolean;
        readonly minimized: boolean;
        readonly maximized: boolean;
        readonly fullScreen: boolean;
        readonly simpleFullScreen: boolean;
        readonly title: string;
        readonly alwaysOnTop: boolean;
        readonly opacity: number;
        readonly resizable: boolean;
        readonly movable: boolean;
        readonly minimizable: boolean;
        readonly maximizable: boolean;
        readonly closable: boolean;
        readonly fullScreenable: boolean;
        readonly menuBarVisible: boolean;
        readonly kiosk: boolean;
    }, never, MainContext>;
    awaitClosed: Effect.Effect<void, never, MainContext>;
    attach: (view: View.Attachable, options: View.AttachOptions) => Effect.Effect<View.Attachment, SewedError, MainContext | Scope.Scope>;
    mediaSourceId: Effect.Effect<string, SewedError, MainContext>;
    contentBounds: Effect.Effect<Electron.Rectangle, SewedError, MainContext>;
    sizeLimits: Effect.Effect<{
        readonly minimum: {
            readonly width: number;
            readonly height: number;
        };
        readonly maximum: {
            readonly width: number;
            readonly height: number;
        };
    }, SewedError, MainContext>;
    enabled: Effect.Effect<boolean, SewedError, MainContext>;
    backgroundColor: Effect.Effect<string, SewedError, MainContext>;
    visibleOnAllWorkspaces: Effect.Effect<boolean, SewedError, MainContext>;
    /** The Sewed id of the window's parent; `null` for none, or for one Sewed did not create. */
    parentId: Effect.Effect<string | null, SewedError, MainContext>;
    /** The Sewed ids of the window's child windows. */
    childIds: Effect.Effect<string[], SewedError, MainContext>;
    shadow: Effect.Effect<boolean, SewedError, MainContext>;
    accessibleTitle: Effect.Effect<string, SewedError, MainContext>;
    /** Whether the window is neither maximized, minimized nor fullscreen. */
    normal: Effect.Effect<boolean, SewedError, MainContext>;
    menuBarAutoHide: Effect.Effect<boolean, SewedError, MainContext>;
    /** The platform's own handle: an X11 `Window`, an `HWND`, or an `NSView*`, as bytes. */
    nativeHandle: Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
    touchBar: TouchBar.Handle;
}, never, MainContext | Scope.Scope>;
export type Handle = Effect.Success<ReturnType<typeof make>>;
export declare const toPublic: <T extends {
    readonly native: NativeBaseWindow;
    readonly closed: Deferred.Deferred<void>;
    readonly webContents: unknown;
}>(handle: T) => Omit<T, "native" | "closed" | "webContents">;
//# sourceMappingURL=Window.d.ts.map