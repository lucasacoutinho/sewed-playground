import { Layer } from "effect";
import type { SewedError } from "../SewedError.ts";
import * as Shell from "../Shell.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
export { Grants } from "../Shell.ts";
/**
 * The shell capability for tests, and the scoped grant beside it: the same policy `Shell.native`
 * carries, no Electron, and a recorder listing the calls. Both services come from the one
 * `ShellPolicy.operations` call below, so a grant admitted here is honoured by the very operations
 * a bound test client calls, exactly as it is in production. An invalid policy or a relative root
 * still fails as the Layer builds.
 */
export declare const memory: (options: Shell.Options) => Layer.Layer<typeof Shell.capability | Shell.Grants | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=ShellMemory.d.ts.map