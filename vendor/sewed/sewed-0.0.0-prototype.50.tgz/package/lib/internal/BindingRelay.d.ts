import { Effect } from "effect";
import { type Bound } from "../Binding.ts";
import { SewedError } from "../SewedError.ts";
import { type Connection } from "./Transport.ts";
/**
 * Serve a connection opened by a consuming runtime. The callback owns the
 * connection after it returns; rejected connections are closed immediately.
 */
export declare const serveConnections: (bindings: readonly Bound[]) => Effect.Effect<(key: string, connection: Connection) => SewedError | undefined, SewedError, import("effect/Scope").Scope>;
//# sourceMappingURL=BindingRelay.d.ts.map