import { Effect } from "effect";
import type { Scope } from "effect";
import type { Rpc } from "effect/rpc";
import * as Binding from "../Binding.ts";
import type { Capability } from "../Capability.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export * from "../Capability.ts";
export declare const serve: <Rpcs extends Rpc.Any, Key extends string>(capability: Capability<Rpcs, Key>) => Effect.Effect<Binding.Owner<Rpcs>, SewedError, Capability<Rpcs, Key> | MainContext | Scope.Scope>;
//# sourceMappingURL=CapabilityServe.d.ts.map