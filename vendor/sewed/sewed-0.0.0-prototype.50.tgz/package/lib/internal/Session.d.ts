import type { Session } from "electron";
import { Effect, Schema } from "effect";
import type { Stream } from "effect";
import type * as Decision from "../Decision.ts";
import * as Net from "../Net.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as SessionStorage from "../SessionStorage.ts";
import type * as WebRequestData from "../WebRequest.ts";
import * as Cookies from "./Cookies.ts";
/** A browser partition selected by a Sewed caller. */
export declare const Partition: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["memory", "persistent"]>;
    readonly name: Schema.String;
    /**
     * `raw` hands Electron `name` unchanged (`persist:`-prefixed for a persistent partition), for
     * an application that already has users under a native partition name. Omitted or `"hashed"`
     * keeps the default `sewed-v1-<sha256>` mapping. See [sessions](../../docs/sessions.md) for
     * what the default costs an application switching to `raw` after it has shipped.
     */
    readonly mapping: Schema.optionalKey<Schema.Literals<readonly ["hashed", "raw"]>>;
}>;
export type Partition = typeof Partition.Type;
export declare const decodePartition: (input: unknown, options?: import("effect/SchemaAST").ParseOptions) => {
    readonly kind: "memory" | "persistent";
    readonly name: string;
    readonly mapping?: "hashed" | "raw";
};
declare const sessionHandle: unique symbol;
/**
 * The literal string a partition selector resolves to, before Electron ever sees it. Pure and
 * Electron-free so a test can pin it directly, independent of `session.fromPartition` itself
 * (which only a real Electron process can answer). `raw` hands the given `name` through
 * unchanged, `persist:`-prefixed for a persistent one, matching Electron's own convention for a
 * caller with users already under a native partition name; the default `hashed` (or any mapping
 * other than `raw`) keeps `sewed-v1-<sha256>`, the documented compatibility mapping that lets an
 * application-chosen name collide with nothing another origin's own raw partition picked.
 */
export declare const partitionKey: (partition: Partition) => string;
/**
 * A selected browser session. The identity brand is what keeps a caller from fabricating one
 * structurally; every other member is a method or a value the session's own construction builds
 * once, matching how a window and a web contents already read.
 */
export interface Handle {
    readonly [sessionHandle]: true;
    /** Cookie access for this session; the handle is inert until an operation runs in main. */
    readonly cookies: Cookies.Handle;
    /** Clears the selected storages, for the whole session or scoped to one origin. */
    readonly clearStorage: (options: SessionStorage.ClearOptions) => Effect.Effect<void, SewedError, MainContext>;
    /** Closes every open connection in the session, for example after its proxy changes. */
    readonly closeAllConnections: Effect.Effect<void, SewedError, MainContext>;
    /** Resolves a host with the session's resolver; `cacheUsage: "disallowed"` skips cached answers. */
    readonly resolveHost: (host: string, options?: Net.ResolveHostOptions) => Effect.Effect<Net.ResolvedHost, SewedError, MainContext>;
    /** Reads one upload blob, for request deciders that take `body.blobs: "reference"`. */
    readonly blobData: (uuid: string) => Effect.Effect<Uint8Array, SewedError, MainContext>;
    /** Observes the request stages deciders never see, for the requests a filter selects. */
    readonly requests: (filter: WebRequestData.Filter) => Stream.Stream<WebRequestData.Event, SewedError, MainContext>;
    /**
     * Installs a decider for one of `Decidables.Session`'s decidables against this session's own
     * registry, for the caller's scope. Any number of deciders may be installed, and the decidable's
     * own composition decides among them. Sessions have application lifetime and no closed state of
     * their own, so nothing here ever refuses installation the way a window or web contents can once
     * closed.
     *
     * The three request stages are not among them: they name `owner: "requests"`, so this refuses
     * them at compile time and {@link Handle.intercept} is where they install.
     */
    readonly decide: Decision.Owner<"session">["decide"];
    /**
     * Installs a decider for one of the three request stages — `Decidables.Session.Request`,
     * `.RequestHeaders`, `.ResponseHeaders` — on the requests one filter selects, for the caller's
     * scope. Any number of deciders may be installed on any of them, independently: one feature
     * blocking trackers and another rewriting headers neither know nor need to know about each other,
     * and removing one leaves the other deciding.
     *
     * The filter's own contract — why it is required and separate from the decidable, what a `body`
     * option does, and how several deciders on one stage compose — is {@link Decision.Requests},
     * which `sewed/testing`'s owner stand-in publishes too, so a feature that intercepts names that
     * interface and takes either this handle or a stand-in.
     */
    readonly intercept: Decision.Requests["intercept"];
}
export declare const fromNative: (session: Session) => Handle;
export declare const resolve: (handle: Handle) => Session;
export {};
//# sourceMappingURL=Session.d.ts.map