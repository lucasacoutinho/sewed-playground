import { Effect } from "effect";
import type { Stream } from "effect";
import type * as Application from "../Application.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/**
 * What the process has open, as plain data. Electron's lookups hand out the native objects;
 * these name each one instead, by the Sewed id of the handle that owns it, so a program can find
 * its own windows and notice what it did not create without receiving a resource nobody owns.
 */
export declare const windows: Effect.Effect<ReadonlyArray<Application.WindowEntry>, SewedError, MainContext>;
export declare const focusedWindow: Effect.Effect<Application.WindowEntry | null, SewedError, MainContext>;
export declare const allWebContents: Effect.Effect<ReadonlyArray<Application.WebContentsEntry>, SewedError, MainContext>;
export declare const focusedWebContents: Effect.Effect<Application.WebContentsEntry | null, SewedError, MainContext>;
/** Every window the process creates, a Sewed one or not. */
export declare const windowsCreated: Stream.Stream<Application.WindowEntry, SewedError, MainContext>;
/** Every session Electron creates. */
export declare const sessionsCreated: Stream.Stream<Application.SessionCreated, SewedError, MainContext>;
/**
 * Emits once every window has closed and the process is about to quit, after the quit decision.
 * It is an observation: the application scope's finalizers are where shutdown work belongs.
 */
export declare const willQuit: Stream.Stream<void, SewedError, MainContext>;
//# sourceMappingURL=AppInventory.d.ts.map