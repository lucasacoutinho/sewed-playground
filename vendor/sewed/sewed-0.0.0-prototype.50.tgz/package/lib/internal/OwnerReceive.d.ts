import type { AnswerBound, Bound } from "./Bulk.ts";
import type { Encoding } from "./Encoding.ts";
import { type Client, type Incoming, type RequestId, type RequestMessage } from "./OwnerClient.ts";
import type * as PendingBytes from "./PendingBytes.ts";
import { type Wire } from "./Transport.ts";
/** What the receive path needs of the owner it belongs to. */
export interface Owner {
    readonly encoding: Encoding;
    readonly bounds: ReadonlyMap<string, Bound>;
    readonly answerBounds: ReadonlyMap<string, AnswerBound>;
    readonly pendingBytes: {
        readonly reserve: (bytes: number) => PendingBytes.Reservation | undefined;
    };
    /** Queues a message for RpcServer; false when the inbox is full. */
    readonly offer: (incoming: Incoming) => boolean;
    readonly disconnect: (clientId: number, reason: string) => void;
    readonly endRequest: (clientId: number, client: Client, requestId: RequestId, outcome: "success" | "failure" | "interrupted") => void;
    /** Called once a request is admitted, before it is queued. */
    readonly onStarted: (clientId: number, request: RequestMessage) => void;
}
/**
 * What an owner does with each message a connection delivers: admit a request against its limits
 * and byte budget, assemble a bulk request from its parts, answer an interruption for a request
 * that has not reached its handler, and refuse what no honest client sends.
 */
export declare const make: (owner: Owner) => {
    receive: (id: number, client: Client, wire: Wire) => void;
    refuseUndecodable: (id: number, client: Client, requestId: RequestId) => void;
};
//# sourceMappingURL=OwnerReceive.d.ts.map