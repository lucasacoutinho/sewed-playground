export declare const register: (contentsId: number, handleId: string) => (() => void);
export declare const handleIdOf: (contentsId: number | undefined) => string | undefined;
//# sourceMappingURL=ContentsRegistry.d.ts.map