import type * as Device from "../Device.ts";
import * as Registry from "./DecisionRegistry.ts";
type Listener = (event: {
    preventDefault(): void;
}, devices: ReadonlyArray<Device.Bluetooth>, callback: (deviceId: string) => void) => void;
/** The structural subset of a web contents the Bluetooth chooser listens to. */
export interface Contents {
    on(event: "select-bluetooth-device", listener: Listener): unknown;
    off(event: "select-bluetooth-device", listener: Listener): unknown;
    getURL(): string;
}
/**
 * Resolves `Decidables.WebContents.BluetoothDevice` for a page's `navigator.bluetooth.requestDevice`,
 * while the decidable has a decider. Electron reports the devices a scan has found so far and
 * reports again as the list changes, until one report's callback is answered. Each report starts a
 * fresh resolution with its own list and interrupts the one before it, so a decider only ever
 * answers for the list it was shown: a picker waiting on a person is interrupted and asked again
 * when a device appears. `wait` leaves the request scanning, which is what Electron's own contract
 * calls not answering yet.
 *
 * `preventDefault` is unconditional: without it Electron selects the first device found. `contents`
 * and `registry` are thunks because a guest view's registry is built before its web contents
 * exists, and both exist by the time a decider can be installed.
 */
export declare const hook: (contents: () => Contents, registry: () => Registry.Resolver<"contents">) => Registry.Hook;
export {};
//# sourceMappingURL=ContentsBluetooth.d.ts.map