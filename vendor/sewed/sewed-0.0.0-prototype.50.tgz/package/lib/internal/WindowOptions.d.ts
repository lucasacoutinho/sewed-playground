import { Schema } from "effect";
/** Window creation options that are plain data; a parent window is resolved separately. */
export declare const Options: Schema.Struct<{
    readonly title: Schema.optionalKey<Schema.String>;
    readonly width: Schema.optionalKey<Schema.Finite>;
    readonly height: Schema.optionalKey<Schema.Finite>;
    readonly x: Schema.optionalKey<Schema.Finite>;
    readonly y: Schema.optionalKey<Schema.Finite>;
    readonly minWidth: Schema.optionalKey<Schema.Finite>;
    readonly minHeight: Schema.optionalKey<Schema.Finite>;
    readonly maxWidth: Schema.optionalKey<Schema.Finite>;
    readonly maxHeight: Schema.optionalKey<Schema.Finite>;
    readonly show: Schema.optionalKey<Schema.Boolean>;
    readonly frame: Schema.optionalKey<Schema.Boolean>;
    readonly transparent: Schema.optionalKey<Schema.Boolean>;
    readonly backgroundColor: Schema.optionalKey<Schema.String>;
    readonly alwaysOnTop: Schema.optionalKey<Schema.Boolean>;
    readonly resizable: Schema.optionalKey<Schema.Boolean>;
    readonly movable: Schema.optionalKey<Schema.Boolean>;
    readonly minimizable: Schema.optionalKey<Schema.Boolean>;
    readonly maximizable: Schema.optionalKey<Schema.Boolean>;
    readonly closable: Schema.optionalKey<Schema.Boolean>;
    readonly fullScreenable: Schema.optionalKey<Schema.Boolean>;
    readonly skipTaskbar: Schema.optionalKey<Schema.Boolean>;
    readonly kiosk: Schema.optionalKey<Schema.Boolean>;
    readonly autoHideMenuBar: Schema.optionalKey<Schema.Boolean>;
    readonly opacity: Schema.optionalKey<Schema.Finite>;
    readonly icon: Schema.optionalKey<Schema.String>;
    readonly modal: Schema.optionalKey<Schema.Boolean>;
    /** macOS title bar treatment; other platforms apply only the styles Electron supports there. */
    readonly titleBarStyle: Schema.optionalKey<Schema.Literals<readonly ["default", "hidden", "hiddenInset", "customButtonsOnHover"]>>;
    /** Sizes the content area to `width` and `height` instead of the whole window. */
    readonly useContentSize: Schema.optionalKey<Schema.Boolean>;
    readonly center: Schema.optionalKey<Schema.Boolean>;
    readonly focusable: Schema.optionalKey<Schema.Boolean>;
    readonly hasShadow: Schema.optionalKey<Schema.Boolean>;
    /** Asks for the dark variant of the window frame, where the desktop has one. */
    readonly darkTheme: Schema.optionalKey<Schema.Boolean>;
    /** Whether a frameless window has rounded corners, on macOS and Windows. */
    readonly roundedCorners: Schema.optionalKey<Schema.Boolean>;
    /** Whether a frameless window keeps the standard Windows frame with its shadow and animations. */
    readonly thickFrame: Schema.optionalKey<Schema.Boolean>;
    /** Draws the native window controls over the content of a frameless window. */
    readonly titleBarOverlay: Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly color: Schema.optionalKey<Schema.String>;
        readonly symbolColor: Schema.optionalKey<Schema.String>;
        readonly height: Schema.optionalKey<Schema.Finite>;
    }>]>>;
    /** A macOS material behind the content; see `WindowControls.Vibrancy`. */
    readonly vibrancy: Schema.optionalKey<Schema.Literals<readonly ["titlebar", "selection", "menu", "popover", "sidebar", "header", "sheet", "window", "hud", "fullscreen-ui", "tooltip", "content", "under-window", "under-page"]>>;
    /** Whether a macOS vibrancy follows the window's activity, or stays active or inactive. */
    readonly visualEffectState: Schema.optionalKey<Schema.Literals<readonly ["followWindow", "active", "inactive"]>>;
    /** A Windows 11 material behind the content. */
    readonly backgroundMaterial: Schema.optionalKey<Schema.Literals<readonly ["auto", "none", "mica", "acrylic", "tabbed"]>>;
    /** Windows with one tabbing identifier group as native tabs, on macOS. */
    readonly tabbingIdentifier: Schema.optionalKey<Schema.String>;
    readonly hiddenInMissionControl: Schema.optionalKey<Schema.Boolean>;
    /** Whether a click that activates a macOS window also reaches its content. */
    readonly acceptFirstMouse: Schema.optionalKey<Schema.Boolean>;
    /** The window type the desktop treats it as: `desktop`, `dock`, `toolbar`, `splash`, and so on. */
    readonly type: Schema.optionalKey<Schema.String>;
    /**
     * A name unique among the application's windows, which is what persisted state is stored under.
     */
    readonly name: Schema.optionalKey<Schema.String>;
    /**
     * Restores the window's bounds and display mode from its last run and saves them as they
     * change; needs `name`. `true` persists both.
     */
    readonly windowStatePersistence: Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly bounds: Schema.optionalKey<Schema.Boolean>;
        readonly displayMode: Schema.optionalKey<Schema.Boolean>;
    }>]>>;
    /** Position of the macOS traffic light buttons in a hidden title bar. */
    readonly trafficLightPosition: Schema.optionalKey<Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
    }>>;
}>;
export type Options = typeof Options.Type;
//# sourceMappingURL=WindowOptions.d.ts.map