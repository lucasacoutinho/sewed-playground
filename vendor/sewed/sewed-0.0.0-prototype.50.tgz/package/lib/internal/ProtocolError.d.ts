import { Effect } from "effect";
import { SewedError } from "../SewedError.ts";
/**
 * Shared by `internal/Session.ts` and `internal/SessionSettings.ts`, which cannot import each other's
 * copy directly: `SessionSettings.ts` imports `resolve` from `Session.ts`, so `Session.ts` importing
 * back from `SessionSettings.ts` would be a cycle. Neither imports this module's own dependencies
 * (`effect`, `SewedError`), so both importing from here instead is cycle-free.
 */
export declare const protocolError: (message: string, cause?: unknown, reason?: string) => SewedError;
/** Wraps `run`, mapping anything it throws to a `Protocol` `SewedError` unless it already is one. */
export declare const decoded: <A>(message: string, run: () => A) => Effect.Effect<A, SewedError>;
//# sourceMappingURL=ProtocolError.d.ts.map