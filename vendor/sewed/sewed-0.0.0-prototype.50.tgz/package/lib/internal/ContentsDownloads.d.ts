import type * as Download from "../Download.ts";
import type { Decision, Offer } from "../Download.ts";
import { type AdoptableItem } from "./DownloadItem.ts";
import * as DecisionRegistry from "./DecisionRegistry.ts";
interface Item extends AdoptableItem {
    getURL(): string;
    getFilename(): string;
    getMimeType(): string;
    getURLChain(): string[];
    hasUserGesture(): boolean;
    getContentDisposition(): string;
    setSavePath(path: string): void;
    setSaveDialogOptions(options: Electron.SaveDialogOptions): void;
}
type Listener = (event: {
    preventDefault(): void;
}, item: Item, contents: {
    readonly id: number;
} | null | undefined) => void;
/** The structural subset of a native session the download dispatch listens on. */
export interface SessionLike {
    on(event: "will-download", listener: Listener): unknown;
    off(event: "will-download", listener: Listener): unknown;
}
/**
 * One web contents' download posture. `decide` is normally filled from the owner's own
 * `Decidables.WebContents.Download` registry resolution (`internal/WebContents.ts`,
 * `internal/GuestView.ts`) rather than a caller's function, so it already denies, prompts, or saves
 * on its own terms — including the "fails or suspends" case, which the registry's own resolution
 * treats as a broken decider and answers the fallback for. `undefined` still denies outright, for an
 * entry constructed with no registry behind it at all.
 */
export interface Governor {
    readonly sourceId: string;
    readonly onBlocked: (url: string) => void;
    decide: ((offer: Offer) => Decision) | undefined;
}
/** Receives each download a contents' governor accepted. */
export type Observer = (handle: Download.Handle) => void;
/** Governs a web contents' downloads until the returned function is called. */
export declare const install: (session: SessionLike, contentsId: number, governor: Governor) => (() => void);
/** Receives the downloads a web contents' governor accepts. Without a governor nothing arrives. */
export declare const observe: (session: SessionLike, contentsId: number, onAccepted: Observer) => (() => void);
/**
 * Keeps the native download dispatch installed while this decidable has at least one decider. The
 * governor is built at the moment the first decider attaches, after the owner registry exists.
 */
export declare const hook: (session: SessionLike, contentsId: number, governor: () => Governor) => DecisionRegistry.Hook;
export {};
//# sourceMappingURL=ContentsDownloads.d.ts.map