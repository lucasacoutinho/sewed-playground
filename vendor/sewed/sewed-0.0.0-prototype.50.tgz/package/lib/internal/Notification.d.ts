import { Effect, Layer, Stream } from "effect";
import type { Scope } from "effect";
import * as Notification from "../Notification.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Action, Activation, Delivered, Event, Options, Timeout, Urgency, capability, protocol, } from "../Notification.ts";
export declare const supported: Effect.Effect<boolean, SewedError, MainContext>;
export interface Handle {
    /** Finishes when the notification closes or fails; late observers fail with `Closed`. */
    readonly events: Stream.Stream<Notification.Event, SewedError, MainContext>;
    readonly close: Effect.Effect<void, SewedError, MainContext>;
}
/** Shows a notification for the acquiring scope; closing the scope closes it. */
export declare const show: (options: Notification.Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
/**
 * The notification capability for main. The rules live in this Layer, not in a separate host, so
 * `Capability.serve(Notification.capability)` gives a document exactly the checks a main-side call
 * obeys.
 */
export declare const native: () => Layer.Layer<typeof Notification.capability, SewedError, MainContext>;
/**
 * The application's notifications still in the macOS Notification Center. An unsigned build is
 * delivered none, so this answers an empty list there.
 */
export declare const delivered: Effect.Effect<ReadonlyArray<Notification.Delivered>, SewedError, MainContext>;
/** Removes delivered notifications from the macOS Notification Center by id. */
export declare const remove: (ids: ReadonlyArray<string>) => Effect.Effect<void, SewedError, MainContext>;
/** Removes one group's delivered notifications from the macOS Notification Center. */
export declare const removeGroup: (groupId: string) => Effect.Effect<void, SewedError, MainContext>;
/** Removes every delivered notification of the application from the macOS Notification Center. */
export declare const removeAll: Effect.Effect<void, SewedError, MainContext>;
/**
 * Windows toasts the user acted on, wherever the notification object is: after a restart, after
 * it was collected, and for the toast that launched the application. Electron keeps one handler,
 * so one observer at a time receives them.
 */
export declare const activations: Stream.Stream<Notification.Activation, SewedError, MainContext>;
//# sourceMappingURL=Notification.d.ts.map