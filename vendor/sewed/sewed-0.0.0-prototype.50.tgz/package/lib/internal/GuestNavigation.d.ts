import * as Navigation from "../Navigation.ts";
/** Validates and compiles a guest's navigation rules; `Protocol` on invalid input. */
export declare const compile: (rules: Navigation.Rules) => readonly ((url: URL) => boolean)[];
/**
 * The guest's rule set, fixed at creation: `navigate` and history moves consult it. `check` serves
 * main's own `navigate`; a target outside the policy is main's mistake and fails with `Protocol`
 * without reaching the `blocked` stream, which reports only what the page started.
 */
export interface Policy {
    readonly allows: (url: URL) => boolean;
    readonly check: (raw: string) => URL;
}
export declare const make: (initial: Navigation.Rules) => Policy;
//# sourceMappingURL=GuestNavigation.d.ts.map