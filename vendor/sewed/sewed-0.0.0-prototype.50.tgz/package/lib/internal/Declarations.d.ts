import * as Application from "../Application.ts";
import * as Declaration from "../Declaration.ts";
import { SewedError } from "../SewedError.ts";
/**
 * Applies `App.run`'s declarations in order: a thunk is called for its declaration where it
 * stands, then the declaration's step runs. A non-empty list is refused outright once
 * `options.isReady()` answers true — Electron's pre-ready calls apply silently or throw once
 * readiness has passed, so a declaration made too late would otherwise look like it worked. The
 * first failure after that stops the walk and is returned as `Startup`, naming the declaration —
 * or the position, for a thunk that threw before it had one. `App.run` exits on any failure, so
 * nothing after one is applied.
 */
export declare const apply: (entries: readonly Declaration.Entry[], options: {
    readonly isReady: () => boolean;
}) => SewedError | undefined;
export interface CommandLineNative {
    appendSwitch(name: string, value?: string): void;
    appendArgument(value: string): void;
    removeSwitch(name: string): void;
}
export declare const commandLine: (native: CommandLineNative, flag: Application.CommandLineSwitch) => Declaration.Declaration;
/** Appends one bare argument to Chromium's command line, after its switches. */
export declare const commandLineArgument: (native: CommandLineNative, value: string) => Declaration.Declaration;
/** Removes a switch from Chromium's command line, whoever put it there. */
export declare const commandLineRemoval: (native: CommandLineNative, name: string) => Declaration.Declaration;
export interface PathsNative {
    setPath(name: Application.PathName, path: string): void;
    ensureDirectory(path: string): void;
}
/** A partial table of application paths; `Schema.Record` over a literal union would require every key. */
export type PathTable = {
    readonly [Name in Application.PathName]?: string;
};
/**
 * A declared directory exists when the program starts: every entry is decoded first, then every
 * declared directory is created (recursively, in declaration order) before any path is set, so a
 * create failure leaves every path unset. `exe` and `module` are files and are never created.
 */
export declare const paths: (native: PathsNative, table: PathTable) => Declaration.Declaration;
export interface GpuNative {
    disableHardwareAcceleration(): void;
    disableDomainBlockingFor3DAPIs(): void;
}
export declare const gpu: (native: GpuNative, options: Application.Gpu) => Declaration.Declaration;
export interface IdentityNative {
    setAppUserModelId(id: string): void;
    setName(name: string): void;
    setDesktopName(name: string): void;
    enableSandbox(): void;
}
export declare const identity: (native: IdentityNative, options: Application.Identity) => Declaration.Declaration;
//# sourceMappingURL=Declarations.d.ts.map