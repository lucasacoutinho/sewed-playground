import type { MessagePortMain } from "electron";
import { SewedError } from "../SewedError.ts";
import type { Connection } from "./Transport.ts";
/** The MessagePortMain surface shared by main and an Electron utility child. */
export type ElectronPortLike = Pick<MessagePortMain, "on" | "off" | "once" | "postMessage" | "close" | "start">;
export declare const isElectronPort: (value: unknown) => value is ElectronPortLike;
export declare const electronPort: (port: ElectronPortLike) => Connection;
export declare const connectElectronPort: (createChannel: () => {
    readonly port1: MessagePortMain;
    readonly port2: MessagePortMain;
}, transfer: (port: MessagePortMain) => void) => import("effect/Effect").Effect<Connection, SewedError, import("effect/Scope").Scope>;
//# sourceMappingURL=ElectronPort.d.ts.map