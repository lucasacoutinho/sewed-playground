import { Effect, Schema } from "effect";
import type { Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as SystemPreferences from "../SystemPreferences.ts";
export { Animation, Appearance, Change, ColorName, MediaAccess, CenterNotification, Defaults, MediaKind, NotificationCenter, SystemColor, } from "../SystemPreferences.ts";
export declare const animation: Effect.Effect<SystemPreferences.Animation, SewedError, MainContext>;
export declare const accentColor: Effect.Effect<string, SewedError, MainContext>;
export declare const appearance: Effect.Effect<SystemPreferences.Appearance, SewedError, MainContext>;
export declare const mediaAccess: (kind: SystemPreferences.MediaKind) => Effect.Effect<SystemPreferences.MediaAccess, SewedError, MainContext>;
export declare const askForMediaAccess: (kind: Exclude<SystemPreferences.MediaKind, "screen">) => Effect.Effect<boolean, SewedError, MainContext>;
export declare const color: (name: string) => Effect.Effect<string, SewedError, MainContext>;
export declare const systemColor: (name: SystemPreferences.SystemColor) => Effect.Effect<string, SewedError, MainContext>;
/** Accent and theme color changes; each observer owns its listeners and a queue of 128 changes. */
export declare const changes: Stream.Stream<SystemPreferences.Change, SewedError, MainContext>;
/** Whether this Mac can ask for Touch ID. */
export declare const canPromptTouchId: Effect.Effect<boolean, SewedError, MainContext>;
/**
 * Asks the user to authenticate with Touch ID, showing `reason`. Succeeds when they do and fails
 * `Native` when they cancel or cannot.
 */
export declare const promptTouchId: (reason: string) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Whether the application is trusted to use the macOS accessibility API; with `prompt`, macOS
 * asks the user to grant it when it is not.
 */
export declare const trustedAccessibilityClient: (prompt?: boolean) => Effect.Effect<boolean, SewedError, MainContext>;
/** Whether the user enabled swiping between pages with a scroll gesture, on macOS. */
export declare const swipeTrackingFromScrollEvents: Effect.Effect<boolean, SewedError, MainContext>;
/** Registers fallback values in the macOS user defaults, used until a key is set. */
export declare const registerDefaults: (defaults: SystemPreferences.Defaults) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Reads a key of the macOS user defaults as the given type. What comes back is checked against
 * that type, so a key stored as something else fails `Protocol` and is never a mistyped value.
 */
export declare const userDefault: (key: string, type: SystemPreferences.UserDefaultType) => Effect.Effect<SystemPreferences.UserDefault, SewedError, MainContext>;
/** Sets a key of the macOS user defaults to a value of a stated type. */
export declare const setUserDefault: (key: string, entry: SystemPreferences.UserDefault) => Effect.Effect<void, SewedError, MainContext>;
/** Removes a key from the macOS user defaults, restoring its registered or global value. */
export declare const removeUserDefault: (key: string) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Messages posted to a macOS notification center under one name, or under every name with
 * `null`. Each observer holds its own subscription.
 */
export declare const notifications: (center: SystemPreferences.NotificationCenter, event: string | null) => Stream.Stream<SystemPreferences.CenterNotification, SewedError, MainContext>;
/**
 * Posts a message to a macOS notification center. `deliverImmediately` applies to the distributed
 * center, which otherwise waits for the receiving application to be active.
 */
export declare const postNotification: (center: SystemPreferences.NotificationCenter, event: string, userInfo?: Record<string, Schema.Json>, deliverImmediately?: boolean) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=SystemPreferences.d.ts.map