import { Effect } from "effect";
import * as Clipboard from "../Clipboard.ts";
import type { SewedError } from "../SewedError.ts";
/**
 * The platform calls a clipboard capability makes once its policy has allowed them. `native`
 * supplies Electron's `clipboard`; a test supplies its own. `R` is whatever that implementation
 * requires, so the policy above it stays free of any runtime requirement of its own.
 */
export interface Core<R> {
    readonly read: (format: Clipboard.Format) => Effect.Effect<Clipboard.Content | null, SewedError, R>;
    readonly write: (content: Clipboard.Content) => Effect.Effect<void, SewedError, R>;
    readonly formats: Effect.Effect<readonly Clipboard.Format[], SewedError, R>;
    readonly clear: Effect.Effect<void, SewedError, R>;
}
/**
 * The clipboard operations a capability serves, each one already behind the policy. The policy
 * denies formats and filters what `formats` reports without changing any signature, so this is the
 * core's shape exactly. One declaration, so the two cannot drift.
 */
export type Operations<R> = Core<R>;
/**
 * Decodes the policy once and returns operations that check every format before the core runs.
 * This is the only place the clipboard's rules live, so the native Layer, a served renderer call,
 * and the memory Layer cannot drift apart. `formats` reports only readable formats, and `clear`
 * needs some writable format. An invalid policy fails here, while the Layer is building, rather
 * than on the first call.
 */
export declare const operations: <R>(policy: Clipboard.Policy, core: Core<R>) => Effect.Effect<Operations<R>, SewedError>;
//# sourceMappingURL=ClipboardPolicy.d.ts.map