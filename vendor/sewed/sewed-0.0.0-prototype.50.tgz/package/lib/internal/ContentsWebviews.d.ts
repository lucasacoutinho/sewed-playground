import type { WebContents } from "electron";
import { Effect } from "effect";
import type { Stream } from "effect";
import type { Context } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import type { Blocked } from "../WebContents.ts";
import { type Core, type Owner } from "./WebContentsCore.ts";
/**
 * A `<webview>` a page attached, as a resource the program owns. It has what a guest view's web
 * contents has and the same posture: its navigations and redirects are denied unless a decider on
 * its `webContents` allows them, whether its own page or the host page starts them; popups and
 * downloads are denied, and it carries no bridge.
 *
 * A load the host page directs (`src`, `loadURL`, history) has no cancellable event: a denied one
 * is stopped before its document commits and reported, but its request may already have been
 * sent. A page's own navigation is denied before any request.
 *
 * Its lifetime is the DOM element's, which no scope controls: when the page removes the element
 * or navigates away the webview is destroyed, every operation here fails `Closed`, and
 * `awaitClosed` resolves.
 */
export interface Handle {
    readonly id: string;
    /** The Sewed id of the web contents whose page attached this webview. */
    readonly hostId: string | null;
    readonly webContents: Core;
    /** The navigations, redirects, popups and downloads this webview was denied. */
    readonly blocked: Stream.Stream<Blocked, SewedError, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
/**
 * Owns every webview `host` attaches, for as long as each lives. `Decidables.WebContents
 * .WebviewAttach` has already allowed the attachment and locked its preferences down by the time
 * `did-attach-webview` fires; this is where the guest it created stops being a native object
 * nobody holds. `services` is the context native callbacks run their Effects with; `native` is
 * what each webview's own core needs from Electron's main-process modules.
 */
export declare const install: (host: WebContents, services: Context.Context<MainContext>, native: Pick<Owner, "imageOf" | "displayScaleFactor">) => {
    /** The webviews this page attaches from now on, each as an owned handle. */
    webviews: Stream.Stream<Handle, SewedError, MainContext>;
    release: () => void;
};
//# sourceMappingURL=ContentsWebviews.d.ts.map