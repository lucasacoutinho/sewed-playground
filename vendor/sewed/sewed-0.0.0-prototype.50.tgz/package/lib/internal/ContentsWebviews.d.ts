import type { WebContents } from "electron";
import { Effect } from "effect";
import type { Stream } from "effect";
import type { Context } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import type { Blocked } from "../WebContents.ts";
import type { Handle as PopupHandle, Installed as Popups } from "./ContentsPopups.ts";
import { type Core, type Owner } from "./WebContentsCore.ts";
/**
 * A `<webview>` a page attached, as a resource the program owns. It has what a guest view's web
 * contents has and the same posture: its navigations and redirects are denied unless a decider on
 * its `webContents` allows them, whether its own page or the host page starts them; popups and
 * downloads are denied, and it carries no bridge.
 *
 * A load the host page directs (`src`, `loadURL`, history) has no cancellable event of its own:
 * a denied one is reported and its request is cancelled before it is sent, so the webview keeps
 * the document it had.
 */
export interface Handle {
    readonly id: string;
    /** The Sewed id of the web contents whose page attached this webview. */
    readonly hostId: string | null;
    readonly webContents: Core;
    /** The navigations, redirects, popups and downloads this webview was denied. */
    readonly blocked: Stream.Stream<Blocked, SewedError, MainContext>;
    /** The windows this webview's page opens, when a decider on its `webContents` allows them. */
    readonly popups: Stream.Stream<PopupHandle, SewedError, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
/**
 * Owns every webview `host` attaches, for as long as each lives. `Decidables.WebContents
 * .WebviewAttach` has already allowed the attachment and locked its preferences down by the time
 * `did-attach-webview` fires; this is where the guest it created stops being a native object
 * nobody holds. `services` is the context native callbacks run their Effects with; `native` is
 * what each webview's own core needs from Electron's main-process modules.
 */
export declare const install: (host: WebContents, services: Context.Context<MainContext>, native: Pick<Owner, "imageOf" | "displayScaleFactor"> & {
    /** Installs popup ownership for one webview; see `ContentsPopups.install`. */
    readonly popupsOf: (guest: WebContents) => Popups;
}) => {
    /** The webviews this page attaches from now on, each as an owned handle. */
    webviews: Stream.Stream<Handle, SewedError, MainContext>;
    release: () => void;
};
//# sourceMappingURL=ContentsWebviews.d.ts.map