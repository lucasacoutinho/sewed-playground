import { Layer } from "effect";
import * as Clipboard from "../Clipboard.ts";
import type { SewedError } from "../SewedError.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
/**
 * The clipboard capability for tests: the same policy `Clipboard.native` carries, no Electron, and
 * a recorder listing the calls. An invalid policy still fails as the Layer builds.
 */
export declare const memory: (policy: Clipboard.Policy) => Layer.Layer<typeof Clipboard.capability | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=ClipboardMemory.d.ts.map