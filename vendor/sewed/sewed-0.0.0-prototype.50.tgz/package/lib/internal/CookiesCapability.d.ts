import { Layer } from "effect";
import * as Cookie from "../Cookie.ts";
import type { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import type { Handle } from "./Session.ts";
export { Cause, Change, Cookie, Details, Filter, Policy, SameSite, capability, protocol, } from "../Cookie.ts";
/**
 * The cookie capability for main. Unlike the ambient surfaces, this one is scoped to a session, so
 * the Layer threads an acquired handle rather than a plain options bag: it resolves the handle in
 * main, then compiles the policy once over that session's store. The policy lives in this Layer,
 * not in a separate host, so `Capability.serve(Cookie.capability)` gives a document exactly the
 * rules a main-side call obeys.
 */
export declare const native: (session: Handle, policy: Cookie.Policy) => Layer.Layer<typeof Cookie.capability, SewedError, MainContext>;
//# sourceMappingURL=CookiesCapability.d.ts.map