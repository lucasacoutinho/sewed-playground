import { Layer } from "effect";
import * as NativeTheme from "../NativeTheme.ts";
import type { SewedError } from "../SewedError.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
/**
 * The theme capability for tests: the same options `NativeTheme.native` carries, no Electron, and
 * a recorder listing the calls. Invalid options still fail as the Layer builds.
 */
export declare const memory: (options?: NativeTheme.Options) => Layer.Layer<typeof NativeTheme.capability | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=NativeThemeMemory.d.ts.map