import type { Event, Placement } from "../Diagnostics.ts";
import { type Wire } from "./Transport.ts";
export interface Identity {
    readonly ownerId: string;
    readonly clientId: number;
    readonly requestId: string;
    readonly placement: Placement;
}
export interface Tracker {
    readonly start: (identity: Identity) => void;
    readonly frame: (identity: Identity, message: Wire) => void;
    readonly finish: (identity: Identity) => void;
}
export declare const make: (emit: (event: Event) => void) => Tracker;
//# sourceMappingURL=StreamDiagnostics.d.ts.map