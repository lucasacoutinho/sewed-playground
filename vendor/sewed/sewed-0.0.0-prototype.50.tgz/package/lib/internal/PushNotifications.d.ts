import { Effect, Schema } from "effect";
import type { Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/** Registers with APNS and returns the device token; macOS only, `Native` elsewhere. */
export declare const register: Effect.Effect<string, SewedError, MainContext>;
export declare const unregister: Effect.Effect<void, SewedError, MainContext>;
/** Received APNS payloads as JSON; each observer owns its listener and a queue of 128 payloads. */
export declare const notifications: Stream.Stream<Schema.Json, SewedError, MainContext>;
//# sourceMappingURL=PushNotifications.d.ts.map