import { Effect } from "effect";
import type { Rpc } from "effect/rpc";
import * as Binding from "../Binding.ts";
import type { Operations } from "../Capability.ts";
import { ClientContext } from "../RuntimeContext.ts";
export declare const operations: <Rpcs extends Rpc.Any>(slot: Binding.Slot<Rpcs>, options: {
    readonly connection?: Binding.Connection;
}) => Effect.Effect<Operations<Rpcs>, never, ClientContext>;
//# sourceMappingURL=CapabilityClient.d.ts.map