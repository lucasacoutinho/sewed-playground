import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Accelerator } from "../GlobalShortcut.ts";
export interface Handle {
    readonly accelerator: string;
    readonly presses: Stream.Stream<void, SewedError, MainContext>;
}
export declare const register: (accelerator: string) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
/** Whether every registered shortcut is currently suspended. */
export declare const suspended: Effect.Effect<boolean, SewedError, MainContext>;
/**
 * Suspends or resumes every registered shortcut without unregistering any, for example while the
 * user records a new key combination.
 */
export declare const setSuspended: (flag: boolean) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=GlobalShortcut.d.ts.map