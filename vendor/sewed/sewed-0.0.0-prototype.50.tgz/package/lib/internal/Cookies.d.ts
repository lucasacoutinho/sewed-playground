import type { Session } from "electron";
import { Effect } from "effect";
import type { Stream } from "effect";
import * as Cookie from "../Cookie.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export interface Handle {
    readonly get: (filter?: Cookie.Filter) => Effect.Effect<readonly Cookie.Cookie[], SewedError, MainContext>;
    readonly set: (details: Cookie.Details) => Effect.Effect<void, SewedError, MainContext>;
    readonly remove: (url: string, name: string) => Effect.Effect<void, SewedError, MainContext>;
    readonly flush: Effect.Effect<void, SewedError, MainContext>;
    /** Every observer owns its listener and a queue of 128 changes; overflow fails it with `Limit`. */
    readonly changes: Stream.Stream<Cookie.Change, SewedError, MainContext>;
}
export declare const make: (native: Session) => Handle;
//# sourceMappingURL=Cookies.d.ts.map