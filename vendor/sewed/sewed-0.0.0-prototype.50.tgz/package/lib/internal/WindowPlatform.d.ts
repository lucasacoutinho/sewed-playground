import type { BaseWindow as NativeBaseWindow } from "electron";
import { Deferred, Effect, Stream } from "effect";
import type { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as WindowControls from "../WindowControls.ts";
import type * as Registry from "./DecisionRegistry.ts";
import { Point } from "./Geometry.ts";
export interface Helpers {
    readonly id: string;
    readonly closed: Deferred.Deferred<void>;
    readonly registry: Registry.Resolver<"window">;
    readonly operation: <A>(run: () => A) => Effect.Effect<A, SewedError, MainContext>;
    readonly read: <A>(message: string, run: () => A) => Effect.Effect<A, SewedError, MainContext>;
    /** Decodes first, so invalid input fails `Protocol`, then applies and republishes state. */
    readonly setting: <A>(decode: () => A, apply: (value: A) => void) => Effect.Effect<void, SewedError, MainContext>;
    /** The native window behind another Sewed window handle. */
    readonly nativeOf: (handle: {
        readonly id: string;
    }) => NativeBaseWindow;
}
/**
 * The window members Electron implements on macOS or Windows only. Each fails `Native` elsewhere
 * instead of pretending to succeed, so a caller learns the platform does not have it.
 */
export declare const make: (native: NativeBaseWindow, helpers: Helpers) => {
    /** Removes the listeners this module holds for the window's whole life. */
    release: () => void;
    members: {
        /** Whether the window can take focus, on macOS and Windows. */
        setFocusable: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
        focusable: Effect.Effect<boolean, SewedError, MainContext>;
        contentProtected: Effect.Effect<boolean, SewedError, MainContext>;
        /** The file a macOS window represents, shown as an icon in its title bar. */
        setRepresentedFilename: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        representedFilename: Effect.Effect<string, SewedError, MainContext>;
        /** Marks a macOS window's document as having unsaved changes. */
        setDocumentEdited: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
        documentEdited: Effect.Effect<boolean, SewedError, MainContext>;
        setVibrancy: (vibrancy: WindowControls.Vibrancy) => Effect.Effect<void, SewedError, MainContext>;
        /** Places the macOS traffic light buttons; `null` restores their default position. */
        setWindowButtonPosition: (position: Point | null) => Effect.Effect<void, SewedError, MainContext>;
        windowButtonPosition: Effect.Effect<{
            x: number;
            y: number;
        } | null, SewedError, MainContext>;
        /** Where sheets attach on a macOS window, as offsets from its top left. */
        setSheetOffset: (offset: {
            readonly y: number;
            readonly x?: number;
        }) => Effect.Effect<void, SewedError, MainContext>;
        /** Shows a macOS Quick Look preview of a file, by absolute path. */
        previewFile: (path: string, displayName?: string) => Effect.Effect<void, SewedError, MainContext>;
        closeFilePreview: Effect.Effect<void, SewedError, MainContext>;
        setHiddenInMissionControl: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
        hiddenInMissionControl: Effect.Effect<boolean, SewedError, MainContext>;
        /** Whether the cursor hides while the user types in a macOS window. */
        setAutoHideCursor: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
        /** Recomputes a macOS window's shadow, after its shape or transparency changed. */
        invalidateShadow: Effect.Effect<void, SewedError, MainContext>;
        setExcludedFromShownWindowsMenu: (value: boolean) => Effect.Effect<void, SewedError, MainContext>;
        excludedFromShownWindowsMenu: Effect.Effect<boolean, SewedError, MainContext>;
        /** Native window tabs, on macOS. */
        tabs: {
            identifier: Effect.Effect<string | null, SewedError, MainContext>;
            selectNext: Effect.Effect<void, SewedError, MainContext>;
            selectPrevious: Effect.Effect<void, SewedError, MainContext>;
            showAll: Effect.Effect<void, SewedError, MainContext>;
            mergeAll: Effect.Effect<void, SewedError, MainContext>;
            moveToNewWindow: Effect.Effect<void, SewedError, MainContext>;
            toggleBar: Effect.Effect<void, SewedError, MainContext>;
            /** Adds another Sewed window as a tab of this one. */
            add: (window: {
                readonly id: string;
            }) => Effect.Effect<void, SewedError, MainContext>;
        };
        setAccentColor: (color: WindowControls.AccentColor) => Effect.Effect<void, SewedError, MainContext>;
        setAppDetails: (details: WindowControls.AppDetails) => Effect.Effect<void, SewedError, MainContext>;
        setBackgroundMaterial: (material: WindowControls.BackgroundMaterial) => Effect.Effect<void, SewedError, MainContext>;
        /**
         * Sets the buttons of the Windows taskbar thumbnail toolbar, at most seven; an empty list
         * removes them. A press arrives on `thumbarClicks` as the button's `id`.
         */
        setThumbarButtons: (buttons: ReadonlyArray<WindowControls.ThumbarButton>) => Effect.Effect<void, SewedError, MainContext>;
        thumbarClicks: Stream.Stream<string, SewedError, MainContext>;
        /** The part of the window shown as its Windows taskbar thumbnail. */
        setThumbnailClip: (region: WindowControls.Bounds) => Effect.Effect<void, SewedError, MainContext>;
        setThumbnailToolTip: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        snapped: Effect.Effect<boolean, SewedError, MainContext>;
        tabletMode: Effect.Effect<boolean, SewedError, MainContext>;
        /**
         * A raw Windows message as it reaches the window, by message code. Observers of one code
         * share Electron's single hook for it, removed with the last of them.
         */
        windowMessages: (message: number) => Stream.Stream<WindowControls.WindowMessage, SewedError, MainContext>;
    };
};
//# sourceMappingURL=WindowPlatform.d.ts.map