import type { Session } from "electron";
import { Effect } from "effect";
import type { Scope } from "effect";
import type { Stream } from "effect";
import type * as Decision from "../Decision.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as WebRequest from "../WebRequest.ts";
import type * as Registry from "./DecisionRegistry.ts";
type UploadData = Pick<Electron.UploadData, "bytes" | "file" | "blobUUID">;
/** A part is kept only when it fits the remaining budget; the first that does not ends the body. */
export declare const assembleBody: (parts: readonly UploadData[], filter: WebRequest.BodyFilter, blob: (id: string) => Promise<Uint8Array>) => Promise<WebRequest.Body>;
/**
 * Observes the request stages deciders never see: headers sent, response started, redirects,
 * completion, and errors. One native listener per stage covers the union of the installed
 * filters; each observer owns its registration and a bounded queue.
 */
export declare const observe: (native: Session, filter: WebRequest.Filter) => Stream.Stream<WebRequest.Event, SewedError, MainContext>;
/**
 * Installs one decider on one request stage, for the requests one filter selects, for the caller's
 * scope. This is the whole of `session.intercept`; see `internal/Session.ts` for the handle method
 * that binds the session and its `"requests"` registry into it.
 *
 * The filter is a parameter rather than a registry concept because it is a cost, not a key: a
 * listener over every URL routes every request in the session through main, and making the caller
 * name the scope at the call site is what keeps that visible — as the `Rules<R>` bundle this
 * replaces did. Which decidables are stages, what a filter selects, and the wrapper that makes a
 * decider answer {@link Decision.Pass} for a request its own filter does not select all live in
 * `internal/RequestStages.ts`, which has no Electron in it, so `sewed/testing`'s owner stand-in
 * applies a feature's filter with this same code. The union filter above is only Electron's half of
 * the same question.
 *
 * Body assembly is the half that cannot move: it reads Electron's `uploadData` off this listener's
 * own details. It is per install and lives in the wrapper's `answer` step, so only a decider whose
 * filter asked for a body pays for one, the blob cache the listener put beside the event means a
 * blob is read once per request however many installs ask, and a body that cannot be read fails
 * *that* decider — which, on a stage declaring `failure: { kind: "block" }`, blocks the request
 * exactly as the hand-rolled listener this replaces did.
 *
 * The request stage's event also carries `readBody`, assembled lazily so an install over
 * `<all_urls>` pays for a body only on the request whose decider actually calls it. `reinstall`
 * attaches one under the fixed default to every request; an install that named its own `body`
 * option replaces it here with one bound to that option instead, so `readBody()` called with no
 * arguments answers what *this* install asked for.
 */
export declare const intercept: <Event, Answer, R>(native: Session, registry: Registry.Registry<"requests">, decidable: Decision.Decidable<Event, Answer, "async", Decision.Composition, "requests">, filter: WebRequest.Filter, decider: Decision.Decider<NoInfer<Event>, NoInfer<Answer>, R>) => Effect.Effect<void, SewedError, MainContext | Scope.Scope | R>;
export {};
//# sourceMappingURL=WebRequest.d.ts.map