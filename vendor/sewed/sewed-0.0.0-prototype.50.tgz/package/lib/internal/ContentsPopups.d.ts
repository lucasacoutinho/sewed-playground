import { type WebContents } from "electron";
import { Effect } from "effect";
import type { Context, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import type { Blocked } from "../WebContents.ts";
import { type Core } from "./WebContentsCore.ts";
/**
 * The window a page opened with `window.open`, once `Decidables.WebContents.Popup` allowed it, as
 * a resource the program owns. The library builds the window itself, so there is never a moment
 * it exists unowned: it is sandboxed and isolated with no preload and no bridge, whatever its
 * opener had, and it has a guest's posture. Its navigations and redirects are denied unless a
 * decider on its `webContents` allows them, and downloads and further popups are denied.
 *
 * It closes when the person closes it, when its page calls `window.close()`, when `close` runs, or
 * when the web contents that opened it close: a popup does not outlive what vouched for it.
 */
export interface Handle {
    readonly id: string;
    /** The Sewed id of the owner of the web contents whose page opened this window. */
    readonly openerId: string | null;
    readonly webContents: Core;
    /** The navigations, redirects, popups and downloads this window was denied. */
    readonly blocked: Stream.Stream<Blocked, SewedError, MainContext>;
    /** The windows this one's page opens in turn, when a decider on it allows them. */
    readonly popups: Stream.Stream<Handle, SewedError, MainContext>;
    readonly close: Effect.Effect<void, never, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
/** What an owner hands its core so an allowed popup is built owned, and what it publishes. */
export interface Installed {
    /** Electron's `createWindow`: builds the popup's window and answers its web contents. */
    readonly create: (options: Electron.BrowserWindowConstructorOptions, url: string) => WebContents;
    readonly popups: Stream.Stream<Handle, SewedError, MainContext>;
    /** Closes every popup still open and ends the stream. */
    readonly release: () => void;
}
/**
 * Owns every popup `opener` is allowed to open. `services` is the context native callbacks run
 * their Effects with.
 */
export declare const install: (opener: WebContents, services: Context.Context<MainContext>) => Installed;
//# sourceMappingURL=ContentsPopups.d.ts.map