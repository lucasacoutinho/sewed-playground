import type { BaseWindow, Session as NativeSession, View as NativeView } from "electron";
import { Effect } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle as SessionHandle } from "./Session.ts";
import * as View from "./View.ts";
/** Runs `use` with the native window behind a Sewed window handle. */
export declare const window: <A>(handle: {
    readonly id: string;
}, use: (native: BaseWindow) => A | Promise<A>) => Effect.Effect<A, SewedError, MainContext>;
/** Runs `use` with the native session behind a Sewed session handle. */
export declare const session: <A>(handle: SessionHandle, use: (native: NativeSession) => A | Promise<A>) => Effect.Effect<A, SewedError, MainContext>;
/** Runs `use` with the native view behind a Sewed view or guest view handle. */
export declare const view: <A>(handle: View.Attachable, use: (native: NativeView) => A | Promise<A>) => Effect.Effect<A, SewedError, MainContext>;
//# sourceMappingURL=NativeAccess.d.ts.map