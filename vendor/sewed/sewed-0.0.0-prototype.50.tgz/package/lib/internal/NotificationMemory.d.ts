import { Layer } from "effect";
import * as Notification from "../Notification.ts";
import type { SewedError } from "../SewedError.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
/**
 * The notification capability for tests: the same options check `Notification.native` carries, no
 * Electron, and a recorder listing the calls.
 */
export declare const memory: () => Layer.Layer<typeof Notification.capability | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=NotificationMemory.d.ts.map