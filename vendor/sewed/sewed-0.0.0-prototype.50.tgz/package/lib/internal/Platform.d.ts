export type Platform = "darwin" | "win32" | "linux";
/**
 * Throws `Native` on a platform Electron does not implement a member for, so the member fails
 * there instead of pretending to succeed. Call it after decoding, so invalid input is still
 * `Protocol` everywhere.
 */
export declare const only: (platforms: ReadonlyArray<Platform>, what: string) => void;
//# sourceMappingURL=Platform.d.ts.map