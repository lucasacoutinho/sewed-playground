import type { WebContents } from "electron";
import { Scope } from "effect";
import { type Bound } from "../Binding.ts";
import type { Sink } from "./Diagnostics.ts";
export declare const mainBridge: (contents: WebContents, parent: Scope.Scope, diagnostics: Sink["Service"] | undefined) => {
    configure(url: URL, bindings: readonly Bound[]): void;
};
//# sourceMappingURL=MainBridge.d.ts.map