import { Effect } from "effect";
import type { Scope } from "effect";
import * as ContentTracing from "../ContentTracing.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { BufferUsage, Mode, Options } from "../ContentTracing.ts";
export declare const categories: Effect.Effect<readonly string[], SewedError, MainContext>;
export declare const bufferUsage: Effect.Effect<ContentTracing.BufferUsage, SewedError, MainContext>;
export interface Handle {
    /** Stops recording and returns the trace file; a second stop fails with `Closed`. */
    readonly stop: Effect.Effect<string, SewedError, MainContext>;
}
/**
 * Records a Chromium trace for the scope's lifetime and writes it to an absolute path. Stop early
 * with `stop`; closing the scope stops a recording that is still running.
 */
export declare const record: (file: string, options?: ContentTracing.Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
/**
 * Turns on heap profiling, so a trace recorded with the `memory-infra` category carries
 * allocation samples. Electron marks this experimental.
 */
export declare const enableHeapProfiling: (options?: ContentTracing.HeapProfiling) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=ContentTracing.d.ts.map