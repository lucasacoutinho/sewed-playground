import { Schema } from "effect";
import { type Bound } from "../Binding.ts";
import { SewedError } from "../SewedError.ts";
export declare const UtilityData: Schema.Struct<{
    url: Schema.String;
    ownerId: Schema.String;
    diagnostics: Schema.Boolean;
    tracing: Schema.Boolean;
    bindings: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly ownerId: Schema.String;
    }>>;
}>;
export declare const FromUtility: Schema.Union<readonly [Schema.TaggedStruct<"Ready", {
    readonly processId: Schema.Int;
}>, Schema.TaggedStruct<"Failed", {
    readonly message: Schema.String;
}>, Schema.TaggedStruct<"Diagnostics", {
    readonly events: Schema.$Array<Schema.Union<readonly [Schema.TaggedStruct<"OwnerStarted", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly ownerId: Schema.String;
    }>, Schema.TaggedStruct<"OwnerClosed", {
        readonly ownerId: Schema.String;
        readonly reason: Schema.Literals<readonly ["scope-closed", "shutdown", "terminated", "exited", "startup-failed"]>;
    }>, Schema.TaggedStruct<"RuntimeClosed", {
        readonly runtimeId: Schema.String;
    }>, Schema.TaggedStruct<"BindingOpened", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly bindingId: Schema.String;
        readonly slot: Schema.String;
        readonly ownerId: Schema.String;
    }>, Schema.TaggedStruct<"BindingClosed", {
        readonly bindingId: Schema.String;
        readonly reason: Schema.Literals<readonly ["scope-closed", "navigation", "renderer-gone", "renderer-disconnected", "replaced"]>;
    }>, Schema.TaggedStruct<"RequestStarted", {
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly procedure: Schema.String;
        readonly traceId: Schema.optionalKey<Schema.String>;
        readonly spanId: Schema.optionalKey<Schema.String>;
    }>, Schema.TaggedStruct<"RequestEnded", {
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
        readonly reason: Schema.String;
    }>, Schema.TaggedStruct<"EventsDropped", {
        readonly ownerId: Schema.String;
        readonly count: Schema.Finite;
    }>, Schema.TaggedStruct<"ResourceChanged", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly resourceId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly state: Schema.Literals<readonly ["acquiring", "ready", "releasing"]>;
    }>, Schema.TaggedStruct<"ResourceClosed", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly resourceId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
        readonly reason: Schema.String;
    }>, Schema.TaggedStruct<"TransferProgress", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly frames: Schema.Int;
        readonly wireBytes: Schema.Int;
        readonly terminal: Schema.Boolean;
    }>, Schema.TaggedStruct<"TraceSpan", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
        readonly parentId: Schema.optionalKey<Schema.String>;
        readonly name: Schema.String;
        readonly startTime: Schema.String;
        readonly endTime: Schema.optionalKey<Schema.String>;
        readonly outcome: Schema.Literals<readonly ["running", "success", "failure"]>;
        readonly ownerId: Schema.optionalKey<Schema.String>;
        readonly binding: Schema.optionalKey<Schema.String>;
    }>, Schema.TaggedStruct<"TraceEvent", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
        readonly name: Schema.String;
        readonly time: Schema.String;
    }>, Schema.TaggedStruct<"RuntimeSample", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly delayMs: Schema.Number;
        readonly intervalMs: Schema.Number;
    }>, Schema.TaggedStruct<"QueueSample", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly queueId: Schema.String;
        readonly ownerId: Schema.optionalKey<Schema.String>;
        readonly kind: Schema.Literals<readonly ["rpc-server", "rpc-client"]>;
        readonly size: Schema.Number;
        readonly capacity: Schema.Number;
        readonly activeRequests: Schema.optionalKey<Schema.Number>;
    }>, Schema.TaggedStruct<"QueueClosed", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly queueId: Schema.String;
    }>]>>;
    readonly dropped: Schema.Int;
}>, Schema.TaggedStruct<"Open", {
    readonly key: Schema.String;
    readonly requestId: Schema.String;
}>, Schema.TaggedStruct<"Cancel", {
    readonly requestId: Schema.String;
}>]>;
export declare const ToUtility: Schema.Union<readonly [Schema.TaggedStruct<"Initialize", {
    readonly url: Schema.String;
    readonly ownerId: Schema.String;
    readonly diagnostics: Schema.Boolean;
    readonly tracing: Schema.Boolean;
    readonly bindings: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly ownerId: Schema.String;
    }>>;
}>, Schema.TaggedStruct<"Shutdown", {}>, Schema.TaggedStruct<"DiagnosticsAck", {}>, Schema.TaggedStruct<"Connect", {}>, Schema.TaggedStruct<"Opened", {
    readonly requestId: Schema.String;
}>, Schema.TaggedStruct<"Rejected", {
    readonly requestId: Schema.String;
    readonly code: Schema.Literals<readonly ["Closed", "Protocol", "Limit", "Startup", "Native", "Unknown"]>;
    readonly message: Schema.String;
}>]>;
export type UtilityDiagnosticsMessage = Extract<typeof FromUtility.Type, {
    readonly _tag: "Diagnostics";
}>;
export interface UtilityParent {
    readonly postMessage: (message: unknown) => void;
}
export interface RemoteBindings {
    readonly bindings: readonly Bound[];
    readonly receive: (message: typeof ToUtility.Type, ports: readonly unknown[]) => void;
    readonly close: (reason?: SewedError) => void;
}
export declare const remoteBindings: (parent: UtilityParent, bindings: typeof UtilityData.Type.bindings) => RemoteBindings;
//# sourceMappingURL=UtilityBindings.d.ts.map