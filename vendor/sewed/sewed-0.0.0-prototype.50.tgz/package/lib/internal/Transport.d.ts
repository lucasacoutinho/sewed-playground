import { Schema } from "effect";
import { RpcClientError } from "effect/rpc/RpcClientError";
import type { FromClientEncoded, FromServerEncoded, ResponseChunkEncoded } from "effect/rpc/RpcMessage";
import { SewedError } from "../SewedError.ts";
import type { Encoding } from "./Encoding.ts";
export declare const maxMessageBytes: number;
/**
 * The smallest a non-final bulk part may be. The owner's allowance counts bytes, which bounds how
 * much one assembly holds but not how many parts it holds: a peer sending empty parts passes a
 * byte count forever. A floor on a non-final part bounds the count instead, so an assembly holds
 * at most `ceil((maxBytes + maxMessageBytes) / minPartBytes) + 1` parts — about 800 for a 12 MiB
 * bound. The final part is the tail and may be any size from one byte up.
 *
 * The floor never bites an honest client: a slice starts at half an envelope, 131072 bytes, and is
 * halved only when a part that size does not fit one envelope, which would need more than 128 KiB
 * of overhead from a request id and a tag.
 */
export declare const minPartBytes: number;
export declare const maxPendingMessages = 128;
export declare const maxRequestsPerConnection = 64;
export type Wire = string | Uint8Array;
/** The measure `encode` applies: a packet's bytes, or the UTF-8 bytes of JSON text. */
export declare const sizeOf: (wire: Wire) => number;
/** Rejoins a bulk request's parts into the one packet its client encoded. */
export declare const concat: (parts: readonly Uint8Array[]) => Uint8Array;
/**
 * The slice to try after one that did not fit an envelope, or `undefined` when there is none
 * left. Halving stops at `minPartBytes` because that is the floor the owner enforces on a
 * non-final part, and the clamp is what keeps a halving that would step past the floor from
 * landing under it — a part the owner would refuse for being too small is worse than none.
 * Answering `undefined` at the floor is what ends the attempt in a `Protocol` failure instead of
 * a loop that narrows forever.
 */
export declare const narrower: (slice: number) => number | undefined;
/**
 * The bytes a declared operation's bulk field carries, or `undefined` when the field holds
 * anything else. Over a `Binary.protocol` a `Binary.Bytes` field reaches the wire as the byte
 * array it is; a JSON codec would have turned it into base64 text by now, which is the case this
 * returning `undefined` reports.
 *
 * Asking `isBytes` rather than `instanceof` is belt-and-braces here, not load-bearing: both callers
 * are already past a point where the bytes are this realm's. The client reads a payload the codec
 * encoded, and `Binary.Bytes` re-viewed the field on the way through; the owner reads what
 * MessagePack produced, in the realm it runs in. It asks the transport's question anyway, so that
 * no caller has to know which of those two it is.
 */
export declare const bulkField: (payload: unknown, field: string) => Uint8Array | undefined;
/**
 * The id of the other wire type that reads the same: `"1"` for `1`, `1` for `"1"`. A peer that
 * names one request both ways has broken the protocol, so each side looks for this twin.
 */
export declare const aliasOf: (id: string | number) => string | number | undefined;
export interface Connection {
    readonly send: (message: Wire) => void;
    readonly subscribe: (receive: (message: unknown) => void, close: (reason: SewedError) => void) => () => void;
    readonly close: () => void;
}
/**
 * One slice of a request too large for a single envelope, on an operation that declared a bulk
 * bound. `bytes` is a slice of the encoded request's own MessagePack packet, so the owner
 * concatenates the slices and decodes the whole once, with no second codec. A bulk operation
 * belongs to a `Binary.protocol` — refused anywhere else where the slot is declared — so a part
 * carrying anything but bytes is not a packet this transport can have produced.
 */
declare const requestPart: Schema.TaggedStruct<"RequestPart", {
    readonly id: Schema.Union<readonly [Schema.String, Schema.Finite]>;
    readonly tag: Schema.String;
    readonly bytes: Schema.decodeTo<Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, never, never>;
    readonly final: Schema.Boolean;
}>;
export type RequestPart = typeof requestPart.Type;
/** The owner's answer to one `RequestPart`: the client may send the next slice. */
declare const partAck: Schema.TaggedStruct<"PartAck", {
    readonly requestId: Schema.Union<readonly [Schema.String, Schema.Finite]>;
}>;
export type PartAck = typeof partAck.Type;
/**
 * One slice of an answer too large for a single envelope, on a unary operation that declared
 * `Binary.bulkAnswer` — the mirror of `RequestPart` in the other direction. `bytes` is a slice of
 * the owner's own encoded `Exit` packet, so the client concatenates the slices and decodes the
 * whole once, with no second codec. The client acknowledges every non-final part with the same
 * `Ack` envelope that already paces a stream's chunks, one in flight; the final part carries no
 * acknowledgment of its own, because the assembled `Exit` it completes ends the request. A
 * bulk-answer operation belongs to a `Binary.protocol` — refused anywhere else where the slot is
 * declared — so a part carrying anything but bytes is not a packet this transport can have
 * produced.
 */
declare const answerPart: Schema.TaggedStruct<"AnswerPart", {
    readonly requestId: Schema.Union<readonly [Schema.String, Schema.Finite]>;
    readonly bytes: Schema.decodeTo<Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, never, never>;
    readonly final: Schema.Boolean;
}>;
export type AnswerPart = typeof answerPart.Type;
export declare function encode(message: unknown, encoding?: "json", limit?: number): string;
export declare function encode(message: unknown, encoding: "binary", limit?: number): Uint8Array;
export declare function encode(message: unknown, encoding: Encoding, limit?: number): Wire;
export declare function encodeChunks(chunk: ResponseChunkEncoded, encoding?: "json"): Generator<{
    readonly message: string;
    readonly final: boolean;
}>;
export declare function encodeChunks(chunk: ResponseChunkEncoded, encoding: "binary"): Generator<{
    readonly message: Uint8Array;
    readonly final: boolean;
}>;
export declare function encodeChunks(chunk: ResponseChunkEncoded, encoding: Encoding): Generator<{
    readonly message: Wire;
    readonly final: boolean;
}>;
/**
 * Slices a bulk answer's own encoded `Exit` packet into `AnswerPart` frames — the owner's mirror
 * of the client's own bulk-request `fragment`, but pure: sizing is the only concern here, and the
 * caller (`Runtime.ts`'s `send`) owns sending each frame and waiting for its acknowledgment. A
 * slice starts at half an envelope and is halved again on a `Limit`, down to the floor
 * `minPartBytes` enforces on the request side, since the client that will reassemble these parts
 * is the same one that floors a `RequestPart`'s own non-final size. A slice that does not fit one
 * envelope even at that floor rethrows the `Limit` it hit there — practically unreachable, since
 * an `AnswerPart`'s own wrapper costs a few dozen bytes, nowhere near the floor.
 */
export declare function answerParts(requestId: string | number, wire: Uint8Array, encoding?: Encoding): Generator<{
    readonly message: Wire;
    readonly final: boolean;
}>;
/**
 * A packet that parsed but did not decode, and the request it names when it names one: the
 * request that fails, typed, while the connection carries on. A packet that does not parse at all
 * names nothing — no part of it can be read — and ends the connection as a broken or hostile peer.
 */
export declare class Undecodable extends TypeError {
    readonly requestId: string | number | undefined;
    constructor(requestId: string | number | undefined, cause: unknown);
}
export declare const decodeClient: (message: unknown, encoding?: Encoding, limit?: number) => FromClientEncoded | RequestPart;
export declare const decodeServer: (message: unknown, encoding?: Encoding, limit?: number) => FromServerEncoded | PartAck | AnswerPart;
/**
 * What a relay asks of a packet before forwarding it: that it decodes, or that it names the
 * request it fails. The endpoint fails that one request and keeps the connection, so a relay that
 * refused the packet would end every call on the connection for what the endpoint confines to
 * one. A packet that names nothing throws, and the relay closes as it always has.
 */
export declare const relayable: (decode: (message: unknown) => unknown) => (message: unknown) => void;
export declare const rpcError: (cause: unknown) => RpcClientError;
/**
 * A synthetic `Exit` failure, in the exact wire shape a real owner's answer would carry: the
 * client's own `fail` typed-fails an in-flight request with it directly, and the owner's `send`
 * (`Runtime.ts`) reaches for the same shape when an `Exit` refuses the envelope after its
 * handler ran. This assumes the operation's own declared `error` schema admits `SewedError` —
 * true of every operation this library declares, but unenforced here: nothing stops a consumer's
 * own `Rpc.make` from omitting `error` entirely (or naming a schema that excludes `SewedError`),
 * and RpcClient then fails *this* synthetic exit's own decode instead of handing it to the
 * caller, so the caller sees `Protocol: <tag>: Expected never` for a loss after send, or the
 * plain rethrown `Closed` at the `connection.send` catch site below for one before send — never
 * this function's own `code`/`reason` (see `docs/transport.md`). `cause`, when given, is the
 * `SewedError` that actually triggered the failure (T7): the request's own reasoned message
 * stays the answer, with the trigger attached rather than dropped, for a caller that reads that
 * far. It travels as its encoded fields, `_tag`, `code`, `message` and `reason`: the caller's
 * decode admits only JSON values in `cause`, and an error instance is not one, so attaching the
 * instance itself failed the whole answer as `Protocol: Expected JSON value`.
 */
export declare const failExit: (requestId: string | number, code: "Closed" | "Unknown" | "Protocol" | "Limit", message: string, reason: string, cause?: SewedError) => FromServerEncoded;
/** A request a client has sent, or is sending, and not yet had answered. */
export declare const pair: () => readonly [Connection, Connection];
export {};
//# sourceMappingURL=Transport.d.ts.map