import { Effect, Scope } from "effect";
import { Rpc } from "effect/rpc";
import * as Binding from "../Binding.ts";
import type { Operations } from "../Capability.ts";
import { type HandlerLayer } from "./HandlerLayer.ts";
export declare const dispatch: <Rpcs extends Rpc.Any, E, R>(slot: Binding.Slot<Rpcs>, handlers: HandlerLayer<Rpcs, E, R>) => Effect.Effect<Operations<Rpcs>, E, R | Scope.Scope>;
//# sourceMappingURL=CapabilityDispatch.d.ts.map