import { type WebContents } from "electron";
import { Effect, Stream } from "effect";
import type { Bound, Complete } from "../Binding.ts";
import type * as Download from "../Download.ts";
import type { Entry } from "../Renderer.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as Registry from "./DecisionRegistry.ts";
/**
 * A renderer's web contents: the shared core plus the bridge, loading, and the bound-document
 * allowance. A browser window passes `windowDecidesTitle` for its own contents (see
 * `Owner.windowDecidesTitle`).
 */
export declare const webContents: (native: WebContents, options?: {
    readonly windowDecidesTitle?: boolean;
}) => Effect.Effect<{
    /**
     * This document's own decision registry, exposed for `internal/Window.ts` alone: its
     * window-level `page-title-updated` listener resolves `Decidables.WebContents.TitleUpdate`
     * here, because only that event's own `preventDefault` holds the native title bar (see
     * `docs/window-controls.md`). Not part of the public `WebContents` handle — `decide` above
     * is the public door onto this same registry.
     */
    registry: Registry.Registry<"contents">;
    contents: {
        frames: (options?: import("../WebContents.ts").FrameOptions) => Stream.Stream<import("../WebContents.ts").Frame, SewedError, MainContext>;
        painting: Effect.Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, SewedError, MainContext>;
        setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setFrameRate: (rate: import("../WebContents.ts").FrameRate) => Effect.Effect<void, SewedError, MainContext>;
        invalidate: Effect.Effect<void, SewedError, MainContext>;
        frameTree: Effect.Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], SewedError, MainContext>;
        rendererProcessId: Effect.Effect<number, SewedError, MainContext>;
        sharedWorkers: Effect.Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], SewedError, MainContext>;
        inspectSharedWorker: (id: string) => Effect.Effect<void, SewedError, MainContext>;
        devToolsTargetId: Effect.Effect<string, SewedError, MainContext>;
        addDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        removeDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        printers: Effect.Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], SewedError, MainContext>;
        webRtc: Effect.Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, SewedError, MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => Effect.Effect<void, SewedError, MainContext>;
        setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => Effect.Effect<void, SewedError, MainContext>;
        caretBrowsing: Effect.Effect<boolean, SewedError, MainContext>;
        setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
        events: Stream.Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, SewedError, MainContext>;
        activity: Effect.Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, SewedError, MainContext>;
        devTools: Effect.Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, SewedError, MainContext>;
        toggleDevTools: Effect.Effect<void, SewedError, MainContext>;
        setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
        inspectElement: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, MainContext>;
        enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => Effect.Effect<void, SewedError, MainContext>;
        disableDeviceEmulation: Effect.Effect<void, SewedError, MainContext>;
        edit: (command: import("../WebContents.ts").EditCommand) => Effect.Effect<void, SewedError, MainContext>;
        replace: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => Effect.Effect<void, SewedError, MainContext>;
        copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        copyImageAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => Effect.Effect<void, SewedError, MainContext>;
        setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => Effect.Effect<void, SewedError, MainContext>;
        startDrag: (drag: import("../WebContents.ts").Drag) => Effect.Effect<void, SewedError, MainContext>;
        showDefinitionForSelection: Effect.Effect<void, SewedError, MainContext>;
        takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        print: (options?: import("../WebContents.ts").PrintOptions) => Effect.Effect<void, SewedError, MainContext>;
        pdf: (options?: import("../WebContents.ts").PdfOptions) => Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
        capture: (options?: import("../WebContents.ts").CaptureOptions) => Effect.Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, SewedError, MainContext>;
        zoom: Stream.Stream<{
            readonly factor: number;
        }, never, MainContext>;
        setZoom: (factor: number) => Effect.Effect<void, SewedError, MainContext>;
        audio: Stream.Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, MainContext>;
        setAudioMuted: (muted: boolean) => Effect.Effect<void, SewedError, MainContext>;
        userAgent: Effect.Effect<string, SewedError, MainContext>;
        setUserAgent: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
        insertText: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        savePage: (path: string, type?: import("../WebContents.ts").SaveType) => Effect.Effect<void, SewedError, MainContext>;
        setBackgroundThrottling: (allowed: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
        find: (text: string, options?: import("../WebContents.ts").FindOptions) => Effect.Effect<import("../WebContents.ts").Search, SewedError, MainContext | import("effect/Scope").Scope>;
        findNext: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
        stopFind: (action?: import("../WebContents.ts").FindStop) => Effect.Effect<void, SewedError, MainContext>;
        style: (css: string, options?: import("../WebContents.ts").StyleOptions) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
        history: Stream.Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, MainContext>;
        back: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        forward: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        go: (index: number) => Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        removeHistoryEntry: (index: number) => Effect.Effect<void, SewedError, MainContext>;
        clearHistory: Effect.Effect<void, SewedError, MainContext>;
        openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => Effect.Effect<void, SewedError, MainContext>;
        closeDevTools: Effect.Effect<void, SewedError, MainContext>;
        focus: Effect.Effect<void, SewedError, MainContext>;
        console: Stream.Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, SewedError, MainContext>;
        state: Stream.Stream<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, MainContext>;
        responsiveness: Stream.Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, MainContext>;
        favicons: Stream.Stream<readonly string[], never, MainContext>;
        title: Stream.Stream<string, never, MainContext>;
        current: Effect.Effect<{
            readonly state: {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, SewedError, MainContext>;
        terminate: Effect.Effect<void, SewedError, MainContext>;
        recover: Effect.Effect<void, SewedError, MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
        /**
         * The webviews and main-frame navigations this document's policy denied, and the popups
         * denied with no decider installed to allow them; an allowed popup opens and is not reported
         * here.
         */
        blocked: Stream.Stream<{
            readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
            readonly url: string;
        }, SewedError, MainContext>;
        load: <Keys extends string, const B extends readonly Bound<Keys>[]>(entry: Entry<Keys> & Complete<Keys, B>, options: {
            readonly bindings: B;
        }) => Effect.Effect<undefined, SewedError, MainContext>;
        reload: Effect.Effect<void, SewedError, MainContext>;
        /** Reloads the document, fetching every resource again instead of reading the cache. */
        reloadIgnoringCache: Effect.Effect<void, SewedError, MainContext>;
        /** Stops a navigation or load that is still in progress. */
        stopLoading: Effect.Effect<void, SewedError, MainContext>;
        downloads: Stream.Stream<Download.Handle, SewedError, MainContext>;
    };
}, never, MainContext | import("effect/Scope").Scope>;
//# sourceMappingURL=WebContents.d.ts.map