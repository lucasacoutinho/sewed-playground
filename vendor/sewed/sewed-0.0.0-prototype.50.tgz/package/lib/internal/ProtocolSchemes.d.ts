import * as Declaration from "../Declaration.ts";
import * as Protocol from "../Protocol.ts";
/**
 * Declares privileged schemes, registered in one call before readiness. Electron accepts that
 * call once per process, so one declaration carries every scheme and a second in the same list
 * fails `Startup`.
 */
export declare const declare: (...schemes: readonly Protocol.Scheme[]) => Declaration.Declaration;
//# sourceMappingURL=ProtocolSchemes.d.ts.map