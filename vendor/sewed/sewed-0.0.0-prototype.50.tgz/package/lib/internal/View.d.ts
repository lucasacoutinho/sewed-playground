import type { View as NativeView } from "electron";
import { Effect, Scope } from "effect";
import type { Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import { Bounds as BoundsSchema } from "./Geometry.ts";
type Bounds = BoundsSchema;
export declare const viewIdentity: unique symbol;
/** Any Sewed view handle; windows and container views attach these. */
export interface Attachable {
    readonly [viewIdentity]: true;
    readonly id: string;
}
export interface AttachOptions {
    readonly bounds: Bounds;
    readonly visible?: boolean;
}
/** One-shot: `attachment.current`'s own answer, read fresh from the native view at the callback. */
export interface AttachmentSnapshot {
    readonly bounds: Bounds;
    readonly visible: boolean;
}
export interface Attachment {
    /** `getBounds`/`getVisible` answer synchronously (`.artifacts/probe-wave-5/raise.mjs`), so this
     * is a fresh read, not a cached one — the same shape `internal/Window.ts`'s own `current` reads
     * through `readState`. */
    readonly current: Effect.Effect<AttachmentSnapshot, SewedError, MainContext>;
    readonly setBounds: (bounds: Bounds) => Effect.Effect<void, SewedError, MainContext>;
    readonly setVisible: (visible: boolean) => Effect.Effect<void, SewedError, MainContext>;
    /** The view's bounds each time they change, whoever changed them. */
    readonly boundsChanges: Stream.Stream<Bounds, SewedError, MainContext>;
    /** Blurs what is behind the view by a radius in pixels; zero removes the blur. */
    readonly setBackgroundBlur: (radius: number) => Effect.Effect<void, SewedError, MainContext>;
    /**
     * Draws this attachment above its siblings. `.artifacts/probe-wave-5/children-order.mjs` proves
     * a repeated `addChildView` on an already-attached view reorders it to the topmost position —
     * Electron's own doc comment on the method says as much — so this is the one native call, not a
     * remove-then-add: an index would lie the moment another attachment moves, and this can't.
     */
    readonly raise: Effect.Effect<void, SewedError, MainContext>;
    readonly detach: Effect.Effect<void, SewedError, MainContext>;
}
interface NativeAttachment extends Attachment {
    readonly detachNative: () => void;
    readonly closeView: () => Effect.Effect<void, never, never>;
}
/** Private state behind every view handle; `isDestroyed` reports the native object's own death. */
export interface State {
    readonly native: NativeView;
    readonly lifetime: Scope.Closeable;
    readonly isDestroyed: () => boolean;
    closedFlag: boolean;
    scopeClosing: boolean;
    attachment: NativeAttachment | undefined;
}
export declare const register: (handle: Attachable, state: State) => void;
/**
 * Where a parent stands: `closed` takes no new attachment but still has a native view to detach
 * children from; `destroyed` has none left to touch.
 */
export type ParentState = "open" | "closed" | "destroyed";
/** Owns the attachments of one parent: caller scopes detach, parent closure closes the views. */
export declare const makeParent: (parent: {
    readonly view: () => NativeView;
    readonly state: () => ParentState;
}) => {
    attach: (view: Attachable, options: AttachOptions) => Effect.Effect<Attachment, SewedError, MainContext | Scope.Scope>;
    closeAll: Effect.Effect<undefined, never, never>;
};
/** Shared lifecycle for plain views: a scope, a closed flag, and detachment on close. */
export declare const lifecycle: <N extends NativeView>(native: N, isDestroyed: () => boolean) => Effect.Effect<{
    id: string;
    state: State;
    lifetime: Scope.Closeable;
    operation: <A>(run: () => A) => Effect.Effect<A, SewedError, MainContext>;
    close: Effect.Effect<void, never, MainContext>;
    awaitClosed: Effect.Effect<void, never, MainContext>;
}, never, MainContext | Scope.Scope>;
/** A color as Electron spells one; shared by every surface that paints a background. */
export declare const decodeColor: (input: unknown, options?: import("effect/SchemaAST").ParseOptions) => string;
export interface Options {
    readonly backgroundColor?: string;
    readonly borderRadius?: number;
    readonly visible?: boolean;
}
/** A container view: it attaches child views and is itself attachable. */
export interface Handle extends Attachable {
    readonly attach: (view: Attachable, options: AttachOptions) => Effect.Effect<Attachment, SewedError, MainContext | Scope.Scope>;
    readonly setBackgroundColor: (color: string) => Effect.Effect<void, SewedError, MainContext>;
    readonly setBorderRadius: (radius: number) => Effect.Effect<void, SewedError, MainContext>;
    readonly setVisible: (visible: boolean) => Effect.Effect<void, SewedError, MainContext>;
    readonly close: Effect.Effect<void, never, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
/**
 * Builds a container view's handle over an *already-constructed* native view: `View.make` (the
 * root module) is the only caller in production, and it is the one that does `new NativeView()`
 * — construction stays in the owning runtime, this module stays Electron-value-free, and a test
 * hands this a structural fake instead (`view.test.ts`).
 */
export declare const fromNative: (native: NativeView, options?: Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
export {};
//# sourceMappingURL=View.d.ts.map