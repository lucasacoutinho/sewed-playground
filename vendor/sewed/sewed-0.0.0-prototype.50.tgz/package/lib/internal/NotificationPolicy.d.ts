import { Effect, Stream } from "effect";
import * as Notification from "../Notification.ts";
import { SewedError } from "../SewedError.ts";
/**
 * The platform call a notification capability makes once its options have been checked. `native`
 * supplies Electron's `Notification`; a test supplies its own. `R` is whatever that implementation
 * requires, so the rules above it stay free of any runtime requirement of their own.
 */
export interface Core<R> {
    readonly show: (options: Notification.Options) => Stream.Stream<Notification.Event, SewedError, R>;
}
/**
 * The notification operations a capability serves, already behind the options check. That check
 * fails the request's own stream without changing any signature, so this is the core's shape
 * exactly. One declaration, so the two cannot drift.
 */
export type Operations<R> = Core<R>;
/**
 * Returns operations that check the options before the core runs, so the core only ever sees
 * options the schema accepted. This is the only place that rule lives for the hosted path, so the
 * native Layer, a served renderer call, and the memory Layer cannot drift apart. The options
 * arrive in the payload, so they are checked per call rather than while the Layer builds, and an
 * invalid request fails on its own stream.
 */
export declare const operations: <R>(core: Core<R>) => Effect.Effect<Operations<R>, SewedError>;
//# sourceMappingURL=NotificationPolicy.d.ts.map