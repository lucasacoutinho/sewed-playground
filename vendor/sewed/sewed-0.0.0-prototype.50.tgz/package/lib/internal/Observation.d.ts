import type { EventEmitter } from "node:events";
import { Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/**
 * A stream where every observer owns its native registration and a queue of 128 values;
 * overflow fails that observer with `Limit` and leaves the others untouched.
 */
export declare const listen: <A>(what: string, register: (offer: (value: A) => void) => Effect.Effect<() => void, SewedError, MainContext>) => Stream.Stream<A, SewedError, MainContext>;
/** Observes named events on a Node emitter; a projection returning undefined drops the event. */
export declare const fromEmitter: <A>(what: string, emitter: () => EventEmitter, events: readonly (readonly [string, (...args: never[]) => A | undefined])[]) => Stream.Stream<A, SewedError, MainContext>;
//# sourceMappingURL=Observation.d.ts.map