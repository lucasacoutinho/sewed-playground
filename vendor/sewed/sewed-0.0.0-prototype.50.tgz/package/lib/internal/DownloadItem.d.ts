import type * as Download from "../Download.ts";
type Phase = "progressing" | "interrupted";
type Terminal = "completed" | "cancelled" | "interrupted";
/** The subset of Electron's DownloadItem the adopted handle drives. */
export interface AdoptableItem {
    on(event: "updated", listener: (event: unknown, state: Phase) => void): unknown;
    on(event: "done", listener: (event: unknown, state: Terminal) => void): unknown;
    off(event: "updated", listener: (event: unknown, state: Phase) => void): unknown;
    off(event: "done", listener: (event: unknown, state: Terminal) => void): unknown;
    getReceivedBytes(): number;
    getTotalBytes(): number;
    getPercentComplete(): number;
    getCurrentBytesPerSecond(): number;
    canResume(): boolean;
    isPaused(): boolean;
    getState(): "progressing" | Terminal;
    getSavePath(): string;
    getStartTime(): number;
    getEndTime(): number;
    getETag(): string;
    getLastModifiedTime(): string;
    pause(): void;
    resume(): void;
    cancel(): void;
}
/** The file and response facts Electron keeps on a download item. */
export declare const detailsOf: (item: Pick<AdoptableItem, "getSavePath" | "getStartTime" | "getEndTime" | "getETag" | "getLastModifiedTime">) => Download.Details;
/** Wraps a native download Electron already started; the handle ends with the item. */
export declare const adopt: (item: AdoptableItem) => Download.Handle;
export {};
//# sourceMappingURL=DownloadItem.d.ts.map