import { Effect, Scope } from "effect";
import type * as Automation from "../Automation.ts";
import * as Public from "../GuestView.ts";
import { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import * as ContentsPopups from "./ContentsPopups.ts";
import { type Core } from "./WebContentsCore.ts";
export { HostPolicy, InputPolicy, Settings, WebRtcPolicy, protocol, tab } from "../GuestView.ts";
export type { Options } from "../GuestView.ts";
export { native } from "./GuestHost.ts";
/** A guest view handle whose web contents is the shared core; see the root `Handle`. */
export type Handle<A extends Automation.Declaration = {}> = Public.Handle<A, Core, ContentsPopups.Handle>;
/**
 * Acquires a view for a page the application does not own: no preload, no bridge, a navigation
 * policy fixed at creation (`Navigation.Rules`: URL rules or match patterns), denied webviews,
 * decider-gated popups and downloads, and the automation declared here. The view lives until the
 * scope closes or `close` runs; it is never recreated.
 */
export declare const make: <const A extends Automation.Declaration = {}>(options: Public.Options<A>) => Effect.Effect<Handle<A>, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=GuestView.d.ts.map