import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as ServiceWorker from "../ServiceWorker.ts";
import type { Handle } from "./Session.ts";
export interface ServiceWorkers {
    readonly running: Effect.Effect<readonly ServiceWorker.Info[], SewedError, MainContext>;
    /** One worker by its version id, or `null` when no worker has it. */
    readonly info: (versionId: number) => Effect.Effect<ServiceWorker.Info | null, SewedError, MainContext>;
    /**
     * Starts the worker registered for a scope, or answers the one already running, as its version
     * id, scope and script. Electron marks this experimental.
     */
    readonly start: (scope: string) => Effect.Effect<ServiceWorker.Started, SewedError, MainContext>;
    /**
     * Keeps a running worker from being stopped for idleness, for the scope's lifetime. Fails
     * `Protocol` for a version id no running worker has. Electron marks this experimental.
     */
    readonly keepAlive: (versionId: number) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
    /** Every observer owns its listeners and a queue of 128 events; overflow fails it with `Limit`. */
    readonly events: Stream.Stream<ServiceWorker.Event, SewedError, MainContext>;
}
export declare const serviceWorkers: (handle: Handle) => ServiceWorkers;
//# sourceMappingURL=ServiceWorkers.d.ts.map