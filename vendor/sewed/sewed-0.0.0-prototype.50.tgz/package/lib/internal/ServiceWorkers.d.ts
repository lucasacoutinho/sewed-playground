import { Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import * as ServiceWorker from "../ServiceWorker.ts";
import type { Handle } from "./Session.ts";
export interface ServiceWorkers {
    readonly running: Effect.Effect<readonly ServiceWorker.Info[], SewedError, MainContext>;
    /** One worker by its version id, or `null` when no worker has it. */
    readonly info: (versionId: number) => Effect.Effect<ServiceWorker.Info | null, SewedError, MainContext>;
    /** Every observer owns its listeners and a queue of 128 events; overflow fails it with `Limit`. */
    readonly events: Stream.Stream<ServiceWorker.Event, SewedError, MainContext>;
}
export declare const serviceWorkers: (handle: Handle) => ServiceWorkers;
//# sourceMappingURL=ServiceWorkers.d.ts.map