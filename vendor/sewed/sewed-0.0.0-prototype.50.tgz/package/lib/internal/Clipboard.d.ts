import { Effect, Layer } from "effect";
import * as Clipboard from "../Clipboard.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as ClipboardPolicy from "./ClipboardPolicy.ts";
export { Content, Format, Policy, capability, protocol } from "../Clipboard.ts";
export declare const read: (format: Clipboard.Format) => Effect.Effect<{
    readonly kind: "text";
    readonly text: string;
} | {
    readonly kind: "html";
    readonly html: string;
    readonly text?: string;
} | {
    readonly kind: "rtf";
    readonly rtf: string;
} | {
    readonly kind: "image";
    readonly png: Uint8Array<ArrayBufferLike>;
} | {
    readonly kind: "bookmark";
    readonly title: string;
    readonly url: string;
} | null, SewedError, MainContext>, write: (content: Clipboard.Content) => Effect.Effect<void, SewedError, MainContext>, formats: Effect.Effect<readonly ("bookmark" | "html" | "image" | "rtf" | "text")[], SewedError, MainContext>, clear: Effect.Effect<void, SewedError, MainContext>;
/**
 * The primary selection on Linux: what was last selected, pasted with the middle button. It has
 * the system clipboard's operations and is main's alone, with no policy and no capability. Every
 * operation fails `Native` on other platforms.
 */
export declare const selection: ClipboardPolicy.Core<MainContext>;
/**
 * The clipboard capability for main. The policy lives in this Layer, not in a separate host, so
 * `Capability.serve(Clipboard.capability)` gives a document exactly the rules a main-side call
 * obeys.
 */
export declare const native: (policy: Clipboard.Policy) => Layer.Layer<typeof Clipboard.capability, SewedError, MainContext>;
//# sourceMappingURL=Clipboard.d.ts.map