import { Effect, Layer } from "effect";
import * as Clipboard from "../Clipboard.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Content, Format, Policy, capability, protocol } from "../Clipboard.ts";
/** Reads one format, or `null` when the clipboard holds nothing of that kind. */
export declare const read: (format: Clipboard.Format) => Effect.Effect<Clipboard.Content | null, SewedError, MainContext>;
/** Replaces the clipboard atomically with one piece of content. */
export declare const write: (content: Clipboard.Content) => Effect.Effect<void, SewedError, MainContext>;
/** Presence checks run in parallel, one per format, without materializing any content. */
export declare const formats: Effect.Effect<readonly Clipboard.Format[], SewedError, MainContext>;
export declare const clear: Effect.Effect<void, SewedError, MainContext>;
/**
 * The clipboard capability for main. The policy lives in this Layer, not in a separate host, so
 * `Capability.serve(Clipboard.capability)` gives a document exactly the rules a main-side call
 * obeys.
 */
export declare const native: (policy: Clipboard.Policy) => Layer.Layer<typeof Clipboard.capability, SewedError, MainContext>;
//# sourceMappingURL=Clipboard.d.ts.map