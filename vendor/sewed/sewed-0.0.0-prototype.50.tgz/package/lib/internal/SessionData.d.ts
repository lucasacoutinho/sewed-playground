import { Effect } from "effect";
import type { Scope, Stream } from "effect";
import type * as Extension from "../Extension.ts";
import type { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import * as SessionStorage from "../SessionStorage.ts";
import type { Handle } from "./Session.ts";
/** Clears browsing data by type and origin; with no options, everything the session stores. */
export declare const clearData: (handle: Handle, options?: SessionStorage.ClearData) => Effect.Effect<void, SewedError, MainContext>;
/** How much each isolation key's shared compression dictionaries occupy. */
export declare const sharedDictionaryUsage: (handle: Handle) => Effect.Effect<ReadonlyArray<SessionStorage.SharedDictionaryUsage>, SewedError, MainContext>;
/** The shared compression dictionaries stored under one isolation key. */
export declare const sharedDictionaries: (handle: Handle, key: SessionStorage.SharedDictionaryKey) => Effect.Effect<ReadonlyArray<SessionStorage.SharedDictionary>, SewedError, MainContext>;
/** Clears shared compression dictionaries: one isolation key's, or all of them without a key. */
export declare const clearSharedDictionaries: (handle: Handle, key?: SessionStorage.SharedDictionaryKey) => Effect.Effect<void, SewedError, MainContext>;
/** Spell checker dictionary files being fetched and becoming usable. */
export declare const spellCheckerDictionaries: (handle: Handle) => Stream.Stream<SessionStorage.DictionaryEvent, SewedError, MainContext>;
/**
 * Sets where spell checker dictionaries are downloaded from, instead of Google's servers. The
 * URL must end in a slash; Chromium appends the dictionary file name.
 */
export declare const setSpellCheckerDictionaryDownloadUrl: (handle: Handle, url: string) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Names the servers integrated authentication (NTLM, Negotiate) may send credentials to, as
 * host patterns such as `*.example.com`. Without it Chromium sends them only to intranet hosts.
 */
export declare const allowNtlmCredentialsForDomains: (handle: Handle, domains: ReadonlyArray<string>) => Effect.Effect<void, SewedError, MainContext>;
/** Sets the directory V8's generated code cache is kept in; it must be absolute. */
export declare const setCodeCachePath: (handle: Handle, directory: string) => Effect.Effect<void, SewedError, MainContext>;
/** The extensions loaded in the session. */
export declare const extensions: (handle: Handle) => Effect.Effect<ReadonlyArray<Extension.Info>, SewedError, MainContext>;
/** Extensions being loaded, becoming ready, and being unloaded. */
export declare const extensionEvents: (handle: Handle) => Stream.Stream<Extension.Event, SewedError, MainContext>;
/**
 * Registers a preload script for the scope's lifetime and answers its id; closing the scope
 * unregisters it. It runs in every frame, or every service worker, of the web contents that use
 * the session from then on, beside Sewed's own bridge preload and not instead of it.
 */
export declare const registerPreloadScript: (handle: Handle, script: SessionStorage.PreloadScript) => Effect.Effect<string, SewedError, MainContext | Scope.Scope>;
/** The preload scripts registered on the session, Sewed's own bridge included. */
export declare const preloadScripts: (handle: Handle) => Effect.Effect<ReadonlyArray<SessionStorage.RegisteredPreloadScript>, SewedError, MainContext>;
/** Whether the session has a handler for a scheme, its own or one an application registered. */
export declare const isProtocolHandled: (handle: Handle, scheme: string) => Effect.Effect<boolean, SewedError, MainContext>;
//# sourceMappingURL=SessionData.d.ts.map