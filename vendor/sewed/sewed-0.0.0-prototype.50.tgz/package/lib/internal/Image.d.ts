import { Effect, Schema } from "effect";
import { Bitmap, type Source } from "../Image.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Bitmap, Layer, Scaled, Source, aspectRatio, compose, crop } from "../Image.ts";
export declare const ResizeOptions: Schema.Struct<{
    readonly width: Schema.optionalKey<Schema.Int>;
    readonly height: Schema.optionalKey<Schema.Int>;
}>;
export type ResizeOptions = typeof ResizeOptions.Type;
export declare const EncodeOptions: Schema.Struct<{
    readonly format: Schema.Literals<readonly ["png", "jpeg"]>;
    readonly quality: Schema.optionalKey<Schema.Finite>;
}>;
export type EncodeOptions = typeof EncodeOptions.Type;
/**
 * Decodes an `Image.Source` — a path or already-encoded bytes (PNG, JPEG, and the other formats
 * `nativeImage` reads), the same shape and the same `nativeImageOf` resolution every icon door
 * takes — into a `Bitmap`. Fails `Protocol`, naming the path, for a path or bytes no decoder
 * accepts, `Native` for any other Electron failure.
 */
export declare const decode: (source: Source) => Effect.Effect<Bitmap, SewedError, MainContext>;
/**
 * Resizes a bitmap; omitting a dimension keeps the image's own. Fails `Protocol` for an invalid
 * bitmap or options, `Native` for an Electron failure.
 */
export declare const resize: (bitmap: Bitmap, options?: ResizeOptions) => Effect.Effect<Bitmap, SewedError, MainContext>;
/**
 * Encodes a bitmap to PNG or JPEG bytes; `quality` (0-100) applies to JPEG only and defaults to
 * 100. Fails `Protocol` for an invalid bitmap or options, `Native` for an Electron failure.
 */
export declare const encode: (bitmap: Bitmap, options: EncodeOptions) => Effect.Effect<Uint8Array, SewedError, MainContext>;
/**
 * The operating system's preview thumbnail for a file, by absolute path, on macOS and Windows.
 * Fails `Protocol` for a relative path or an invalid size, `Native` elsewhere and when the system
 * has no thumbnail for the file.
 */
export declare const thumbnail: (target: string, size: {
    readonly width: number;
    readonly height: number;
}) => Effect.Effect<Bitmap, SewedError, MainContext>;
/** A macOS system image by its `NSImageName`, such as `NSImageNameAddTemplate`. */
export declare const named: (name: string) => Effect.Effect<Bitmap, SewedError, MainContext>;
/** A macOS SF Symbol sized for a menu item, by symbol name. */
export declare const menuSymbol: (name: string) => Effect.Effect<Bitmap, SewedError, MainContext>;
/** A bitmap as a PNG `data:` URL, for an `img` element or a stylesheet. */
export declare const toDataUrl: (bitmap: Bitmap) => Effect.Effect<string, SewedError, MainContext>;
/** Decodes a `data:` URL holding a PNG or JPEG image into a bitmap. */
export declare const fromDataUrl: (url: string) => Effect.Effect<Bitmap, SewedError, MainContext>;
//# sourceMappingURL=Image.d.ts.map