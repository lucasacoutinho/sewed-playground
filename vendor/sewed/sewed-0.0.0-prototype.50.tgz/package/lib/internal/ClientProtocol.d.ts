import { Effect, Scope } from "effect";
import { RpcSerialization } from "effect/rpc";
import { RpcClientError } from "effect/rpc/RpcClientError";
import type { FromClientEncoded, FromServerEncoded } from "effect/rpc/RpcMessage";
import type { AnswerBound, Bound } from "./Bulk.ts";
import type { Encoding } from "./Encoding.ts";
import { type Connection } from "./Transport.ts";
export declare const clientProtocol: (connection: Connection, encoding?: Encoding, bounds?: ReadonlyMap<string, Bound>, answerBounds?: ReadonlyMap<string, AnswerBound>, onFailure?: () => void, options?: {
    readonly maxPendingBytes?: number;
}) => Effect.Effect<{
    readonly run: (clientId: number, f: (data: FromServerEncoded) => Effect.Effect<void>) => Effect.Effect<never>;
    readonly send: (clientId: number, request: FromClientEncoded, transferables?: ReadonlyArray<globalThis.Transferable>) => Effect.Effect<void, RpcClientError>;
    readonly supportsAck: boolean;
    readonly supportsTransferables: boolean;
    readonly codecFor: RpcSerialization.CodecFor;
}, never, Scope.Scope>;
//# sourceMappingURL=ClientProtocol.d.ts.map