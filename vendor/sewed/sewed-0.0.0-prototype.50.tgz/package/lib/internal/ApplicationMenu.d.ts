import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import * as Menu from "../Menu.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export interface Handle {
    /** Replaces the menu; the replaced menu's callbacks stop and nothing is restored. */
    readonly replace: (options: Menu.ApplicationOptions) => Effect.Effect<void, SewedError>;
    /** Future custom selections, to any number of observers, each with a queue of 128. */
    readonly selections: Stream.Stream<Menu.Selection, SewedError>;
    /** The menu opening (`will-show`) and closing (`will-close`), where the platform reports it. */
    readonly visibility: Stream.Stream<"will-show" | "will-close", SewedError, MainContext>;
}
/**
 * Installs the application menu for the caller's scope. Shared native state has one owner, so a
 * second live menu fails `Limit`. Releasing stops this menu's callbacks and fails its observers
 * `Closed`; it does not restore or clear the native menu — restoring one was tried on X11 and left
 * an open submenu on screen, which `docs/application-menus.md` records.
 */
export declare const make: (options: Menu.ApplicationOptions) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=ApplicationMenu.d.ts.map