import { Menu as NativeMenu } from "electron";
import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import * as Menu from "../Menu.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
type Items = readonly (Menu.Item | Menu.ApplicationItem)[];
export interface Handle<O = Menu.ApplicationOptions> {
    /** Replaces the menu; the replaced menu's callbacks stop and nothing is restored. */
    readonly replace: (options: O) => Effect.Effect<void, SewedError>;
    /** Future custom selections, to any number of observers, each with a queue of 128. */
    readonly selections: Stream.Stream<Menu.Selection, SewedError>;
    /** One item of the installed menu by its `id`; `Protocol` when the menu has no such item. */
    readonly item: (id: string) => Effect.Effect<Menu.ItemState, SewedError>;
    /** Changes one item in place, without rebuilding the menu or closing an open submenu. */
    readonly update: (id: string, change: Menu.ItemUpdate) => Effect.Effect<void, SewedError>;
    /** The menu opening (`will-show`) and closing (`will-close`), where the platform reports it. */
    readonly visibility: Stream.Stream<"will-show" | "will-close", SewedError, MainContext>;
}
/**
 * One place Electron keeps a menu: the application's, a window's menu bar, the dock's. Each has one
 * owner at a time, its own options, and its own way of saying whether a menu is still the one
 * installed there.
 */
export interface Slot<O> {
    /** Lower case, with its article: `["An", "application menu"]`. */
    readonly name: readonly [article: string, noun: string];
    readonly decode: (options: O) => {
        readonly items: Items;
    };
    readonly set: (menu: NativeMenu) => void;
    readonly isCurrent: (menu: NativeMenu) => boolean;
    readonly claimed: () => boolean;
    readonly claim: (held: boolean) => void;
}
/**
 * Installs the application menu for the caller's scope. Shared native state has one owner, so a
 * second live menu fails `Limit`. Releasing stops this menu's callbacks and fails its observers
 * `Closed`; it does not restore or clear the native menu — restoring one was tried on X11 and left
 * an open submenu on screen, which `docs/application-menus.md` records.
 */
export declare const make: (options: Menu.ApplicationOptions) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
/** The same owner over any slot: one live menu per slot, released with the caller's scope. */
export declare const makeIn: <O>(slot: Slot<O>, options: O) => Effect.Effect<Handle<O>, SewedError, MainContext | Scope.Scope>;
export {};
//# sourceMappingURL=ApplicationMenu.d.ts.map