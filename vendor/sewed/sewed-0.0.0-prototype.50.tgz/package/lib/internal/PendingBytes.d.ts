export declare const maximumPendingBytes: number;
/** Bytes held against a budget. Whoever holds the reservation releases it, once. */
export interface Reservation {
    /** Adds `bytes` and answers this reservation, or `undefined`, changing nothing, if they do not fit. */
    readonly grow: (bytes: number) => Reservation | undefined;
    readonly release: () => void;
}
export declare const make: (maximum?: number) => {
    reserve: (bytes: number) => Reservation | undefined;
};
//# sourceMappingURL=PendingBytes.d.ts.map