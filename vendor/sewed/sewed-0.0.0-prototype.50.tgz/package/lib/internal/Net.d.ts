import { Effect, Layer, Stream } from "effect";
import type { Scope } from "effect";
import { HttpClient } from "effect/http";
import * as Net from "../Net.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle as SessionHandle } from "./Session.ts";
export { Endpoint, ResolvedHost } from "../Net.ts";
export interface Options {
    /** Route requests through this session's cookies, cache, proxy, and interception. */
    readonly session?: SessionHandle;
    /** Skip handlers registered with `Protocol.handle` for this client. */
    readonly bypassCustomProtocolHandlers?: boolean;
}
/** Provides `HttpClient` backed by `net.fetch`, or a session's `fetch` when one is given. */
export declare const layer: (options?: Options) => Layer.Layer<HttpClient.HttpClient, SewedError, MainContext>;
export declare const online: Effect.Effect<boolean, SewedError, MainContext>;
export declare const resolveHost: (host: string) => Effect.Effect<Net.ResolvedHost, SewedError, MainContext>;
/** An open WebSocket made through Chromium's network stack, owned by the scope that made it. */
export interface WebSocketHandle {
    /** Messages as they arrive: text as a string, binary as bytes. Ends when the socket closes. */
    readonly messages: Stream.Stream<string | Uint8Array, SewedError, MainContext>;
    readonly send: (data: string | Uint8Array) => Effect.Effect<void, SewedError, MainContext>;
    /** Resolves with the close code and reason once the socket has closed, by either side. */
    readonly closed: Effect.Effect<Net.WebSocketClose, SewedError, MainContext>;
}
/**
 * Opens a WebSocket from the main process through Chromium's network stack, so it follows the
 * session's proxy, certificates and cookies, where Node's own socket follows none of them. It
 * resolves once the socket is open and fails `Native` if it cannot open; closing the scope
 * closes the socket.
 */
export declare const webSocket: (url: string, options?: Net.WebSocketOptions, session?: SessionHandle) => Effect.Effect<WebSocketHandle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Net.d.ts.map