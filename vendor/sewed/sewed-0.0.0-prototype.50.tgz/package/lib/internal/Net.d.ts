import { Effect, Layer } from "effect";
import { HttpClient } from "effect/http";
import * as Net from "../Net.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle as SessionHandle } from "./Session.ts";
export { Endpoint, ResolvedHost } from "../Net.ts";
export interface Options {
    /** Route requests through this session's cookies, cache, proxy, and interception. */
    readonly session?: SessionHandle;
    /** Skip handlers registered with `Protocol.handle` for this client. */
    readonly bypassCustomProtocolHandlers?: boolean;
}
/** Provides `HttpClient` backed by `net.fetch`, or a session's `fetch` when one is given. */
export declare const layer: (options?: Options) => Layer.Layer<HttpClient.HttpClient, SewedError, MainContext>;
export declare const online: Effect.Effect<boolean, SewedError, MainContext>;
export declare const resolveHost: (host: string) => Effect.Effect<Net.ResolvedHost, SewedError, MainContext>;
//# sourceMappingURL=Net.d.ts.map