import type { WebContents } from "electron";
import { Deferred, Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Source as ImageSource } from "../Image.ts";
import * as Registry from "./DecisionRegistry.ts";
import type { Handle as WebContentsViewHandle } from "./WebContentsView.ts";
import { decoded, protocolError } from "./ProtocolError.ts";
import { CaptureOptions, DevToolsHostOptions, DevToolsOptions, FindOptions, FindStop, PdfOptions, PrintOptions, SaveType, type Search, StyleOptions } from "../WebContents.ts";
export interface Owner {
    readonly registry: Registry.Registry<"contents">;
    readonly blocked: (kind: "navigation" | "redirect" | "popup" | "webview", url: string) => void;
    readonly allows?: (url: URL) => boolean;
    readonly displayScaleFactor: () => number;
    /** Turns an image source into a native image; an owner passes `ImageSource.nativeImageOf`. */
    readonly imageOf: (source: ImageSource, label: string) => Electron.NativeImage;
    /**
     * Whether a browser window's own `page-title-updated` listener asks
     * `Decidables.WebContents.TitleUpdate` for these contents. A browser window's own contents set
     * it: Electron emits the window's event for the same title change, and only that event's
     * `preventDefault` holds the native title, so the window asks and the contents do not ask again.
     * Guests and panes leave it unset and ask on the contents' own event.
     */
    readonly windowDecidesTitle?: boolean;
}
/** The closed state and the error-mapping helpers a composer builds its own operations with. */
export interface Control {
    readonly closed: Deferred.Deferred<void>;
    readonly isClosed: () => boolean;
    readonly closedError: () => SewedError;
    readonly operation: <A>(run: () => A) => Effect.Effect<A, SewedError, MainContext>;
    readonly asynchronous: <A>(message: string, run: () => Promise<A>) => Effect.Effect<A, SewedError, MainContext>;
}
export { decoded, protocolError };
export declare const nativeError: (message: string, cause: unknown) => SewedError;
/**
 * Starts a navigation on a fresh task. A state update published from a Chromium callback can
 * resume the waiting fiber on that callback's stack, and `loadURL` from there deadlocks Electron.
 */
export declare const onFreshTask: <A>(run: () => Promise<A>) => Promise<A>;
/** The operations every web contents shares; the owner's decision registry decides where the page may go. */
export declare const core: (native: WebContents, owner: Owner) => Effect.Effect<{
    contents: {
        frames: (options?: import("../WebContents.ts").FrameOptions) => Stream.Stream<import("../WebContents.ts").Frame, SewedError, MainContext>;
        painting: Effect.Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, SewedError, MainContext>;
        setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
        setFrameRate: (rate: import("../WebContents.ts").FrameRate) => Effect.Effect<void, SewedError, MainContext>;
        invalidate: Effect.Effect<void, SewedError, MainContext>;
        frameTree: Effect.Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], SewedError, MainContext>;
        opener: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        focusedFrame: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, SewedError, MainContext>;
        hostId: Effect.Effect<string | null, SewedError, MainContext>;
        devToolsContentsId: Effect.Effect<number | null, SewedError, MainContext>;
        collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        frame: (identity: import("../WebContents.ts").FrameAddress) => {
            info: Effect.Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly top: number | null;
                readonly detached: boolean;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            }, SewedError, MainContext>;
            reload: Effect.Effect<void, SewedError, MainContext>;
            collectJavaScriptCallStack: Effect.Effect<string | null, SewedError, MainContext>;
        };
        zoomLevel: Effect.Effect<number, SewedError, MainContext>;
        setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => Effect.Effect<void, SewedError, MainContext>;
        zoomMode: Effect.Effect<"default" | "disabled" | "isolated" | "manual", SewedError, MainContext>;
        setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => Effect.Effect<void, SewedError, MainContext>;
        rendererProcessId: Effect.Effect<number, SewedError, MainContext>;
        sharedWorkers: Effect.Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], SewedError, MainContext>;
        inspectSharedWorker: (id: string) => Effect.Effect<void, SewedError, MainContext>;
        devToolsTargetId: Effect.Effect<string, SewedError, MainContext>;
        addDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        removeDevToolsWorkspace: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        printers: Effect.Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], SewedError, MainContext>;
        webRtc: Effect.Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, SewedError, MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => Effect.Effect<void, SewedError, MainContext>;
        setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => Effect.Effect<void, SewedError, MainContext>;
        caretBrowsing: Effect.Effect<boolean, SewedError, MainContext>;
        setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
        events: Stream.Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, SewedError, MainContext>;
        activity: Effect.Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, SewedError, MainContext>;
        devTools: Effect.Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, SewedError, MainContext>;
        toggleDevTools: Effect.Effect<void, SewedError, MainContext>;
        setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, MainContext>;
        inspectElement: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, MainContext>;
        enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => Effect.Effect<void, SewedError, MainContext>;
        disableDeviceEmulation: Effect.Effect<void, SewedError, MainContext>;
        edit: (command: import("../WebContents.ts").EditCommand) => Effect.Effect<void, SewedError, MainContext>;
        replace: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => Effect.Effect<void, SewedError, MainContext>;
        copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        copyImageAt: (point: import("../WebContents.ts").PagePoint) => Effect.Effect<void, SewedError, MainContext>;
        setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => Effect.Effect<void, SewedError, MainContext>;
        setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => Effect.Effect<void, SewedError, MainContext>;
        startDrag: (drag: import("../WebContents.ts").Drag) => Effect.Effect<void, SewedError, MainContext>;
        showDefinitionForSelection: Effect.Effect<void, SewedError, MainContext>;
        takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, MainContext>;
        print: (options?: PrintOptions) => Effect.Effect<void, SewedError, MainContext>;
        pdf: (options?: PdfOptions) => Effect.Effect<Uint8Array<ArrayBuffer>, SewedError, MainContext>;
        capture: (options?: CaptureOptions) => Effect.Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, SewedError, MainContext>;
        zoom: Stream.Stream<{
            readonly factor: number;
        }, never, MainContext>;
        setZoom: (factor: number) => Effect.Effect<void, SewedError, MainContext>;
        audio: Stream.Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, MainContext>;
        setAudioMuted: (muted: boolean) => Effect.Effect<void, SewedError, MainContext>;
        userAgent: Effect.Effect<string, SewedError, MainContext>;
        setUserAgent: (userAgent: string) => Effect.Effect<void, SewedError, MainContext>;
        /** Types `text` at the focused element, as if the user had. */
        insertText: (text: string) => Effect.Effect<void, SewedError, MainContext>;
        /**
         * Saves the current document to an absolute path: its HTML alone, the HTML beside a
         * directory of its resources, or one MHTML archive.
         */
        savePage: (path: string, type?: SaveType) => Effect.Effect<void, SewedError, MainContext>;
        /** Whether the page keeps full timers and animation speed while it is not visible. */
        setBackgroundThrottling: (allowed: boolean) => Effect.Effect<void, SewedError, MainContext>;
        /** While set, key presses reach the page without triggering application menu accelerators. */
        setIgnoreMenuShortcuts: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
        find: (text: string, options?: FindOptions) => Effect.Effect<Search, SewedError, MainContext | import("effect/Scope").Scope>;
        /** Advances the active search; `Protocol` when none is active. */
        findNext: (forward?: boolean) => Effect.Effect<void, SewedError, MainContext>;
        stopFind: (action?: FindStop) => Effect.Effect<void, SewedError, MainContext>;
        /** Inserts CSS for the current document until the scope closes; a navigation drops it earlier. */
        style: (css: string, options?: StyleOptions) => Effect.Effect<void, SewedError, MainContext | import("effect/Scope").Scope>;
        history: Stream.Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, MainContext>;
        back: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        forward: Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        go: (index: number) => Effect.Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, SewedError, MainContext>;
        /**
         * Removes one history entry by index. The active entry cannot be removed, and neither can
         * an index the history does not have; both fail with `Protocol`.
         */
        removeHistoryEntry: (index: number) => Effect.Effect<void, SewedError, MainContext>;
        clearHistory: Effect.Effect<void, SewedError, MainContext>;
        openDevTools: (options?: DevToolsOptions) => Effect.Effect<void, SewedError, MainContext>;
        /**
         * Opens DevTools inside a `WebContentsView` the program owns, so the application places
         * them like any other view. The view must not have loaded anything yet. It fails `Closed`
         * when either side is gone and `Protocol` for a view that is not a fresh Sewed view.
         * Hosted DevTools last as long as their view: closing the view closes them, and
         * `closeDevTools` closes only DevTools that have a window of their own.
         */
        openDevToolsIn: (host: WebContentsViewHandle, options?: DevToolsHostOptions) => Effect.Effect<void, SewedError, MainContext>;
        closeDevTools: Effect.Effect<void, SewedError, MainContext>;
        focus: Effect.Effect<void, SewedError, MainContext>;
        console: Stream.Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, SewedError, MainContext>;
        state: Stream.Stream<{
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, MainContext>;
        responsiveness: Stream.Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, MainContext>;
        favicons: Stream.Stream<readonly string[], never, MainContext>;
        title: Stream.Stream<string, never, MainContext>;
        current: Effect.Effect<{
            readonly state: {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, SewedError, MainContext>;
        terminate: Effect.Effect<void, SewedError, MainContext>;
        recover: Effect.Effect<void, SewedError, MainContext>;
        /**
         * Installs a decider for one of `Decidables.WebContents`'s decidables against this contents'
         * own registry, for the caller's scope. Any number of deciders may be installed, and the
         * decidable's own composition decides among them.
         */
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, R | MainContext | import("effect/Scope").Scope>;
    };
    control: Control;
}, never, MainContext | import("effect/Scope").Scope>;
export type Core = Effect.Success<ReturnType<typeof core>>["contents"];
//# sourceMappingURL=WebContentsCore.d.ts.map