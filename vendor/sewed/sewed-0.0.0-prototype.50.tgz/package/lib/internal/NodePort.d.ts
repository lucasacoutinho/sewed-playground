import { type MessagePort } from "node:worker_threads";
import { SewedError } from "../SewedError.ts";
import type { Connection } from "./Transport.ts";
export declare const connectPort: (transfer: (port: MessagePort) => void) => import("effect/Effect").Effect<Connection, SewedError, import("effect/Scope").Scope>;
export declare const nodePort: (port: MessagePort) => Connection;
//# sourceMappingURL=NodePort.d.ts.map