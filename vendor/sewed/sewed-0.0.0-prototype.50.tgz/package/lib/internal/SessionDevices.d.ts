import { Effect } from "effect";
import type { Stream } from "effect";
import * as Device from "../Device.ts";
import type { MainContext } from "../RuntimeContext.ts";
import type { SewedError } from "../SewedError.ts";
import type { Handle } from "./Session.ts";
/**
 * HID, USB and serial devices that appear or go away while a chooser request is pending, and
 * devices whose access a page gave up. Each observer owns its native listeners.
 */
export declare const deviceChanges: (handle: Handle) => Stream.Stream<Device.Change, SewedError, MainContext>;
/**
 * Sets which USB classes pages cannot reach. An empty list protects none; `null` restores
 * Chromium's own list.
 */
export declare const setUsbProtectedClasses: (handle: Handle, classes: ReadonlyArray<Device.UsbClass> | null) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=SessionDevices.d.ts.map