import { Effect, Scope } from "effect";
import type * as Public from "../WebContentsView.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import { type Attachable } from "./View.ts";
import { webContents } from "./WebContents.ts";
type Contents = Effect.Success<ReturnType<typeof webContents>>["contents"];
export interface Handle extends Attachable {
    readonly webContents: Contents;
    readonly close: Effect.Effect<void, SewedError, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
export declare const make: (options?: Public.Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
export {};
//# sourceMappingURL=WebContentsView.d.ts.map