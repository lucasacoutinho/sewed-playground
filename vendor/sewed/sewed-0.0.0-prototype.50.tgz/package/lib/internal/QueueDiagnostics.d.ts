import { Effect } from "effect";
export declare const observe: (size: () => number, capacity: number, options: {
    readonly kind: "rpc-server" | "rpc-client";
    readonly ownerId?: string;
    readonly activeRequests?: () => number;
}) => Effect.Effect<void, never, import("effect/Scope").Scope>;
//# sourceMappingURL=QueueDiagnostics.d.ts.map