import { Context, Effect, Layer } from "effect";
import type { Rpc } from "effect/rpc";
import type { Capability } from "../Capability.ts";
import type { HandlerLayer } from "./HandlerLayer.ts";
/** One operation a memory capability was asked for, in the order the calls were made. */
export interface Call {
    readonly tag: string;
    readonly payload: unknown;
}
declare const Recorder_base: Context.ServiceClass<Recorder, "sewed/CapabilityRecorder", {
    readonly calls: Effect.Effect<readonly Call[]>;
}>;
/** What a memory capability recorded. `calls` is a snapshot, so a test can read it repeatedly. */
export declare class Recorder extends Recorder_base {
}
/**
 * The in-memory Layer for a capability: the same dispatch the native Layer uses, over handlers a
 * test supplies, with every call recorded when it runs. The recorder observes the operation the
 * caller asked for, before the handler decides it, so a denial is recorded exactly like a call
 * that succeeds. The record happens inside the returned Effect or Stream rather than when the
 * operation is merely built, so building a call without running it records nothing, and running
 * a built call twice records it twice.
 */
export declare const memory: <Rpcs extends Rpc.Any, Key extends string, E, R>(capability: Capability<Rpcs, Key>, handlers: HandlerLayer<Rpcs, E, R>) => Layer.Layer<Capability<Rpcs, Key> | Recorder, E, R>;
export {};
//# sourceMappingURL=CapabilityMemory.d.ts.map