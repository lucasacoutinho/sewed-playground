import { Effect } from "effect";
import * as Net from "../Net.ts";
import * as Proxy from "../Proxy.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle } from "./Session.ts";
export declare const resolved: (handle: Handle) => Effect.Effect<Electron.Session, SewedError, MainContext>;
export declare const operation: <A>(handle: Handle, message: string, run: (native: Electron.Session) => A) => Effect.Effect<A, SewedError, MainContext>;
export declare const asynchronous: <A>(handle: Handle, message: string, run: (native: Electron.Session) => Promise<A>) => Effect.Effect<A, SewedError, MainContext>;
export declare const setProxy: (handle: Handle, config: Proxy.Config) => Effect.Effect<void, SewedError, MainContext>;
export declare const resolveProxy: (handle: Handle, url: string) => Effect.Effect<string, SewedError, MainContext>;
export interface SpellChecker {
    readonly enabled: boolean;
    readonly languages: readonly string[];
    readonly available: readonly string[];
}
export declare const spellChecker: (handle: Handle) => Effect.Effect<SpellChecker, SewedError, MainContext>;
export declare const setSpellChecker: (handle: Handle, settings: {
    readonly enabled?: boolean;
    readonly languages?: readonly string[];
}) => Effect.Effect<void, SewedError, MainContext>;
/** Makes the session read its proxy configuration again, for example after a PAC file changed. */
export declare const forceReloadProxyConfig: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
/** The words in the session's custom spell checker dictionary. */
export declare const spellCheckerWords: (handle: Handle) => Effect.Effect<ReadonlyArray<string>, SewedError, MainContext>;
/**
 * Adds a word to the session's custom spell checker dictionary. An in-memory session has no
 * dictionary to write, and the refusal is `Native`.
 */
export declare const addSpellCheckerWord: (handle: Handle, word: string) => Effect.Effect<void, SewedError, MainContext>;
/** Removes a word from the session's custom spell checker dictionary. */
export declare const removeSpellCheckerWord: (handle: Handle, word: string) => Effect.Effect<void, SewedError, MainContext>;
export declare const clearCache: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
export declare const cacheSize: (handle: Handle) => Effect.Effect<number, SewedError, MainContext>;
/** Forgets the HTTP credentials the session cached, so the next challenge asks again. */
export declare const clearAuthCache: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
/** Forgets the session's cached host resolutions. */
export declare const clearHostResolverCache: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Clears the generated code cache: for the resources at `urls`, or for every resource when none
 * is named.
 */
export declare const clearCodeCaches: (handle: Handle, urls?: ReadonlyArray<string>) => Effect.Effect<void, SewedError, MainContext>;
/** Writes DOM storage that is still in memory to disk. */
export declare const flushStorage: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
/** The directory the session persists to, or `null` for an in-memory session. */
export declare const storagePath: (handle: Handle) => Effect.Effect<string | null, SewedError, MainContext>;
/** Emulates the given network conditions for the session until {@link clearNetworkEmulation}. */
export declare const setNetworkEmulation: (handle: Handle, conditions: Net.Emulation) => Effect.Effect<void, SewedError, MainContext>;
/** Returns the session to the real network. */
export declare const clearNetworkEmulation: (handle: Handle) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Sets the TLS configuration for the session's new connections. Connections already open keep
 * the configuration they were made with; `session.closeAllConnections` ends them.
 */
export declare const setSSLConfig: (handle: Handle, config: Net.SSLConfig) => Effect.Effect<void, SewedError, MainContext>;
export declare const userAgent: (handle: Handle) => Effect.Effect<string, SewedError, MainContext>;
export declare const setUserAgent: (handle: Handle, value: string, acceptLanguages?: string) => Effect.Effect<void, SewedError, MainContext>;
export declare const setDownloadPath: (handle: Handle, directory: string) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=SessionSettings.d.ts.map