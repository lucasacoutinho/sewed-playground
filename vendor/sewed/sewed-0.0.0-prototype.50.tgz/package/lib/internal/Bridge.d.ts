import { Schema } from "effect";
import type { Wire } from "./Transport.ts";
export declare const Hello: Schema.Struct<{
    readonly session: Schema.String;
    readonly runtimeId: Schema.String;
    readonly tracing: Schema.Boolean;
    readonly bindings: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly ownerId: Schema.String;
    }>>;
}>;
export declare const Packet: Schema.Union<readonly [Schema.Struct<{
    readonly connection: Schema.String;
    readonly message: Schema.Union<readonly [Schema.String, Schema.decodeTo<Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, Schema.declare<Uint8Array<ArrayBufferLike>, Uint8Array<ArrayBufferLike>>, never, never>]>;
}>, Schema.Struct<{
    readonly connection: Schema.String;
    readonly error: Schema.String;
}>]>;
export interface Bridge {
    readonly hello: () => Promise<unknown>;
    readonly open: (session: string, slot: string, connection: string) => Promise<unknown>;
    readonly observe: (session: string, batch: string) => Promise<void>;
    readonly send: (session: string, connection: string, message: Wire) => void;
    readonly close: (session: string, connection: string) => void;
    readonly disconnect: (session: string) => void;
    readonly subscribe: (connection: string, receive: (packet: unknown) => void) => () => void;
    /** The native path of a `File` the user dropped or chose; empty when it has none. */
    readonly pathOf: (file: File) => string;
}
declare global {
    interface Window {
        readonly sewed?: Bridge;
    }
}
//# sourceMappingURL=Bridge.d.ts.map