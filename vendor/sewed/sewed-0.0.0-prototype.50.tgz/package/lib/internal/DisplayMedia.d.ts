import type { Session } from "electron";
import type * as Registry from "./DecisionRegistry.ts";
/**
 * Installs the display media handler that resolves `Decidables.Session.DisplayMedia` against
 * `registry` for every screen-share request the session receives, while it is installed —
 * `internal/Session.ts` calls this only from its `Session.DisplayMedia` hook's own `attach`, the
 * moment the decidable's entry count goes from zero to one, and clears the handler with `null` from
 * that same hook's `detach`, the moment it goes back to zero. There is no separate `null`-removal
 * path *here* the way there was for the old single-slot decider: closing a decider's own scope is
 * what removes it from the registry, and the hook is what turns "no deciders left" into the native
 * `null`.
 *
 * `NativeAnswer.run` is what makes the native callback total for every exit that settles: a decider
 * that dies, or a `reply` Electron itself rejects, both still leave the request answered exactly
 * once, denied. A decider that never completes is the one case `NativeAnswer.run` does not answer —
 * deliberately, by that module's own doc, since it declines to impose a timeout on a human-paced
 * decision — so a screen-share decider is responsible for its own liveness the same way any other
 * async decider is. A request with no decider installed, and one whose decider fails or answers
 * off-schema, both reach the decidable's own `deny` fallback inside `resolveAsync` itself, so the
 * answer `reply` receives is already a valid `DesktopCapturer.Decision` with no decoding left to do
 * here.
 */
export declare const install: (native: Session, registry: Registry.Resolver<"session">) => void;
//# sourceMappingURL=DisplayMedia.d.ts.map