import type { WebContents as NativeContents } from "electron";
import { Effect, Schema, Stream } from "effect";
import type { Scope } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { IpcMessage } from "../WebContents.ts";
import type { Control } from "./WebContentsCore.ts";
/**
 * Electron's raw IPC, for a page that carries its own preload (`Session.registerPreloadScript`)
 * and talks `ipcRenderer` instead of a binding. A Sewed page has no such preload, so nothing
 * arrives here unless the application put one there. Messages are untyped JSON with no schema, no
 * owner and no request scoping; bindings are the typed way to talk to a page.
 */
export declare const make: (native: NativeContents, control: Pick<Control, "closed" | "isClosed" | "closedError" | "operation">) => {
    ipc: {
        /** Messages the page sends with `ipcRenderer.send`. */
        messages: Stream.Stream<{
            readonly channel: string;
            readonly args: readonly Schema.Json[];
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
        }, SewedError, MainContext>;
        /** Sends to the main frame's `ipcRenderer.on(channel)`. */
        send: (channel: string, ...args: ReadonlyArray<Schema.Json>) => Effect.Effect<void, SewedError, MainContext>;
        /** Sends to one frame, named by its process and routing ids. */
        sendToFrame: (frame: {
            readonly processId: number;
            readonly routingId: number;
        }, channel: string, ...args: ReadonlyArray<Schema.Json>) => Effect.Effect<void, SewedError, MainContext>;
        /**
         * Answers `ipcRenderer.sendSync` for the scope's lifetime. The page is blocked until
         * `answer` returns, so it must be quick and cannot be an Effect; a throw, or no handler at
         * all, answers `null`.
         */
        answerSync: (answer: (message: IpcMessage) => Schema.Json) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
    };
};
//# sourceMappingURL=ContentsIpc.d.ts.map