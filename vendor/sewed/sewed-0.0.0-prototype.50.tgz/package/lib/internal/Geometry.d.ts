import { Schema } from "effect";
export declare const Point: Schema.Struct<{
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
}>;
export type Point = typeof Point.Type;
export declare const Bounds: Schema.Struct<{
    readonly x: Schema.Finite;
    readonly y: Schema.Finite;
    readonly width: Schema.Finite;
    readonly height: Schema.Finite;
}>;
export type Bounds = typeof Bounds.Type;
//# sourceMappingURL=Geometry.d.ts.map