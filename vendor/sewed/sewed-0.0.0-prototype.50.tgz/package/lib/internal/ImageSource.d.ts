import type { NativeImage } from "electron";
import { Source } from "../Image.ts";
export declare const nativeImageOf: (source: Source, label: string) => NativeImage;
//# sourceMappingURL=ImageSource.d.ts.map