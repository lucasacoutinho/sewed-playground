import type { NativeImage } from "electron";
import { Source } from "../Image.ts";
/**
 * Resolves an `Image.Source` (a path or already-encoded bytes) to a native image, for every icon
 * door that takes one: `internal/Window.ts`'s `setIcon` and `setOverlayIcon` in this wave, the
 * tray and the dock in the next. Fails `Protocol`, naming `label`, for a value outside the schema
 * or bytes no decoder reads back as a non-empty image.
 */
export declare const nativeImageOf: (source: Source, label: string) => NativeImage;
//# sourceMappingURL=ImageSource.d.ts.map