import { Context } from "effect";
import * as Registry from "./DecisionRegistry.ts";
export declare const make: (approveQuit: (code?: number) => boolean) => {
    registry: Registry.Registry<"app">;
    gate: {
        request(): void;
        close(): import("effect/Effect").Effect<void>;
    };
    /** What `App.decide` reads through `Registry.decide`'s `Control`, so it refuses after this closes. */
    isClosed: () => boolean;
    offer: (value: unknown) => void;
    launches: import("effect/Stream").Stream<{
        readonly kind: "initial";
        readonly arguments: readonly string[];
        readonly workingDirectory: string;
    } | {
        readonly kind: "file";
        readonly path: string;
    } | {
        readonly kind: "url";
        readonly url: string;
    }, import("../SewedError.ts").SewedError, never>;
    /**
     * Requests the application's end with `code`, calling `approveQuit` directly — never through
     * `gate`, so `Decidables.App.Quit` is never consulted — and answers whether that request is the
     * one the application will exit with. An invalid code (not an integer, or outside 0-255) is
     * refused without asking, and `approveQuit` refuses once a shutdown is already in progress,
     * whichever door began it: one exit code wins, the first. The answer is what lets `App.exit`
     * fail typed instead of waiting for a shutdown it did not start — a wait that, from a finalizer
     * of the closing scope, would never end.
     */
    exit(code: number): boolean;
    close(): import("effect/Effect").Effect<void, never, never>;
};
declare const Owner_base: Context.ServiceClass<Owner, "sewed/internal/AppRuntime", {
    registry: Registry.Registry<"app">;
    gate: {
        request(): void;
        close(): import("effect/Effect").Effect<void>;
    };
    /** What `App.decide` reads through `Registry.decide`'s `Control`, so it refuses after this closes. */
    isClosed: () => boolean;
    offer: (value: unknown) => void;
    launches: import("effect/Stream").Stream<{
        readonly kind: "initial";
        readonly arguments: readonly string[];
        readonly workingDirectory: string;
    } | {
        readonly kind: "file";
        readonly path: string;
    } | {
        readonly kind: "url";
        readonly url: string;
    }, import("../SewedError.ts").SewedError, never>;
    /**
     * Requests the application's end with `code`, calling `approveQuit` directly — never through
     * `gate`, so `Decidables.App.Quit` is never consulted — and answers whether that request is the
     * one the application will exit with. An invalid code (not an integer, or outside 0-255) is
     * refused without asking, and `approveQuit` refuses once a shutdown is already in progress,
     * whichever door began it: one exit code wins, the first. The answer is what lets `App.exit`
     * fail typed instead of waiting for a shutdown it did not start — a wait that, from a finalizer
     * of the closing scope, would never end.
     */
    exit(code: number): boolean;
    close(): import("effect/Effect").Effect<void, never, never>;
}>;
export declare class Owner extends Owner_base {
}
export {};
//# sourceMappingURL=AppRuntime.d.ts.map