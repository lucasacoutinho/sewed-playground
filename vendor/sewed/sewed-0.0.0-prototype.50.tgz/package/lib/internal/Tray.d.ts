import { Effect, Stream } from "effect";
import type { Scope } from "effect";
import type { Source as ImageSource } from "../Image.ts";
import * as Tray from "../Tray.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Balloon, Event, MenuOptions, Options } from "../Tray.ts";
export interface Handle {
    readonly id: string;
    readonly events: Stream.Stream<Tray.Event, SewedError, MainContext>;
    readonly setToolTip: (tooltip: string) => Effect.Effect<void, SewedError, MainContext>;
    /** A path or already-encoded bytes, over wave 3's `Image.Source`; `template` mirrors `Options`. */
    readonly setImage: (icon: ImageSource, options?: {
        readonly template?: boolean;
    }) => Effect.Effect<void, SewedError, MainContext>;
    readonly setMenu: (menu: Tray.MenuOptions) => Effect.Effect<void, SewedError, MainContext>;
    /** Shows a Windows balloon on the icon; `Native` elsewhere. */
    readonly displayBalloon: (balloon: Tray.Balloon) => Effect.Effect<void, SewedError, MainContext>;
    readonly removeBalloon: Effect.Effect<void, SewedError, MainContext>;
    /** Pops the tray's menu up now, on macOS and Windows; `position` applies on Windows. */
    readonly popUpMenu: (position?: {
        readonly x: number;
        readonly y: number;
    }) => Effect.Effect<void, SewedError, MainContext>;
    readonly closeMenu: Effect.Effect<void, SewedError, MainContext>;
    /** The icon's stable identifier where the platform has one, on macOS and Windows. */
    readonly guid: Effect.Effect<string | null, SewedError, MainContext>;
    /** Makes every click report at once instead of waiting to see if it is a double click, on macOS. */
    readonly setIgnoreDoubleClickEvents: (ignore: boolean) => Effect.Effect<void, SewedError, MainContext>;
    readonly ignoreDoubleClickEvents: Effect.Effect<boolean, SewedError, MainContext>;
    /** The image shown while the icon is pressed, on macOS. */
    readonly setPressedImage: (icon: ImageSource) => Effect.Effect<void, SewedError, MainContext>;
}
export declare const make: (options: Tray.Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Tray.d.ts.map