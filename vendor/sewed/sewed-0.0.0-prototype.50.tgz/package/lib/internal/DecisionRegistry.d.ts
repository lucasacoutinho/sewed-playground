import { Context, Effect, Scope } from "effect";
import * as Decision from "../Decision.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/**
 * `install`'s decider parameter is written in terms of `Event`/`Answer`/`Timing` only to be
 * *checked* against them, never to help infer them: without `NoInfer`, a decider whose own event or
 * answer type differs from the decidable's would still type-check, because a type parameter shared
 * across two parameters infers to the union of both instead of requiring them equal. Inferring
 * solely from `decidable` is what makes such a decider a type error on that decidable — a decider
 * built for a *structurally identical* decidable (same event and answer types, different key) still
 * installs freely, which is ordinary structural typing rather than a gap.
 */
type Fits<Event, Answer, Timing extends "sync" | "async"> = Decision.DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>>;
declare const fallbackIdentity: unique symbol;
/**
 * One owner's override of a decidable's own `fallback`, built by {@link fallback} and consumed only
 * by {@link make}. `WebContents.Download`'s catalog fallback is `deny`, the safe end for any owner
 * that declares nothing; a plain web contents' own registry overrides it to `prompt` at its
 * construction site, visible there rather than requiring a reader to cross-reference the decidable's
 * own declaration. See `Decidables.ts`'s doc on `Download` for why one decidable needs two postures.
 *
 * Not a `ReadonlyMap<string, unknown>`: keying by the decidable's own `key` string reopens exactly
 * the collision `entries` above was keyed by identity to close — two decidables sharing a `key` could
 * override each other's fallback — and a value erased to `unknown` would need a cast to read back
 * typed, which is the one erasure this whole module is written to avoid: nothing here ever recovers
 * a type it lost. `apply` closes over `Event`, `Answer`, and `Timing` where {@link fallback} is
 * called, with them fully in scope, so nothing downstream — `make`, `resolveSync`, `resolveAsync` —
 * ever needs one to use it.
 *
 * The brand is why: an object literal satisfies `{ apply: (overrides) => void }` structurally, so
 * without it a hand-built `{ apply: (o) => o.set(SomeDecidable, "whatever") }` would install into
 * `make`'s `fallbacks` with no cast, skipping every check `fallback` makes — an unvalidated override
 * included, and the first resolution that falls back to it would throw a decode error out of
 * `resolveSync`, inside the native callback the construction-time check exists to keep clean. Mirrors
 * `Decision.ts`'s `decidableIdentity` exactly, including why it works: `fallbackIdentity` is not
 * exported, so nothing outside this module can write the property key at all.
 */
export interface Fallback {
    readonly [fallbackIdentity]: true;
    readonly apply: (owner: Decision.OwnerKind, overrides: WeakMap<object, unknown>) => void;
}
/**
 * Declares one owner's override of `decidable`'s own fallback. Validated when the registry that
 * receives it is built (`make`, not here) — so a bad override fails at construction rather than
 * inside an Electron callback — against everything `decidable()` itself validates its own `fallback`
 * against: the answer schema, and, under restrictive composition, membership in the decidable's own
 * `order`. The second check matters for the same reason it matters in `Decision.decidable`'s own
 * fallback check: an override outside the declared order cannot rank, so a decider that fails would
 * contribute nothing instead of the fallback, and the resolution could answer less restrictively
 * than the decidable itself declares — the exact guarantee restrictive composition exists to give.
 *
 * The owner check happens there too, and for the same reason: an override for another owner's
 * decidable is data this registry can never reach, and a posture nobody applies is exactly the
 * silent kind of wrong this wave exists to end. `decidable` keeps the "any decidable" spelling —
 * `fallback` is declared long before it meets a registry, and which owner it is for is the
 * registry's question, not this one's.
 */
export declare const fallback: <Event, Answer, Timing extends "sync" | "async">(decidable: Decision.Decidable<Event, Answer, Timing>, value: NoInfer<Answer>) => Fallback;
declare const hookIdentity: unique symbol;
/** What a hook attaches and detaches: the native installer/remover pair {@link hook} wraps. */
interface NativeHook {
    readonly attach: () => void;
    readonly detach: () => void;
}
type HookMap = WeakMap<object, NativeHook>;
/**
 * One owner's declaration that a decidable has a native counterpart that should exist only while
 * the decidable has at least one decider — the certificate proc and the display-media handler are
 * the two `internal/Session.ts` declares, and a plain web contents' input gate
 * (`internal/ContentsInput.ts`) is the third; `internal/WebRequest.ts`'s own tap bookkeeping is the
 * same idea grown by hand before this existed. Built by {@link hook} and consumed only by
 * {@link make}.
 *
 * Mirrors `Fallback` exactly, including why it works: the brand makes a hook impossible to
 * *assemble* — a hand-built `{ apply: (hooks) => hooks.set(SomeDecidable, { attach, detach }) }`
 * satisfies the structural shape with no cast, which would skip the duplicate check `hook` makes.
 * `hookIdentity` is not exported, so nothing outside this module can write the property key at all.
 */
export interface Hook {
    readonly [hookIdentity]: true;
    readonly apply: (owner: Decision.OwnerKind, hooks: HookMap) => void;
}
/**
 * Declares that `decidable`'s registry should call `native.attach()` the moment its entry count
 * goes from zero to one, and `native.detach()` the moment it goes back to zero — see `installOne`'s
 * own doc for exactly when, relative to the entry list, each runs. A second hook for the same
 * decidable fails when the registry that receives both is built, the same way a bad fallback does:
 * two hooks would leave `installOne` unable to tell which one owns the transition. A hook for
 * another owner's decidable fails there too, for the reason {@link fallback}'s own owner check
 * gives: its entry count would never move, so its native counterpart would never attach.
 */
export declare const hook: <Event, Answer, Timing extends "sync" | "async">(decidable: Decision.Decidable<Event, Answer, Timing, Decision.Composition>, native: NativeHook) => Hook;
/**
 * The three resolutions, which are the only thing a helper that merely *consults* a registry needs —
 * `internal/CloseGate.ts`, `internal/ContentsInput.ts`, `internal/DisplayMedia.ts`,
 * `internal/Session.ts`'s two permission gates, and `internal/WebRequest.ts`'s three native
 * listeners.
 *
 * All three name `O` on the *decidable* they resolve, not on `owner` alone. Carrying it on `owner`
 * alone constrained which registry a consumer would accept and said nothing about which decidable it
 * would then hand that registry, so `sessionResolver.resolveSync(Decidables.WebContents.Navigation,
 * …)` compiled clean — the consult path's own version of the install-elsewhere hole `O` exists to
 * close, and the one that matters most, since every consult site is inside a native Electron
 * callback where the refusal can only be a log and a fallback. The pairing is a compile error now,
 * and `foreignSync`/`resolvable` stay as the runtime half for a caller who is not compiling against
 * these types.
 *
 * It costs no call site a type argument: each of the eleven passes a decidable whose own declared
 * owner kind fixes `O` by inference, exactly as `Event` and `Answer` are already fixed. What it does
 * cost is the `Decidable<Event, Answer, Timing>` "any owner" default here — a helper that genuinely
 * means "whoever owns it" is `Registry.fallback` and `Registry.hook`, which keep it.
 *
 * `C` is spelled out rather than left to its default only because reaching the fifth parameter
 * requires naming the fourth; each resolution keeps exactly the compositions it could already fold
 * or rank, so a chain decidable stays out of the two ranking resolutions and a ranked one out of
 * `resolveChain`.
 */
export interface Resolver<O extends Decision.OwnerKind> {
    /** The kind of owner this registry decides for; every decidable installed on it must name it. */
    readonly owner: O;
    /**
     * Resolves synchronously. Only a `"sync"`-timing decidable may be resolved this way: `install`
     * refuses an async decider on one, so every entry installed *for this same decidable* is a
     * `sync` entry — there is no async-entry branch here to fall back silently, because there is
     * nothing left for it to do.
     */
    readonly resolveSync: <Event, Answer>(decidable: Decision.Decidable<Event, Answer, "sync", "first" | "restrictive", O>, event: NoInfer<Event>) => Answer;
    /** Resolves as an Effect, running the deciders in order and awaiting each. */
    readonly resolveAsync: <Event, Answer>(decidable: Decision.Decidable<Event, Answer, "sync" | "async", "first" | "restrictive", O>, event: NoInfer<Event>) => Effect.Effect<Answer, never>;
    /**
     * Resolves a chain decidable: a fold over the installed deciders rather than a ranking of their
     * answers — see {@link chainCore}. Only a `"chain"` decidable reaches it, and `resolveAsync`
     * refuses one, so neither resolution can be asked for an outcome it has no way to produce.
     */
    readonly resolveChain: <Event, Answer>(decidable: Decision.Decidable<Event, Answer, "sync" | "async", "chain", O>, event: NoInfer<Event>) => Effect.Effect<Decision.ChainOutcome<Event, Answer>>;
}
/**
 * One owner's decision registry, tagged with the kind of owner it belongs to. `O` is what makes
 * every install door take that owner's decidables and refuse every other owner's, and it is
 * threaded from here into {@link decide}, so the `decide` an owner publishes carries the same
 * refusal — a construction site that names the wrong kind is a compile error wherever that owner's
 * handle says which kind it is.
 *
 * `owner` (declared on {@link Resolver}) is a plain property rather than a phantom, for three
 * reasons: the runtime checks read it; a covariant property is what lets `O` be *inferred* at a
 * `decide(registry, control)` call site with nothing annotated there; and it is the only thing
 * carrying `O` through to a consult-only helper, whose three resolutions name no owner at all.
 */
export interface Registry<O extends Decision.OwnerKind> extends Resolver<O> {
    readonly installOne: <Event, Answer, Timing extends "sync" | "async", R>(decidable: Decision.Decidable<Event, Answer, Timing, Decision.Composition, O>, decider: Decision.DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>, context: Context.Context<R>) => () => void;
    /**
     * Installs a decider and returns its removal. Install order is the `first` composition's order,
     * and the `chain` composition's walking order. Every composition installs through this one door,
     * which is what keeps a hook's entry-count edges true whatever a decidable composes as.
     */
    readonly install: <Event, Answer, Timing extends "sync" | "async">(decidable: Decision.Decidable<Event, Answer, Timing, Decision.Composition, O>, decider: Fits<Event, Answer, Timing>) => () => void;
}
export declare const make: <O extends Decision.OwnerKind>(options: {
    /**
     * Which owner this registry decides for. Required and never defaulted: a registry that did not
     * know its own owner could not refuse another owner's decidable, and refusing is the whole point.
     */
    readonly owner: O;
    readonly fallbacks?: readonly Fallback[];
    readonly hooks?: readonly Hook[];
}) => Registry<O>;
/** What an owner must expose for its deciders to refuse installation after it closes. */
export interface Control {
    readonly isClosed: () => boolean;
}
/**
 * Builds the `decide` an owner exposes, which is {@link Decision.Owner}'s method: a scoped install.
 * The decider starts deciding when this Effect runs and is removed when the caller's scope closes: it
 * is not consulted by any resolution that begins after that. A resolution already in flight when the
 * scope closes is unaffected — `resolveCore` snapshots its entry list at the start of each resolution,
 * so it still completes with every decider installed when it began, this one included.
 *
 * An owner that has already closed refuses with `Closed` rather than registering a decider nothing
 * will consult. `isClosed` is read when this Effect runs rather than when it is built — the body is
 * deferred, the way every `Effect.gen` body is — so an owner that closes between building the
 * install and running it still refuses.
 *
 * An asynchronous decider's services are provided from the installing Effect's own context, the way
 * `internal/CloseGate.ts`'s `make` captures it, so the decider runs inside a native callback later
 * with the services its installer had. That is why the returned Effect requires the decider's `R`.
 *
 * `installOne` itself can throw now — a hook's `attach`, run when this decider is the decidable's
 * first, and a decidable belonging to another owner — so the install step is `Effect.try`, not
 * `Effect.sync`, and it re-raises a thrown `SewedError` as itself: a thrown `attach` surfaces here
 * as code `Native` and a foreign decidable as the `Protocol` `installOne` threw, both typed failures
 * this Effect already declares rather than a defect the caller never asked for the shape of.
 *
 * `O` is inferred from `registry`'s own `owner` and threaded into the returned function's decidable
 * parameter, which is what makes this the `decide` of {@link Decision.Owner}`<O>` and nothing
 * wider. Every owner's handle publishes the result of one of these calls, so the owner kind its
 * registry was built with is the owner kind its `decide` accepts — a construction site that names
 * the wrong one is a compile error against that handle's own contract assertions.
 */
export declare const decide: <O extends Decision.OwnerKind>(registry: Registry<O>, control: Control) => <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: Decision.Decidable<Event, Answer, Timing, Decision.Composition, O>, decider: Decision.DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => Effect.Effect<void, SewedError, MainContext | Scope.Scope | R>;
export {};
//# sourceMappingURL=DecisionRegistry.d.ts.map