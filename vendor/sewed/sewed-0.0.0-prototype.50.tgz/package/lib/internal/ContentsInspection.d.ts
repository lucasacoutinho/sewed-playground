import type { WebContents as NativeContents } from "electron";
import { Effect } from "effect";
import { FrameAddress, UdpPortRange, WebRtcIpHandlingPolicy, ZoomLevel, ZoomMode } from "../WebContents.ts";
import type { Control } from "./WebContentsCore.ts";
/**
 * What a web contents can tell about itself beyond its page: its frames, its workers and
 * printers, its WebRTC network settings, and the folders DevTools may edit. Reads copy plain data
 * out of Electron's objects; none is handed over.
 */
export declare const make: (native: NativeContents, control: Pick<Control, "operation" | "asynchronous">) => {
    /** Every frame of the page right now, the main frame first. */
    frameTree: Effect.Effect<readonly {
        readonly processId: number;
        readonly routingId: number;
        readonly frameTreeNodeId: number;
        readonly token: string;
        readonly osProcessId: number;
        readonly isMainFrame: boolean;
        readonly parent: number | null;
        readonly top: number | null;
        readonly detached: boolean;
        readonly url: string;
        readonly origin: string;
        readonly name: string;
        readonly visibilityState: string;
    }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** The frame that opened this page with `window.open`, while it still exists. */
    opener: Effect.Effect<{
        readonly processId: number;
        readonly routingId: number;
        readonly frameTreeNodeId: number;
        readonly token: string;
        readonly osProcessId: number;
        readonly isMainFrame: boolean;
        readonly parent: number | null;
        readonly top: number | null;
        readonly detached: boolean;
        readonly url: string;
        readonly origin: string;
        readonly name: string;
        readonly visibilityState: string;
    } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** The frame that has keyboard focus inside the page. */
    focusedFrame: Effect.Effect<{
        readonly processId: number;
        readonly routingId: number;
        readonly frameTreeNodeId: number;
        readonly token: string;
        readonly osProcessId: number;
        readonly isMainFrame: boolean;
        readonly parent: number | null;
        readonly top: number | null;
        readonly detached: boolean;
        readonly url: string;
        readonly origin: string;
        readonly name: string;
        readonly visibilityState: string;
    } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** The Sewed id of the owner of the web contents hosting this one, for a hosted page. */
    hostId: Effect.Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** The native id of the web contents DevTools is shown in, while it is open. */
    devToolsContentsId: Effect.Effect<number | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /**
     * The JavaScript call stack of the main frame, for a page that stopped responding; `null`
     * when Chromium has none to give. Electron marks this experimental.
     */
    collectJavaScriptCallStack: Effect.Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /**
     * One frame of this page, named as `frameTree` names it, for what can be asked of a single
     * frame. Each operation finds the frame again and fails `Protocol` once the page no longer has
     * it; a frame of another page is never reached from here.
     */
    frame: (identity: FrameAddress) => {
        info: Effect.Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly top: number | null;
            readonly detached: boolean;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        /** Reloads the frame alone; `Native` when Chromium refuses. */
        reload: Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        collectJavaScriptCallStack: Effect.Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    };
    /** The zoom as Chromium's level, beside the factor the `zoom` stream carries. */
    zoomLevel: Effect.Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    setZoomLevel: (level: ZoomLevel) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    zoomMode: Effect.Effect<"default" | "disabled" | "isolated" | "manual", import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    setZoomMode: (mode: ZoomMode) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Chromium's own id for the page's renderer process; `state` carries the operating system's. */
    rendererProcessId: Effect.Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    sharedWorkers: Effect.Effect<readonly {
        readonly id: string;
        readonly url: string;
    }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Opens DevTools for one shared worker, by the id `sharedWorkers` reports. */
    inspectSharedWorker: (id: string) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** The id a remote DevTools client names this page by. */
    devToolsTargetId: Effect.Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Lets DevTools read and edit a folder on disk, by absolute path. */
    addDevToolsWorkspace: (path: string) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    removeDevToolsWorkspace: (path: string) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    printers: Effect.Effect<readonly {
        readonly name: string;
        readonly displayName: string;
        readonly description: string;
    }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    webRtc: Effect.Effect<{
        readonly ipHandlingPolicy: string;
        readonly udpPortRange: {
            readonly min: number;
            readonly max: number;
        };
    }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Which network interfaces WebRTC may reveal. */
    setWebRtcIpHandlingPolicy: (policy: WebRtcIpHandlingPolicy) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    setWebRtcUdpPortRange: (range: UdpPortRange) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Whether the page is navigated with a text caret, as F7 toggles in a browser. */
    caretBrowsing: Effect.Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
    setCaretBrowsing: (enabled: boolean) => Effect.Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
};
//# sourceMappingURL=ContentsInspection.d.ts.map