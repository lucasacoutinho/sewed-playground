import { Effect } from "effect";
import { SewedError } from "../SewedError.ts";
export declare const validate: (expected: readonly string[], actual: readonly string[], message: string) => Effect.Effect<void, SewedError>;
//# sourceMappingURL=BindingContract.d.ts.map