import type { Event } from "../Diagnostics.ts";
import type { Bridge } from "./Bridge.ts";
/** Only observations cross the renderer boundary; owner state comes from main. */
export declare const forward: (bridge: Bridge, session: string) => {
    tracing: boolean;
    emit(event: Event): void;
    close(): void;
};
//# sourceMappingURL=RendererDiagnostics.d.ts.map