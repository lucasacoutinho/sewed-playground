import { Stream } from "effect";
import { SewedError } from "../SewedError.ts";
export interface LaunchQueue<A> {
    /** Decodes and enqueues one native launch; a bad or oversized one fails the consumer instead. */
    readonly offer: (value: unknown) => void;
    /** The launches, in order, to exactly one draining consumer at a time. */
    readonly launches: Stream.Stream<A, SewedError>;
    /** Ends the queue: buffered launches still drain, and a later consumer fails `Closed`. */
    readonly end: () => void;
}
/**
 * One ordered, bounded queue of launch requests. Two owners share it: the application's own
 * launches (`internal/AppRuntime.ts`: initial, file, url) and a claimed instance's second-instance
 * launches (`internal/Instance.ts`). Launches offered before a consumer exists are retained, so a
 * launch that arrives before the program subscribes is not lost; the capacity is 128 and a launch
 * is at most 256 KiB, and overflow of either fails the consumer with `Limit` after what was
 * buffered drains. There is exactly one draining consumer; a second fails `Limit`.
 */
export declare const make: <A>(what: string, decode: (value: unknown) => A) => LaunchQueue<A>;
//# sourceMappingURL=LaunchQueue.d.ts.map