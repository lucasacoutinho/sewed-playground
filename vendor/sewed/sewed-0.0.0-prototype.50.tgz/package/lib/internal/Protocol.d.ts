import { Effect, Scope } from "effect";
import type { Handle as SessionHandle } from "./Session.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as Protocol from "../Protocol.ts";
export { Privileges, scheme, definition } from "../Protocol.ts";
export type { Handler, Request, Response, Scheme, SchemeDefinition, WebHandler, } from "../Protocol.ts";
export declare const protocolError: (message: string, cause?: unknown) => SewedError;
/** Validates a scheme's own declared shape; `ProtocolSchemes.ts`'s `registerSchemes` shares it. */
export declare const validateScheme: (value: Protocol.Scheme) => Protocol.SchemeDefinition;
export declare const handleWeb: (session: SessionHandle, value: Protocol.Scheme, handler: Protocol.WebHandler) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
export declare const handle: <E, R>(session: SessionHandle, value: Protocol.Scheme, handler: Protocol.Handler<E, R>) => Effect.Effect<void, SewedError, MainContext | R | Scope.Scope>;
//# sourceMappingURL=Protocol.d.ts.map