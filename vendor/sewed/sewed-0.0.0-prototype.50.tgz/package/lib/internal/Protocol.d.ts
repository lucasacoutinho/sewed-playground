import { Effect, Scope } from "effect";
import type { Handle as SessionHandle } from "./Session.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as Protocol from "../Protocol.ts";
export { Privileges, scheme, definition } from "../Protocol.ts";
export type { Handler, Request, Response, Scheme, SchemeDefinition, WebHandler, } from "../Protocol.ts";
export declare const protocolError: (message: string, cause?: unknown) => SewedError;
/** Validates a scheme's own declared shape; `ProtocolSchemes.ts`'s `registerSchemes` shares it. */
export declare const validateScheme: (value: Protocol.Scheme) => Protocol.SchemeDefinition;
export declare const handleWeb: (session: SessionHandle, value: Protocol.Scheme, handler: Protocol.WebHandler) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
export declare const handle: <E, R>(session: SessionHandle, value: Protocol.Scheme, handler: Protocol.Handler<E, R>) => Effect.Effect<void, SewedError, MainContext | R | Scope.Scope>;
/**
 * Serves a scheme from directories on disk with no handler: Chromium streams the files itself,
 * so no request waits on the main process. A route with a `host` wins over one without, then the
 * longest `path` prefix; a path outside its route's `root`, a missing file, and any method but
 * `GET` and `HEAD` fail as a missing file. Scoped: closing the scope stops serving. A scheme has
 * a handler or routes, not both. Electron marks this experimental.
 */
export declare const serveFiles: (session: SessionHandle, value: Protocol.Scheme, routes: ReadonlyArray<Protocol.Route>) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Protocol.d.ts.map