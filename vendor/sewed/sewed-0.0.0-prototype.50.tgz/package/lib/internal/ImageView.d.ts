import { Effect } from "effect";
import type { Scope } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import { type Attachable } from "./View.ts";
export interface Options {
    /** A file path or encoded image bytes such as PNG; either must decode to a non-empty image. */
    readonly image?: string | Uint8Array;
}
/** A view that displays one image; attach it to a window or container view. */
export interface Handle extends Attachable {
    readonly setImage: (image: string | Uint8Array) => Effect.Effect<void, SewedError, MainContext>;
    readonly close: Effect.Effect<void, never, MainContext>;
    readonly awaitClosed: Effect.Effect<void, never, MainContext>;
}
export declare const make: (options?: Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=ImageView.d.ts.map