import { Effect } from "effect";
import * as DesktopCapturer from "../DesktopCapturer.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Decision, Options, Request, Source, SourceType } from "../DesktopCapturer.ts";
/** Lists capturable screens and windows with PNG thumbnails; screen capture itself stays a session policy. */
export declare const sources: (options: DesktopCapturer.Options) => Effect.Effect<readonly DesktopCapturer.Source[], SewedError, MainContext>;
//# sourceMappingURL=DesktopCapturer.d.ts.map