import type { Layer } from "effect";
import type { Rpc, RpcGroup } from "effect/rpc";
import type { HandlerServices } from "../Runtime.ts";
export type HandlerLayer<Rpcs extends Rpc.Any, E, R> = Layer.Layer<NoInfer<HandlerServices<Rpcs>>, E, R> | ((implement: NoInfer<RpcGroup.RpcGroup<Rpcs>["toLayer"]>) => Layer.Layer<NoInfer<HandlerServices<Rpcs>>, E, R>);
export declare const handlerLayer: <Rpcs extends Rpc.Any, E, R>(protocol: RpcGroup.RpcGroup<Rpcs>, handlers: HandlerLayer<Rpcs, E, R>) => Layer.Layer<HandlerServices<Rpcs>, E, R>;
//# sourceMappingURL=HandlerLayer.d.ts.map