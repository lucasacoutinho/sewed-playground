import { Effect } from "effect";
import type { Scope } from "effect";
import * as PowerSaveBlocker from "../PowerSaveBlocker.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Kind } from "../PowerSaveBlocker.ts";
export interface Handle {
    readonly kind: PowerSaveBlocker.Kind;
    /** Whether Electron still holds the block; false once the scope released it. */
    readonly active: Effect.Effect<boolean, SewedError, MainContext>;
}
/** Holds a power save block for the scope's lifetime; closing the scope releases it. */
export declare const hold: (kind: PowerSaveBlocker.Kind) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=PowerSaveBlocker.d.ts.map