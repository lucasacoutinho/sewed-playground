import { Context, Effect } from "effect";
import type { Event } from "../Diagnostics.ts";
declare const Sink_base: Context.ServiceClass<Sink, "sewed/Diagnostics", {
    readonly emit: (event: Event) => void;
    readonly tracing?: boolean;
}>;
export declare class Sink extends Sink_base {
}
export declare const sink: Effect.Effect<{
    readonly emit: (event: Event) => void;
    readonly tracing?: boolean;
} | undefined, never, never>;
declare const OwnerContext_base: Context.ServiceClass<OwnerContext, "sewed/DiagnosticOwner", {
    readonly id: string;
}>;
export declare class OwnerContext extends OwnerContext_base {
}
export declare const location: Effect.Effect<{
    readonly runtime: "utility";
    readonly threadId: 0;
    readonly processId: number;
    readonly runtimeId: string;
} | {
    readonly processId?: never;
    readonly runtime: "worker";
    readonly threadId: number;
    readonly runtimeId: string;
} | {
    readonly processId?: never;
    readonly runtime: "renderer";
    readonly threadId: 0;
    readonly runtimeId: string;
} | {
    readonly processId?: never;
    readonly runtime: "main";
    readonly threadId: 0;
    readonly runtimeId: "main";
} | {
    readonly processId?: never;
    readonly runtime: "unknown";
    readonly threadId: 0;
    readonly runtimeId: "unknown";
}, never, never>;
export {};
//# sourceMappingURL=Diagnostics.d.ts.map