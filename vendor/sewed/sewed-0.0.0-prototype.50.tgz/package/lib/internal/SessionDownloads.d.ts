import { Effect } from "effect";
import * as Download from "../Download.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import { type AdoptableItem } from "./DownloadItem.ts";
import type { Handle } from "./Session.ts";
type Listener = (event: unknown, item: AdoptableItem, contents: unknown) => void;
/** The structural subset of a session a resumed download needs. */
interface Resumable {
    on(event: "will-download", listener: Listener): unknown;
    off(event: "will-download", listener: Listener): unknown;
    createInterruptedDownload(options: Electron.CreateInterruptedDownloadOptions): void;
}
/**
 * Continues a download interrupted in an earlier run. Electron recreates it interrupted and
 * announces it like any other download, with no web contents behind it; this adopts the one saved
 * at `path` and answers its handle, on which `resume` continues the transfer. No download decider
 * is asked: the application named the file itself.
 */
export declare const resume: (session: Resumable, options: Download.Resume) => Effect.Effect<Download.Handle, SewedError, MainContext>;
export declare const resumeDownload: (handle: Handle, options: Download.Resume) => Effect.Effect<Download.Handle, SewedError, MainContext>;
export {};
//# sourceMappingURL=SessionDownloads.d.ts.map