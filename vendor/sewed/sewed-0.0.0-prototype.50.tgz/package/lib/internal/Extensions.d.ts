import { Effect } from "effect";
import type { Scope } from "effect";
import * as Extension from "../Extension.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle } from "./Session.ts";
/**
 * Loads an unpacked extension for the scope's lifetime; closing the scope unloads it. Electron
 * only accepts extensions in persistent sessions.
 */
export declare const loadExtension: (handle: Handle, directory: string, options?: Extension.Options) => Effect.Effect<Extension.Info, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Extensions.d.ts.map