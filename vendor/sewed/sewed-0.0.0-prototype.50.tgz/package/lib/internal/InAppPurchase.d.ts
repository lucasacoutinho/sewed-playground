import { Effect } from "effect";
import type { Stream } from "effect";
import * as InAppPurchase from "../InAppPurchase.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Product, Quantity, Transaction, TransactionState } from "../InAppPurchase.ts";
export declare const canMakePayments: Effect.Effect<boolean, SewedError, MainContext>;
export declare const products: (ids: readonly string[]) => Effect.Effect<readonly InAppPurchase.Product[], SewedError, MainContext>;
export declare const purchase: (id: string, quantity?: number) => Effect.Effect<boolean, SewedError, MainContext>;
export declare const finishAll: Effect.Effect<void, SewedError, MainContext>;
export declare const finish: (date: string) => Effect.Effect<void, SewedError, MainContext>;
export declare const restore: Effect.Effect<void, SewedError, MainContext>;
export declare const receiptUrl: Effect.Effect<string, SewedError, MainContext>;
export declare const transactions: Stream.Stream<readonly InAppPurchase.Transaction[], SewedError, MainContext>;
//# sourceMappingURL=InAppPurchase.d.ts.map