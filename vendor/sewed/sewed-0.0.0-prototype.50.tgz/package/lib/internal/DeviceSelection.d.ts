import type { Session } from "electron";
import type * as Device from "../Device.ts";
import * as Registry from "./DecisionRegistry.ts";
export declare const hid: (device: Electron.HIDDevice) => Device.Hid;
export declare const usb: (device: Electron.USBDevice) => Device.Usb;
export declare const serialPort: (port: Electron.SerialPort) => Device.SerialPort;
/** What a pairing answer means to Electron; an answer of the wrong kind for its prompt cancels. */
export declare const pairingResponse: (kind: Device.Pairing["kind"], answer: Device.PairingAnswer) => Electron.Response;
/**
 * The native side of a session's chooser decidables and its restricted-path prompt: each listener
 * and the pairing handler exists only while its decidable has a decider, so a session nobody asked to choose devices for keeps
 * Electron's own behaviour, which is to cancel. `registry` is read when an event arrives, not when
 * the hooks are built, because the registry is built from them.
 */
export declare const hooks: (session: Session, registry: () => Registry.Resolver<"session">) => ReadonlyArray<Registry.Hook>;
//# sourceMappingURL=DeviceSelection.d.ts.map