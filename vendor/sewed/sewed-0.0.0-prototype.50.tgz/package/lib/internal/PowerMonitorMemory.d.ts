import { Layer } from "effect";
import * as PowerMonitor from "../PowerMonitor.ts";
import type { SewedError } from "../SewedError.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
/**
 * The power capability for tests: the same threshold check `PowerMonitor.native` carries, no
 * Electron, and a recorder listing the calls.
 */
export declare const memory: () => Layer.Layer<typeof PowerMonitor.capability | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=PowerMonitorMemory.d.ts.map