import { Effect, Schema } from "effect";
import type { Scope, Stream } from "effect";
import { SecondInstance } from "../Launch.ts";
import { SewedError } from "../SewedError.ts";
declare const SecondaryInstance_base: Schema.Class<SecondaryInstance, Schema.TaggedStruct<"SecondaryInstance", {}>, import("effect/Cause").YieldableError>;
/**
 * Another process already holds the single-instance lock. Electron forwarded this process's
 * arguments, working directory and claim data to it inside the lock request, so nothing is lost;
 * what remains is for the program to decide how this process exits.
 */
export declare class SecondaryInstance extends SecondaryInstance_base {
    get message(): string;
}
export interface Options {
    /** A JSON object forwarded to the primary process when this one turns out to be secondary. */
    readonly data?: Schema.JsonObject;
}
/** The claimed single instance: the launches of later processes, for as long as the claim's scope lives. */
export interface Instance {
    readonly launches: Stream.Stream<SecondInstance, SewedError>;
}
type Listener = (event: unknown, argv: string[], workingDirectory: string, additionalData: unknown) => void;
/** The slice of Electron's `app` a claim uses; `App.ts` hands this module the real one. */
export interface Native {
    requestSingleInstanceLock(data?: Record<string, unknown>): boolean;
    releaseSingleInstanceLock(): void;
    on(event: "second-instance", listener: Listener): unknown;
    off(event: "second-instance", listener: Listener): unknown;
}
/**
 * The single-instance claim over one native `app`. One claim may be held at a time; a second
 * fails `Limit` rather than asking Electron, which would answer `true` to the holder and leave two
 * scopes believing they own one lock.
 */
export declare const make: (native: Native) => {
    claim: (options?: Options) => Effect.Effect<Instance, SewedError | SecondaryInstance, Scope.Scope>;
};
export {};
//# sourceMappingURL=Instance.d.ts.map