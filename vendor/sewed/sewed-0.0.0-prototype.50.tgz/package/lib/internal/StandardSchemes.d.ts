export declare const register: (schemes: Iterable<string>) => void;
export declare const has: (name: string) => boolean;
//# sourceMappingURL=StandardSchemes.d.ts.map