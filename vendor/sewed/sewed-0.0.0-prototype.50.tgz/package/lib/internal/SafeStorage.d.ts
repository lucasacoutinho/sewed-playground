import { Effect, Redacted } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import * as SafeStorage from "../SafeStorage.ts";
import { SewedError } from "../SewedError.ts";
export { Availability, Sealed } from "../SafeStorage.ts";
/** Linux only: lets the in-memory `basic_text` backend serve encryption when no OS keyring exists; a no-op elsewhere. */
export declare const allowPlainText: Effect.Effect<void, SewedError, MainContext>;
export declare const availability: Effect.Effect<SafeStorage.Availability, SewedError, MainContext>;
/** Encrypts with the OS keystore; the plaintext never leaves its `Redacted` wrapper except here. */
export declare const encrypt: (value: Redacted.Redacted<string>) => Effect.Effect<SafeStorage.Sealed, SewedError, MainContext>;
export declare const decrypt: (sealed: SafeStorage.Sealed) => Effect.Effect<Redacted.Redacted<string>, SewedError, MainContext>;
/**
 * Whether the asynchronous operations can encrypt. They reach the operating system's keystore
 * without blocking the main process, which the synchronous ones do while a keychain prompt is up.
 */
export declare const asyncAvailable: Effect.Effect<boolean, SewedError, MainContext>;
/** `encrypt` without blocking the main process. */
export declare const encryptAsync: (value: Redacted.Redacted<string>) => Effect.Effect<SafeStorage.Sealed, SewedError, MainContext>;
/**
 * `decrypt` without blocking the main process. `shouldReEncrypt` says the keystore's key has
 * rotated and the value should be sealed again.
 */
export declare const decryptAsync: (sealed: SafeStorage.Sealed) => Effect.Effect<{
    readonly value: Redacted.Redacted<string>;
    readonly shouldReEncrypt: boolean;
}, SewedError, MainContext>;
//# sourceMappingURL=SafeStorage.d.ts.map