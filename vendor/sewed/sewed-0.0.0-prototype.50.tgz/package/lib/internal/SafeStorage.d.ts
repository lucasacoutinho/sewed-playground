import { Effect, Redacted } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import * as SafeStorage from "../SafeStorage.ts";
import { SewedError } from "../SewedError.ts";
export { Availability, Sealed } from "../SafeStorage.ts";
/** Linux only: lets the in-memory `basic_text` backend serve encryption when no OS keyring exists; a no-op elsewhere. */
export declare const allowPlainText: Effect.Effect<void, SewedError, MainContext>;
export declare const availability: Effect.Effect<SafeStorage.Availability, SewedError, MainContext>;
/** Encrypts with the OS keystore; the plaintext never leaves its `Redacted` wrapper except here. */
export declare const encrypt: (value: Redacted.Redacted<string>) => Effect.Effect<SafeStorage.Sealed, SewedError, MainContext>;
export declare const decrypt: (sealed: SafeStorage.Sealed) => Effect.Effect<Redacted.Redacted<string>, SewedError, MainContext>;
//# sourceMappingURL=SafeStorage.d.ts.map