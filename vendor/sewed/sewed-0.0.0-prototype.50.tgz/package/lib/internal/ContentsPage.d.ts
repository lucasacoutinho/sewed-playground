import type { WebContents as NativeContents } from "electron";
import { Effect, Stream } from "effect";
import { Drag, DeviceEmulation, EditCommand, ImageAnimationPolicy, PagePoint, SelectionAdjustment, VisualZoomLimits } from "../WebContents.ts";
import type { Source as ImageSource } from "../Image.ts";
import { SewedError } from "../SewedError.ts";
import type { Control } from "./WebContentsCore.ts";
/**
 * Page events, DevTools state, emulation and editing commands: the members of a web contents that
 * neither load nor decide anything. Kept apart from `WebContentsCore.ts`, which owns navigation
 * state and the decision gates.
 */
export declare const make: (native: NativeContents, control: Pick<Control, "closed" | "operation" | "asynchronous">, imageOf: (source: ImageSource, label: string) => Electron.NativeImage) => {
    /**
     * What the page does that main may react to: context-menu requests, cursor and link-target
     * changes, the theme color, HTML fullscreen, DOM readiness, preload failures, frames coming
     * and going, and DevTools opening, closing and taking focus.
     */
    events: Stream.Stream<{
        readonly kind: "context-menu";
        readonly x: number;
        readonly y: number;
        readonly pageUrl: string;
        readonly frameUrl: string;
        readonly linkUrl: string;
        readonly linkText: string;
        readonly sourceUrl: string;
        readonly mediaType: string;
        readonly hasImageContents: boolean;
        readonly isEditable: boolean;
        readonly selectionText: string;
        readonly misspelledWord: string;
        readonly dictionarySuggestions: readonly string[];
        readonly source: string;
        readonly editFlags: {
            readonly canUndo: boolean;
            readonly canRedo: boolean;
            readonly canCut: boolean;
            readonly canCopy: boolean;
            readonly canPaste: boolean;
            readonly canDelete: boolean;
            readonly canSelectAll: boolean;
        };
    } | {
        readonly kind: "cursor";
        readonly type: string;
    } | {
        readonly kind: "target-url";
        readonly url: string;
    } | {
        readonly kind: "theme-color";
        readonly color: string | null;
    } | {
        readonly kind: "html-full-screen";
        readonly active: boolean;
    } | {
        readonly kind: "dom-ready";
    } | {
        readonly kind: "preload-error";
        readonly path: string;
        readonly message: string;
    } | {
        readonly kind: "frame";
        readonly change: "created" | "loaded" | "navigated";
        readonly frame: {
            readonly processId: number;
            readonly routingId: number;
            readonly isMainFrame: boolean;
        };
        readonly url?: string;
        readonly httpStatus?: number;
    } | {
        readonly kind: "devtools";
        readonly change: "closed" | "focused" | "opened";
    } | {
        readonly kind: "devtools-open-url";
        readonly url: string;
    } | {
        readonly kind: "devtools-reload-page";
    } | {
        readonly kind: "devtools-search-query";
        readonly query: string;
    } | {
        readonly kind: "content-bounds-updated";
        readonly bounds: {
            readonly x: number;
            readonly y: number;
            readonly width: number;
            readonly height: number;
        };
    } | {
        readonly kind: "preferred-size";
        readonly width: number;
        readonly height: number;
    } | {
        readonly kind: "input";
        readonly type: string;
    } | {
        readonly kind: "frame-will-navigate";
        readonly url: string;
        readonly isMainFrame: boolean;
        readonly isSameDocument: boolean;
    }, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** What the page is doing right now. */
    activity: Effect.Effect<{
        readonly loading: boolean;
        readonly waitingForResponse: boolean;
        readonly crashed: boolean;
        readonly beingCaptured: boolean;
        readonly backgroundThrottling: boolean;
    }, SewedError, import("../RuntimeContext.ts").MainContext>;
    devTools: Effect.Effect<{
        readonly opened: boolean;
        readonly focused: boolean;
        readonly title: string;
    }, SewedError, import("../RuntimeContext.ts").MainContext>;
    toggleDevTools: Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    setDevToolsTitle: (title: string) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Opens DevTools on the element at a point in the page. */
    inspectElement: (point: PagePoint) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Opens DevTools for the page's service worker or shared worker. */
    inspectWorker: (kind: "service" | "shared") => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    enableDeviceEmulation: (parameters: DeviceEmulation) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    disableDeviceEmulation: Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Runs an editing command in the focused frame. */
    edit: (command: EditCommand) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Replaces the selection with `text`. */
    replace: (text: string) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Replaces the misspelled word under the caret, as a spelling suggestion does. */
    replaceMisspelling: (text: string) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    adjustSelection: (adjustment: SelectionAdjustment) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Copies the video frame at a point in the page to the clipboard. */
    copyVideoFrameAt: (point: PagePoint) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Opens the system's save dialog for the video frame at a point in the page. */
    saveVideoFrameAs: (point: PagePoint) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Copies the image at a point in the page to the clipboard. */
    copyImageAt: (point: PagePoint) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    setVisualZoomLimits: (limits: VisualZoomLimits) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    setImageAnimationPolicy: (policy: ImageAnimationPolicy) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /**
     * Starts an operating system drag of files out of the page, with `icon` under the pointer.
     * Call it while the page handles `dragstart`, having cancelled the page's own drag.
     */
    startDrag: (drag: Drag) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Shows the dictionary popover for the selected word, on macOS. */
    showDefinitionForSelection: Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
    /** Writes a V8 heap snapshot of the page to an absolute path. */
    takeHeapSnapshot: (path: string) => Effect.Effect<void, SewedError, import("../RuntimeContext.ts").MainContext>;
};
//# sourceMappingURL=ContentsPage.d.ts.map