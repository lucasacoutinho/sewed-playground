import { Effect, Schema } from "effect";
import type { Scope, Stream } from "effect";
import * as Application from "../Application.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/** Recently opened documents, in the macOS Dock menu and the Windows jump list. */
export declare const recentDocuments: {
    add: (path: string) => Effect.Effect<void, SewedError, MainContext>;
    clear: Effect.Effect<void, SewedError, MainContext>;
    list: Effect.Effect<string[], SewedError, MainContext>;
};
/** Chromium's accessibility tree, which assistive technology turns on by itself. */
export declare const accessibility: {
    enabled: Effect.Effect<boolean, SewedError, MainContext>;
    setEnabled: (enabled: boolean) => Effect.Effect<void, SewedError, MainContext>;
    /** Which parts of the accessibility tree are built, such as `nativeAPIs` and `webContents`. */
    features: Effect.Effect<string[], SewedError, MainContext>;
    setFeatures: (features: ReadonlyArray<string>) => Effect.Effect<void, SewedError, MainContext>;
    changes: Stream.Stream<boolean, SewedError, MainContext>;
};
/** Handoff, on macOS: what the user is doing here, offered to their other devices. */
export declare const activity: {
    current: Effect.Effect<string, SewedError, MainContext>;
    set: (value: Application.Activity) => Effect.Effect<void, SewedError, MainContext>;
    /** Replaces the current activity's state when its type matches. */
    update: (value: Application.Activity) => Effect.Effect<void, SewedError, MainContext>;
    invalidate: Effect.Effect<void, SewedError, MainContext>;
    /** Stops offering the current activity without ending it. */
    resign: Effect.Effect<void, SewedError, MainContext>;
    /**
     * Activities arriving from another device and the state of this one's. Observing claims each
     * `continue` and `update-state`: their defaults are prevented, which tells macOS the application
     * handles them.
     */
    events: Stream.Stream<{
        readonly kind: "will-continue";
        readonly type: string;
    } | {
        readonly kind: "continue" | "update-state" | "was-continued";
        readonly type: string;
        readonly userInfo: Schema.Json;
        readonly webpageUrl?: string;
    } | {
        readonly kind: "continue-error";
        readonly type: string;
        readonly error: string;
    }, SewedError, MainContext>;
};
/** Whether the application is the active one, on macOS. */
export declare const active: Effect.Effect<boolean, SewedError, MainContext>;
/** Whether the application is hidden, on macOS. */
export declare const hidden: Effect.Effect<boolean, SewedError, MainContext>;
/** Emits `true` when the application becomes the active one and `false` when it stops, on macOS. */
export declare const activeChanges: Stream.Stream<boolean, SewedError, MainContext>;
/** Emits when the user asks for a new tab with no window to take it, on macOS. */
export declare const newWindowForTab: Stream.Stream<void, SewedError, MainContext>;
/** The macOS Applications folder. */
export declare const applicationsFolder: {
    contains: Effect.Effect<boolean, SewedError, MainContext>;
    /**
     * Moves the application there and relaunches it; answers `false` when the user declined. When
     * an application of the same name is already there, `replace` replaces it and `keep`, the
     * default, leaves both alone.
     */
    move: (conflict?: "keep" | "replace") => Effect.Effect<boolean, SewedError, MainContext>;
};
/** Whether the application shows in the Dock (`regular`), only as windows, or not at all. */
export declare const setActivationPolicy: (policy: Application.ActivationPolicy) => Effect.Effect<void, SewedError, MainContext>;
/** The CLSID Windows activates for the application's toast notifications. */
export declare const toastActivatorClsid: Effect.Effect<string, SewedError, MainContext>;
export declare const setToastActivatorClsid: (id: string) => Effect.Effect<void, SewedError, MainContext>;
/** Whether the platform has an emoji panel to show. */
export declare const emojiPanelSupported: Effect.Effect<boolean, SewedError, MainContext>;
export declare const showEmojiPanel: Effect.Effect<void, SewedError, MainContext>;
/** Whether an x64 build is running translated on ARM64, under Rosetta or Windows on ARM. */
export declare const runningUnderArm64Translation: Effect.Effect<boolean, SewedError, MainContext>;
/** What the user removed from the Windows jump list, and its minimum size. */
export declare const jumpListSettings: Effect.Effect<Application.JumpListSettings, SewedError, MainContext>;
/**
 * Lets the macOS Touch ID authenticator answer WebAuthn requests, storing credentials in a
 * keychain access group the application is entitled to.
 */
export declare const configureWebAuthn: (keychainAccessGroup: string) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Opens a file outside the sandbox through a security-scoped bookmark a dialog returned, for the
 * scope's lifetime, in a Mac App Store build.
 */
export declare const securityScopedResource: (bookmark: string) => Effect.Effect<void, SewedError, MainContext | Scope.Scope>;
/**
 * Sends an Objective-C action, such as `selectAll:`, to whatever has keyboard focus in the macOS
 * application, as a menu item with that action would.
 */
export declare const sendActionToFirstResponder: (action: string) => Effect.Effect<void, SewedError, MainContext>;
/**
 * Shows the system's dialog for trusting or importing a certificate, on macOS and Windows, for a
 * certificate the application was recently asked about (by a certificate or client certificate
 * decider), named by its fingerprint. It resolves when the dialog closes; whether the user
 * trusted it is theirs to know. An unknown fingerprint fails `Protocol`.
 */
export declare const showCertificateTrustDialog: (fingerprint: string, message: string) => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=AppPlatform.d.ts.map