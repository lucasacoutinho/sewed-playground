export declare const remember: (certificate: Electron.Certificate) => void;
export declare const find: (fingerprint: string) => Electron.Certificate | undefined;
//# sourceMappingURL=SeenCertificates.d.ts.map