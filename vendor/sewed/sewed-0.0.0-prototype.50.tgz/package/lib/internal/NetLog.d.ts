import { Effect } from "effect";
import type { Scope } from "effect";
import * as NetLog from "../NetLog.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { CaptureMode, Options } from "../NetLog.ts";
export interface Handle {
    readonly path: string;
    /** Whether Electron is still writing; false once the scope stopped the log. */
    readonly active: Effect.Effect<boolean, SewedError, MainContext>;
}
/**
 * Records Chromium's network log to an absolute path for the scope's lifetime. Electron keeps
 * one log at a time, so a second recording fails with `Limit` until the first scope closes.
 */
export declare const record: (file: string, options?: NetLog.Options) => Effect.Effect<Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=NetLog.d.ts.map