import type { WebContents as NativeContents } from "electron";
import { Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import { FrameOptions, FrameRate } from "../WebContents.ts";
import type { Frame } from "../WebContents.ts";
import type { Control } from "./WebContentsCore.ts";
/**
 * A page's rendered frames. An offscreen page reports each paint; any other page is subscribed to
 * through Electron's single frame subscription, which this module shares between observers and
 * ends with the last one.
 *
 * Frames are large and arrive at the display's rate, so each observer keeps only the newest two:
 * a consumer slower than the page skips frames instead of failing with `Limit` as the event
 * streams do.
 */
export declare const make: (native: NativeContents, control: Pick<Control, "closed" | "isClosed" | "closedError" | "operation">) => {
    frames: (options?: FrameOptions) => Stream.Stream<Frame, SewedError, MainContext>;
    /** Whether the page renders offscreen, whether it is painting, and at what rate. */
    painting: Effect.Effect<{
        readonly offscreen: boolean;
        readonly painting: boolean;
        readonly frameRate: number;
    }, SewedError, MainContext>;
    /** Starts or stops an offscreen page's painting. */
    setPainting: (painting: boolean) => Effect.Effect<void, SewedError, MainContext>;
    setFrameRate: (rate: FrameRate) => Effect.Effect<void, SewedError, MainContext>;
    /** Makes an offscreen page paint a whole new frame. */
    invalidate: Effect.Effect<void, SewedError, MainContext>;
};
//# sourceMappingURL=ContentsFrames.d.ts.map