import { RpcSerialization } from "effect/rpc";
/**
 * A packet that parsed as one MessagePack value but is not the one encoding of any value this
 * wire accepts. `parsed` is what the ordinary decode made of it: a peer's word, not a value to
 * use, kept so a transport can read which request the packet names and fail that request alone.
 */
export declare class Noncanonical extends TypeError {
    readonly parsed: unknown;
    constructor(parsed: unknown, options?: ErrorOptions);
}
export declare const codecFor: RpcSerialization.CodecFor;
/** The extension type code, one msgpackr does not use for its own extensions. */
export declare const utf16Type = 117;
/**
 * The encoded size past which a message leaves the packer's shared arena instead of being copied
 * out of it. The arena is module state in msgpackr, shared by every `Packr`, and it only grows: it
 * is dropped at 1 GiB and no sooner, so one 12 MiB message would otherwise leave the process
 * holding a 48 MiB arena for the rest of its life.
 */
export declare const largeBytes: number;
export declare const encodeBinary: (message: unknown) => Uint8Array;
export declare const sizeOfBinary: (message: unknown) => number;
/** MessagePack fixarray, array16 and array32 length prefixes. */
export declare const arrayHeaderBytes: (length: number) => number;
/** The byte length of the packer's shared arena, for a test that checks it stays ordinary. */
export declare const arenaBytes: () => number;
export declare const decodeBinary: (bytes: Uint8Array) => unknown;
//# sourceMappingURL=BinaryWire.d.ts.map