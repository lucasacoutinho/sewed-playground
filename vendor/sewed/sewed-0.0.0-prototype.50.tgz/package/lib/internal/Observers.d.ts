import { Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
/**
 * A set of independent bounded observers over one event source: each subscriber owns a queue of
 * 128 values and fails with `Limit` on overflow, and `finish` ends every subscriber at once. With
 * `replayLatest`, a new subscriber first receives the most recent value.
 */
export declare const make: <A>(what: string, options?: {
    readonly replayLatest?: boolean;
}) => {
    publish(value: A): void;
    finish(): void;
    readonly finished: boolean;
    stream: Stream.Stream<A, SewedError, MainContext>;
};
//# sourceMappingURL=Observers.d.ts.map