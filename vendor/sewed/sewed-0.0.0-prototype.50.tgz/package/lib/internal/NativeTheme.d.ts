import { Effect, Layer, Stream } from "effect";
import * as NativeTheme from "../NativeTheme.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Source, State, capability, protocol } from "../NativeTheme.ts";
export type { Options } from "../NativeTheme.ts";
export declare const current: Effect.Effect<NativeTheme.State, SewedError, MainContext>;
export declare const setSource: (source: NativeTheme.Source) => Effect.Effect<void, SewedError, MainContext>;
/** Replays the current theme and follows native updates; slow observers skip superseded states. */
export declare const state: Stream.Stream<NativeTheme.State, SewedError, MainContext>;
/**
 * The theme capability for main. The options live in this Layer, not in a separate host, so
 * `Capability.serve(NativeTheme.capability)` gives a document exactly the rules a main-side call
 * obeys.
 */
export declare const native: (options?: NativeTheme.Options) => Layer.Layer<typeof NativeTheme.capability, SewedError, MainContext>;
//# sourceMappingURL=NativeTheme.d.ts.map