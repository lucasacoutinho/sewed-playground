import { Effect, Stream } from "effect";
import * as Cookie from "../Cookie.ts";
import type { SewedError } from "../SewedError.ts";
/**
 * The cookie store a capability reaches once its policy has allowed the call. `native` supplies an
 * acquired session's store; a test supplies its own. `R` is whatever that implementation requires,
 * so the policy above it stays free of any runtime requirement of its own.
 */
export interface Core<R> {
    readonly get: (filter: Cookie.Filter) => Effect.Effect<readonly Cookie.Cookie[], SewedError, R>;
    readonly set: (details: Cookie.Details) => Effect.Effect<void, SewedError, R>;
    readonly remove: (url: string, name: string) => Effect.Effect<void, SewedError, R>;
    readonly flush: Effect.Effect<void, SewedError, R>;
    readonly changes: Stream.Stream<Cookie.Change, SewedError, R>;
}
/**
 * The cookie operations a capability serves, each one already behind the policy. The policy checks
 * URLs and filters the change stream without changing any signature, so this is the core's shape
 * exactly. One declaration, so the two cannot drift.
 */
export type Operations<R> = Core<R>;
/**
 * Compiles the origin policy once and returns operations that check every URL before the core
 * runs. This is the only place the cookie rules live, so the native Layer, a served renderer call,
 * and the memory Layer cannot drift apart. Reads and writes need a URL inside the policy, the
 * change stream only carries cookies whose domain belongs to a policy origin, and flushing asks
 * the policy nothing. An invalid policy fails here, while the Layer is building.
 */
export declare const operations: <R>(policy: Cookie.Policy, core: Core<R>) => Effect.Effect<Operations<R>, SewedError>;
//# sourceMappingURL=CookiePolicy.d.ts.map