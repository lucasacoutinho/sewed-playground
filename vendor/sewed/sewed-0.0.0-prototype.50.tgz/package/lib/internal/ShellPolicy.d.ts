import { Effect } from "effect";
import type { Scope } from "effect";
import * as Shell from "../Shell.ts";
import { SewedError } from "../SewedError.ts";
/** Compiles a decoded shell policy into one predicate over the URLs `openExternal` receives. */
export declare const compile: (policy: Shell.Policy) => ((url: URL) => boolean);
/**
 * The platform calls a shell capability makes once its policy has allowed them. `native` supplies
 * Electron's `shell`; a test supplies its own. `R` is whatever that implementation requires, so the
 * policy above it stays free of any runtime requirement of its own.
 */
export interface Core<R> {
    readonly openExternal: (href: string) => Effect.Effect<void, SewedError, R>;
    readonly openPath: (target: string) => Effect.Effect<Shell.OpenResult, SewedError, R>;
    readonly showItemInFolder: (target: string) => Effect.Effect<void, SewedError, R>;
    readonly trashItem: (target: string) => Effect.Effect<void, SewedError, R>;
    readonly beep: Effect.Effect<void, SewedError, R>;
}
/**
 * The shell operations a capability serves, each one already behind the policy. The policy check
 * rejects a disallowed URL or path without changing any signature, so this is the core's shape
 * exactly. One declaration, so the two cannot drift.
 */
export type Operations<R> = Core<R>;
/**
 * What {@link operations} answers: the checked operations, plus `allow`, the same function
 * `Shell.Grants["Service"]` carries. Handing both out of one call means a Layer that builds
 * `operations` once can give the served capability and the grant service the identical containment
 * state, rather than two copies of it that could drift apart.
 */
export interface Granted<R> {
    readonly operations: Operations<R>;
    /**
     * Admits one absolute path — a file, or a directory and everything under it — for the caller's
     * scope, under the same containment rule a configured root already uses. A relative path fails
     * `Protocol` before anything is admitted. Two scopes admitting the same path are counted, so
     * closing one leaves the other's grant live; the path is withdrawn only once every admitting
     * scope has closed.
     */
    readonly allow: (path: string) => Effect.Effect<void, SewedError, Scope.Scope>;
}
/**
 * Compiles the options once and returns operations that check every URL and path — against the
 * static roots and every path a live grant has admitted — before the core runs, plus `allow` to
 * grant one more. This is the only place the shell's rules live, so the native Layer, a served
 * renderer call, the memory Layer, and a grant cannot drift apart. An invalid policy or a relative
 * root fails here, while the Layer is building, rather than on the first call.
 */
export declare const operations: <R>(options: Shell.Options, core: Core<R>) => Effect.Effect<Granted<R>, SewedError>;
//# sourceMappingURL=ShellPolicy.d.ts.map