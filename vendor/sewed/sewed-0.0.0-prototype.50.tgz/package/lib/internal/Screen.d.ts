import { Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import * as Screen from "../Screen.ts";
import { SewedError } from "../SewedError.ts";
export { Bounds, Change, Display, Point } from "../Screen.ts";
export declare const displays: Effect.Effect<readonly Screen.Display[], SewedError, MainContext>;
export declare const primary: Effect.Effect<{
    readonly id: number;
    readonly label: string;
    readonly bounds: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly workArea: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly scaleFactor: number;
    readonly rotation: number;
    readonly internal: boolean;
}, SewedError, MainContext>;
export declare const cursor: Effect.Effect<Screen.Point, SewedError, MainContext>;
export declare const nearest: (point: Screen.Point) => Effect.Effect<{
    readonly id: number;
    readonly label: string;
    readonly bounds: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly workArea: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly scaleFactor: number;
    readonly rotation: number;
    readonly internal: boolean;
}, SewedError, MainContext>;
export declare const matching: (bounds: Screen.Bounds) => Effect.Effect<{
    readonly id: number;
    readonly label: string;
    readonly bounds: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly workArea: {
        readonly x: number;
        readonly y: number;
        readonly width: number;
        readonly height: number;
    };
    readonly scaleFactor: number;
    readonly rotation: number;
    readonly internal: boolean;
}, SewedError, MainContext>;
/**
 * Converts a point in device-independent pixels to the screen's physical pixels, on Linux and
 * Windows, where the two differ on a scaled display.
 */
export declare const dipToScreenPoint: (point: Screen.Point) => Effect.Effect<{
    readonly x: number;
    readonly y: number;
}, SewedError, MainContext>;
/** Converts a point in the screen's physical pixels to device-independent pixels. */
export declare const screenToDipPoint: (point: Screen.Point) => Effect.Effect<{
    readonly x: number;
    readonly y: number;
}, SewedError, MainContext>;
/** Converts a rectangle in device-independent pixels to the screen's physical pixels, on Windows. */
export declare const dipToScreenRect: (bounds: Screen.Bounds) => Effect.Effect<{
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}, SewedError, MainContext>;
/** Converts a rectangle in the screen's physical pixels to device-independent pixels, on Windows. */
export declare const screenToDipRect: (bounds: Screen.Bounds) => Effect.Effect<{
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}, SewedError, MainContext>;
export declare const changes: Stream.Stream<Screen.Change, SewedError, MainContext>;
//# sourceMappingURL=Screen.d.ts.map