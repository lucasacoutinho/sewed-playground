import { Effect } from "effect";
import type { Scope } from "effect";
export interface HealthOptions {
    readonly intervalMs?: number;
}
/** Start a scoped timer-lateness sampler when the diagnostics sink opted into tracing. */
export declare const health: (options?: HealthOptions) => Effect.Effect<void, never, Scope.Scope>;
/** Opt-in trace observations and the scoped health sampler for one Effect runtime. */
export declare const instrument: <A, E, R>(program: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R | Scope.Scope>;
//# sourceMappingURL=Tracing.d.ts.map