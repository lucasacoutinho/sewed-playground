import { Declaration, type Of } from "../Automation.ts";
import type { Control } from "./WebContentsCore.ts";
export interface DebuggerLike {
    attach(version?: string): void;
    detach(): void;
    isAttached(): boolean;
    on(event: "detach", listener: (event: Electron.Event, reason: string) => void): void;
    off(event: "detach", listener: (event: Electron.Event, reason: string) => void): void;
    sendCommand(method: string, params?: unknown): Promise<unknown>;
}
/** The structural subset of a WebContents the automation group drives. */
export interface Contents {
    isDestroyed(): boolean;
    executeJavaScript(code: string, userGesture?: boolean): Promise<unknown>;
    executeJavaScriptInIsolatedWorld(worldId: number, scripts: ReadonlyArray<{
        readonly code: string;
    }>, userGesture?: boolean): Promise<unknown>;
    sendInputEvent(event: Electron.MouseInputEvent | Electron.MouseWheelInputEvent | Electron.KeyboardInputEvent): void;
    readonly debugger: DebuggerLike;
}
export declare const make: <A extends Declaration = {}>(declaration: A | undefined, contents: Contents, control: Pick<Control, "isClosed" | "closedError">) => {
    readonly automation: Of<A>;
    readonly release: () => void;
};
//# sourceMappingURL=ContentsAutomation.d.ts.map