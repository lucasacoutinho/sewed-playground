import type { BrowserWindow } from "electron";
import { Deferred, Effect } from "effect";
import * as Dialog from "../Dialog.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export declare const dialogs: (parent: BrowserWindow, closed: Deferred.Deferred<void>) => {
    message: (options: Dialog.MessageOptions) => Effect.Effect<Dialog.MessageResult, SewedError, MainContext>;
    open: (options: Dialog.OpenOptions) => Effect.Effect<Dialog.OpenResult, SewedError, MainContext>;
    save: (options: Dialog.SaveOptions) => Effect.Effect<Dialog.SaveResult, SewedError, MainContext>;
};
//# sourceMappingURL=Dialog.d.ts.map