import { Effect } from "effect";
import type { FromServerEncoded } from "effect/rpc/RpcMessage";
import type { AnswerBound } from "./Bulk.ts";
import type { Encoding } from "./Encoding.ts";
import type { Client, Incoming, RequestId } from "./OwnerClient.ts";
import { type Wire } from "./Transport.ts";
/** What the send path needs of the owner it belongs to. */
export interface Owner {
    readonly clients: ReadonlyMap<number, Client>;
    readonly encoding: Encoding;
    readonly answerBounds: ReadonlyMap<string, AnswerBound>;
    readonly offer: (incoming: Incoming) => boolean;
    readonly disconnect: (clientId: number, reason: string) => void;
    readonly endRequest: (clientId: number, client: Client, requestId: RequestId, outcome: "success" | "failure" | "interrupted") => void;
    /** Called for each stream frame that left. */
    readonly onFrame: (clientId: number, requestId: RequestId, frame: Wire) => void;
}
/**
 * How an owner ships what RpcServer hands it: an answer whole, a bulk answer or a stream in
 * acknowledged parts, and a typed refusal in place of an answer that does not fit.
 */
export declare const make: (owner: Owner) => (id: number, response: FromServerEncoded) => Effect.Effect<void>;
//# sourceMappingURL=OwnerSend.d.ts.map