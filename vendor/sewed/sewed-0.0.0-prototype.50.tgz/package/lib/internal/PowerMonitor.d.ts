import { Effect, Layer } from "effect";
import type { Stream } from "effect";
import * as PowerMonitor from "../PowerMonitor.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
export { Event, IdleState, IdleThreshold, State, ThermalState, capability, protocol, } from "../PowerMonitor.ts";
export declare const state: (idleThresholdSeconds: number) => Effect.Effect<PowerMonitor.State, SewedError, MainContext>;
/** Every observer owns its listeners and a bounded queue; overflow fails that observer with `Limit`. */
export declare const events: Stream.Stream<PowerMonitor.Event, SewedError, MainContext>;
/**
 * The power capability for main. The rules live in this Layer, not in a separate host, so
 * `Capability.serve(PowerMonitor.capability)` gives a document exactly the checks a main-side call
 * obeys.
 */
export declare const native: () => Layer.Layer<typeof PowerMonitor.capability, SewedError, MainContext>;
//# sourceMappingURL=PowerMonitor.d.ts.map