import { MessagePort } from "node:worker_threads";
import { Effect, Schema } from "effect";
import { type Bound } from "../Binding.ts";
import { Event } from "../Diagnostics.ts";
export declare const WorkerData: Schema.Struct<{
    readonly url: Schema.String;
    readonly ownerId: Schema.String;
    readonly diagnostics: Schema.Boolean;
    readonly tracing: Schema.Boolean;
    readonly bindings: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly ownerId: Schema.String;
    }>>;
}>;
export declare const FromWorker: Schema.Union<readonly [Schema.TaggedStruct<"Ready", {}>, Schema.TaggedStruct<"Failed", {
    readonly message: Schema.String;
}>, Schema.TaggedStruct<"Diagnostics", {
    readonly events: Schema.$Array<Schema.Union<readonly [Schema.TaggedStruct<"OwnerStarted", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly ownerId: Schema.String;
    }>, Schema.TaggedStruct<"OwnerClosed", {
        readonly ownerId: Schema.String;
        readonly reason: Schema.Literals<readonly ["scope-closed", "shutdown", "terminated", "exited", "startup-failed"]>;
    }>, Schema.TaggedStruct<"RuntimeClosed", {
        readonly runtimeId: Schema.String;
    }>, Schema.TaggedStruct<"BindingOpened", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly bindingId: Schema.String;
        readonly slot: Schema.String;
        readonly ownerId: Schema.String;
    }>, Schema.TaggedStruct<"BindingClosed", {
        readonly bindingId: Schema.String;
        readonly reason: Schema.Literals<readonly ["scope-closed", "navigation", "renderer-gone", "renderer-disconnected", "replaced"]>;
    }>, Schema.TaggedStruct<"RequestStarted", {
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly procedure: Schema.String;
        readonly traceId: Schema.optionalKey<Schema.String>;
        readonly spanId: Schema.optionalKey<Schema.String>;
    }>, Schema.TaggedStruct<"RequestEnded", {
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
        readonly reason: Schema.String;
    }>, Schema.TaggedStruct<"EventsDropped", {
        readonly ownerId: Schema.String;
        readonly count: Schema.Finite;
    }>, Schema.TaggedStruct<"ResourceChanged", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly resourceId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly state: Schema.Literals<readonly ["acquiring", "ready", "releasing"]>;
    }>, Schema.TaggedStruct<"ResourceClosed", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly resourceId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
        readonly reason: Schema.String;
    }>, Schema.TaggedStruct<"TransferProgress", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly ownerId: Schema.String;
        readonly clientId: Schema.Finite;
        readonly requestId: Schema.String;
        readonly frames: Schema.Int;
        readonly wireBytes: Schema.Int;
        readonly terminal: Schema.Boolean;
    }>, Schema.TaggedStruct<"TraceSpan", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
        readonly parentId: Schema.optionalKey<Schema.String>;
        readonly name: Schema.String;
        readonly startTime: Schema.String;
        readonly endTime: Schema.optionalKey<Schema.String>;
        readonly outcome: Schema.Literals<readonly ["running", "success", "failure"]>;
        readonly ownerId: Schema.optionalKey<Schema.String>;
        readonly binding: Schema.optionalKey<Schema.String>;
    }>, Schema.TaggedStruct<"TraceEvent", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly traceId: Schema.String;
        readonly spanId: Schema.String;
        readonly name: Schema.String;
        readonly time: Schema.String;
    }>, Schema.TaggedStruct<"RuntimeSample", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly delayMs: Schema.Number;
        readonly intervalMs: Schema.Number;
    }>, Schema.TaggedStruct<"QueueSample", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly queueId: Schema.String;
        readonly ownerId: Schema.optionalKey<Schema.String>;
        readonly kind: Schema.Literals<readonly ["rpc-server", "rpc-client"]>;
        readonly size: Schema.Number;
        readonly capacity: Schema.Number;
        readonly activeRequests: Schema.optionalKey<Schema.Number>;
    }>, Schema.TaggedStruct<"QueueClosed", {
        readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
        readonly threadId: Schema.Finite;
        readonly processId: Schema.optionalKey<Schema.Finite>;
        readonly runtimeId: Schema.String;
        readonly queueId: Schema.String;
    }>]>>;
    readonly dropped: Schema.Int;
}>, Schema.TaggedStruct<"Open", {
    readonly key: Schema.String;
    readonly port: Schema.instanceOf<MessagePort, unknown>;
}>]>;
export declare const ToWorker: Schema.Union<readonly [Schema.TaggedStruct<"Shutdown", {}>, Schema.TaggedStruct<"DiagnosticsAck", {}>, Schema.TaggedStruct<"Connect", {
    readonly port: Schema.instanceOf<MessagePort, unknown>;
}>]>;
export type DiagnosticsMessage = Extract<typeof FromWorker.Type, {
    readonly _tag: "Diagnostics";
}>;
export interface DiagnosticsControlMessage {
    readonly _tag: "Diagnostics";
    readonly events: readonly Event[];
    readonly dropped: number;
}
export interface DiagnosticsParent {
    readonly postMessage: (message: DiagnosticsControlMessage) => void;
}
/** One batch in flight and a bounded waiting buffer keep diagnostics off the RPC critical path. */
export declare const forwardDiagnostics: (parent: DiagnosticsParent) => {
    emit(event: Event): void;
    acknowledge(): void;
    close(): void;
};
export declare const remoteBindings: (parent: MessagePort, bindings: typeof WorkerData.Type.bindings) => readonly Bound[];
export declare const serveBindings: (bindings: readonly Bound[]) => Effect.Effect<({ key, port }: Extract<typeof FromWorker.Type, {
    readonly _tag: "Open";
}>) => import("../SewedError.ts").SewedError | undefined, import("../SewedError.ts").SewedError, import("effect/Scope").Scope>;
//# sourceMappingURL=WorkerBindings.d.ts.map