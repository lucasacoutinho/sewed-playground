import { Effect, Layer } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as Shell from "../Shell.ts";
export { Grants, OpenResult, Policy, Shortcut, capability, protocol } from "../Shell.ts";
export type { Options } from "../Shell.ts";
/**
 * The shell capability for main, and the scoped grant beside it. The policy lives in this Layer,
 * not in a separate host, so `Capability.serve(Shell.capability)` gives a document exactly the
 * rules a main-side call obeys — `Shell.Grants` carries no RPC of its own, so a served document has
 * no route to it. Both services come from the one `ShellPolicy.operations` call below, so a path
 * `Shell.Grants["allow"]` admits is the very root `allowedPath` already consults, not a second copy
 * of the containment rule.
 */
export declare const native: (options: Shell.Options) => Layer.Layer<typeof Shell.capability | Shell.Grants, SewedError, MainContext>;
/**
 * Reads a Windows shortcut. Main-only and outside the shell policy, which governs what a document
 * may ask for: main names the path itself.
 */
export declare const readShortcutLink: (target: string) => Effect.Effect<Shell.Shortcut, SewedError, MainContext>;
/** Creates, updates or replaces a Windows shortcut; `create` is the default. */
export declare const writeShortcutLink: (target: string, shortcut: Shell.Shortcut, mode?: "create" | "update" | "replace") => Effect.Effect<void, SewedError, MainContext>;
//# sourceMappingURL=Shell.d.ts.map