import type { BaseWindow } from "electron";
import { Deferred, Effect, Stream } from "effect";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import * as TouchBar from "../TouchBar.ts";
export { Interaction, Item, Options } from "../TouchBar.ts";
export interface Handle {
    /** Replaces the window's touch bar; macOS only, `Native` elsewhere. */
    readonly set: (options: TouchBar.Options) => Effect.Effect<void, SewedError, MainContext>;
    readonly clear: Effect.Effect<void, SewedError, MainContext>;
    /** Interactions with the current bar; each observer owns a queue of 128 events. */
    readonly interactions: Stream.Stream<TouchBar.Interaction, SewedError, MainContext>;
}
export declare const make: (native: BaseWindow, isClosed: () => boolean, closed: Deferred.Deferred<void>) => Handle;
//# sourceMappingURL=TouchBar.d.ts.map