import { Layer } from "effect";
import * as Cookie from "../Cookie.ts";
import type { SewedError } from "../SewedError.ts";
import * as CapabilityMemory from "./CapabilityMemory.ts";
/**
 * The cookie capability for tests: the same policy `Cookies.native` carries, no session and no
 * Electron, and a recorder listing the calls. An invalid policy still fails as the Layer builds.
 */
export declare const memory: (policy: Cookie.Policy) => Layer.Layer<typeof Cookie.capability | CapabilityMemory.Recorder, SewedError>;
//# sourceMappingURL=CookiesMemory.d.ts.map