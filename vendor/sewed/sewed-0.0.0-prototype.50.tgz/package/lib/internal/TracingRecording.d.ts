import { Effect } from "effect";
import type { Scope } from "effect";
import type { contentTracing } from "electron";
import { SewedError } from "../SewedError.ts";
export type NativeOptions = Parameters<typeof contentTracing.startRecording>[0];
type Native = Pick<typeof contentTracing, "startRecording" | "stopRecording">;
export interface Handle {
    readonly stop: Effect.Effect<string, SewedError>;
}
/** Owns one native tracing recorder for the lifetime of a scoped recording. */
export declare const make: (native: Native) => {
    record: (file: string, options: NativeOptions) => Effect.Effect<Handle, SewedError, Scope.Scope>;
};
export {};
//# sourceMappingURL=TracingRecording.d.ts.map