import { Context } from "effect";
import type { Rpc, RpcGroup } from "effect/rpc";
export type Encoding = "json" | "binary";
export declare const binary: <Rpcs extends Rpc.Any>(protocol: RpcGroup.RpcGroup<Rpcs>) => RpcGroup.RpcGroup<Rpcs>;
export declare const encodingOf: (protocol: {
    readonly annotations: Context.Context<never>;
}) => Encoding;
//# sourceMappingURL=Encoding.d.ts.map