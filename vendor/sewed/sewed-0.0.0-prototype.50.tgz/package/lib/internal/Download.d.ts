import { Effect, Scope } from "effect";
import * as Download from "../Download.ts";
import { MainContext } from "../RuntimeContext.ts";
import { SewedError } from "../SewedError.ts";
import type { Handle as SessionHandle } from "./Session.ts";
export { Options, State, Outcome } from "../Download.ts";
export type { Handle } from "../Download.ts";
export { adopt } from "./DownloadItem.ts";
export declare const start: (session: SessionHandle, options: Download.Options) => Effect.Effect<Download.Handle, SewedError, MainContext | Scope.Scope>;
//# sourceMappingURL=Download.d.ts.map