import type { WebContents } from "electron";
import type { Handle as BrowserWindowHandle } from "../BrowserWindow.ts";
import type { Handle as WebContentsViewHandle } from "./WebContentsView.ts";
/** Browser windows and base windows; only a browser window has `webContents`. */
export declare const windows: {
    publish: (id: string, handle: BrowserWindowHandle | Omit<{
        setFocusable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focusable: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        contentProtected: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setRepresentedFilename: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        representedFilename: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setDocumentEdited: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        documentEdited: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVibrancy: (vibrancy: import("../WindowControls.ts").Vibrancy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWindowButtonPosition: (position: import("./Geometry.ts").Point | null) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        windowButtonPosition: import("effect/Effect").Effect<{
            x: number;
            y: number;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSheetOffset: (offset: {
            readonly y: number;
            readonly x?: number;
        }) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        previewFile: (path: string, displayName?: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        closeFilePreview: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setHiddenInMissionControl: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hiddenInMissionControl: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAutoHideCursor: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        invalidateShadow: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setExcludedFromShownWindowsMenu: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        excludedFromShownWindowsMenu: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        tabs: {
            identifier: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            selectNext: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            selectPrevious: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            showAll: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            mergeAll: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            moveToNewWindow: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            toggleBar: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            add: (window: {
                readonly id: string;
            }) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        };
        setAccentColor: (color: import("../WindowControls.ts").AccentColor) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAppDetails: (details: import("../WindowControls.ts").AppDetails) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundMaterial: (material: import("../WindowControls.ts").BackgroundMaterial) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbarButtons: (buttons: ReadonlyArray<import("../WindowControls.ts").ThumbarButton>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        thumbarClicks: import("effect/Stream").Stream<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbnailClip: (region: import("./Geometry.ts").Bounds) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbnailToolTip: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        snapped: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        tabletMode: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        windowMessages: (message: number) => import("effect/Stream").Stream<import("../WindowControls.ts").WindowMessage, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        native: Electron.CrossProcessExports.BaseWindow;
        closed: import("effect/Deferred").Deferred<void, never>;
        webContents: {
            frames: (options?: import("../WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("../WebContents.ts").Frame, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            painting: import("effect/Effect").Effect<{
                readonly offscreen: boolean;
                readonly painting: boolean;
                readonly frameRate: number;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setPainting: (painting: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setFrameRate: (rate: import("../WebContents.ts").FrameRate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            invalidate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            frameTree: import("effect/Effect").Effect<readonly {
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            opener: import("effect/Effect").Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            focusedFrame: import("effect/Effect").Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            hostId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devToolsContentsId: import("effect/Effect").Effect<number | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            collectJavaScriptCallStack: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoomLevel: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoomMode: import("effect/Effect").Effect<"default" | "disabled" | "isolated" | "manual", import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            rendererProcessId: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            sharedWorkers: import("effect/Effect").Effect<readonly {
                readonly id: string;
                readonly url: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectSharedWorker: (id: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devToolsTargetId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            addDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            removeDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            printers: import("effect/Effect").Effect<readonly {
                readonly name: string;
                readonly displayName: string;
                readonly description: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            webRtc: import("effect/Effect").Effect<{
                readonly ipHandlingPolicy: string;
                readonly udpPortRange: {
                    readonly min: number;
                    readonly max: number;
                };
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            caretBrowsing: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setCaretBrowsing: (enabled: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            events: import("effect/Stream").Stream<{
                readonly kind: "context-menu";
                readonly x: number;
                readonly y: number;
                readonly pageUrl: string;
                readonly frameUrl: string;
                readonly linkUrl: string;
                readonly linkText: string;
                readonly sourceUrl: string;
                readonly mediaType: string;
                readonly hasImageContents: boolean;
                readonly isEditable: boolean;
                readonly selectionText: string;
                readonly misspelledWord: string;
                readonly dictionarySuggestions: readonly string[];
                readonly source: string;
                readonly editFlags: {
                    readonly canUndo: boolean;
                    readonly canRedo: boolean;
                    readonly canCut: boolean;
                    readonly canCopy: boolean;
                    readonly canPaste: boolean;
                    readonly canDelete: boolean;
                    readonly canSelectAll: boolean;
                };
            } | {
                readonly kind: "cursor";
                readonly type: string;
            } | {
                readonly kind: "target-url";
                readonly url: string;
            } | {
                readonly kind: "theme-color";
                readonly color: string | null;
            } | {
                readonly kind: "html-full-screen";
                readonly active: boolean;
            } | {
                readonly kind: "dom-ready";
            } | {
                readonly kind: "preload-error";
                readonly path: string;
                readonly message: string;
            } | {
                readonly kind: "frame";
                readonly change: "created" | "loaded" | "navigated";
                readonly frame: {
                    readonly processId: number;
                    readonly routingId: number;
                    readonly isMainFrame: boolean;
                };
                readonly url?: string;
                readonly httpStatus?: number;
            } | {
                readonly kind: "devtools";
                readonly change: "closed" | "focused" | "opened";
            } | {
                readonly kind: "devtools-open-url";
                readonly url: string;
            } | {
                readonly kind: "devtools-reload-page";
            } | {
                readonly kind: "devtools-search-query";
                readonly query: string;
            } | {
                readonly kind: "content-bounds-updated";
                readonly bounds: {
                    readonly x: number;
                    readonly y: number;
                    readonly width: number;
                    readonly height: number;
                };
            } | {
                readonly kind: "preferred-size";
                readonly width: number;
                readonly height: number;
            } | {
                readonly kind: "input";
                readonly type: string;
            } | {
                readonly kind: "webview-attached";
                readonly nativeId: number;
            } | {
                readonly kind: "frame-will-navigate";
                readonly url: string;
                readonly isMainFrame: boolean;
                readonly isSameDocument: boolean;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            activity: import("effect/Effect").Effect<{
                readonly loading: boolean;
                readonly waitingForResponse: boolean;
                readonly crashed: boolean;
                readonly beingCaptured: boolean;
                readonly backgroundThrottling: boolean;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devTools: import("effect/Effect").Effect<{
                readonly opened: boolean;
                readonly focused: boolean;
                readonly title: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            toggleDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setDevToolsTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectElement: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectWorker: (kind: "service" | "shared") => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            disableDeviceEmulation: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            edit: (command: import("../WebContents.ts").EditCommand) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            replace: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            replaceMisspelling: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            copyImageAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            startDrag: (drag: import("../WebContents.ts").Drag) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            showDefinitionForSelection: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            takeHeapSnapshot: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            blocked: import("effect/Stream").Stream<{
                readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
                readonly url: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            webviews: import("effect/Stream").Stream<import("./ContentsWebviews.ts").Handle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            load: <Keys extends string, const B extends readonly import("../Binding.ts").Bound<Keys>[]>(entry: import("../Renderer.ts").Entry<Keys> & import("../Binding.ts").Complete<Keys, B>, options: {
                readonly bindings: B;
            }) => import("effect/Effect").Effect<undefined, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            reload: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            reloadIgnoringCache: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            stopLoading: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            downloads: import("effect/Stream").Stream<import("./Download.ts").Handle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            print: (options?: import("../WebContents.ts").PrintOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            pdf: (options?: import("../WebContents.ts").PdfOptions) => import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            capture: (options?: import("../WebContents.ts").CaptureOptions) => import("effect/Effect").Effect<{
                bytes: Uint8Array<ArrayBuffer>;
                width: number;
                height: number;
                scaleFactor: number;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoom: import("effect/Stream").Stream<{
                readonly factor: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            setZoom: (factor: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            audio: import("effect/Stream").Stream<{
                readonly muted: boolean;
                readonly audible: boolean;
            }, never, import("../RuntimeContext.ts").MainContext>;
            setAudioMuted: (muted: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            userAgent: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setUserAgent: (userAgent: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            insertText: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            savePage: (path: string, type?: import("../WebContents.ts").SaveType) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setBackgroundThrottling: (allowed: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setIgnoreMenuShortcuts: (ignore: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            find: (text: string, options?: import("../WebContents.ts").FindOptions) => import("effect/Effect").Effect<import("../WebContents.ts").Search, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
            findNext: (forward?: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            stopFind: (action?: import("../WebContents.ts").FindStop) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            style: (css: string, options?: import("../WebContents.ts").StyleOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
            history: import("effect/Stream").Stream<{
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            }, never, import("../RuntimeContext.ts").MainContext>;
            back: import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            forward: import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            go: (index: number) => import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            removeHistoryEntry: (index: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            clearHistory: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            openDevToolsIn: (host: WebContentsViewHandle, options?: import("../WebContents.ts").DevToolsHostOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            closeDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            console: import("effect/Stream").Stream<{
                readonly level: "debug" | "error" | "info" | "warning";
                readonly message: string;
                readonly lineNumber: number;
                readonly sourceId: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            state: import("effect/Stream").Stream<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            responsiveness: import("effect/Stream").Stream<{
                readonly status: "unknown";
            } | {
                readonly status: "responsive" | "unresponsive";
                readonly processId: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            favicons: import("effect/Stream").Stream<readonly string[], never, import("../RuntimeContext.ts").MainContext>;
            title: import("effect/Stream").Stream<string, never, import("../RuntimeContext.ts").MainContext>;
            current: import("effect/Effect").Effect<{
                readonly state: {
                    readonly status: "ready";
                    readonly url: string;
                    readonly processId: number;
                    readonly httpStatus: number;
                } | {
                    readonly status: "failed";
                    readonly url: string;
                    readonly code: number;
                    readonly description: string;
                } | {
                    readonly status: "idle";
                } | {
                    readonly status: "loading";
                    readonly url: string;
                } | {
                    readonly status: "gone";
                    readonly reason: string;
                    readonly exitCode: number;
                };
                readonly history: {
                    readonly index: number;
                    readonly entries: readonly {
                        readonly url: string;
                        readonly title: string;
                    }[];
                    readonly canGoBack: boolean;
                    readonly canGoForward: boolean;
                };
                readonly title: string;
                readonly favicons: readonly string[];
                readonly zoom: {
                    readonly factor: number;
                };
                readonly audio: {
                    readonly muted: boolean;
                    readonly audible: boolean;
                };
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            terminate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            recover: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        } | undefined;
        id: string;
        current: import("effect/Effect").Effect<{
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly normalBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly contentBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly visible: boolean;
            readonly focused: boolean;
            readonly minimized: boolean;
            readonly maximized: boolean;
            readonly fullScreen: boolean;
            readonly simpleFullScreen: boolean;
            readonly title: string;
            readonly alwaysOnTop: boolean;
            readonly opacity: number;
            readonly resizable: boolean;
            readonly movable: boolean;
            readonly minimizable: boolean;
            readonly maximizable: boolean;
            readonly closable: boolean;
            readonly fullScreenable: boolean;
            readonly menuBarVisible: boolean;
            readonly kiosk: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        show: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        showInactive: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hide: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBounds: (bounds: import("./WindowControls.ts").BoundsUpdate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFullScreen: (fullScreen: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSimpleFullScreen: (simpleFullScreen: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        minimize: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        maximize: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        restore: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        close: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAlwaysOnTop: (alwaysOnTop: boolean, level?: import("./WindowControls.ts").AlwaysOnTopLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setOpacity: (opacity: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setResizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMovable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMinimizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMaximizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setClosable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFullScreenable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMenuBarVisibility: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setKiosk: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSkipTaskbar: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentProtection: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        flash: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWindowButtonVisibility: (visible: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setProgress: (progress: number, mode?: import("./WindowControls.ts").ProgressMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setOverlayIcon: (icon: import("./Image.ts").Source | null, description: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIcon: (icon: import("./Image.ts").Source) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setParent: (parent: import("./Window.ts").Parent | null) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setEnabled: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIgnoreMouseEvents: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAutoHideMenuBar: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVisibleOnAllWorkspaces: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMinimumSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMaximumSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAspectRatio: (ratio: number, extra?: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundColor: (color: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setHasShadow: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentBounds: (bounds: import("./Geometry.ts").Bounds) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        moveAbove: (mediaSourceId: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAccessibleTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setTitleBarOverlay: (overlay: import("../WindowControls.ts").TitleBarOverlay) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setShape: (rectangles: ReadonlyArray<import("./Geometry.ts").Bounds>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeMenu: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "ready-to-show";
        } | {
            readonly kind: "persisted-state-restored";
        } | {
            readonly kind: "app-command";
            readonly command: string;
        } | {
            readonly kind: "moved" | "resized";
        } | {
            readonly kind: "will-move" | "will-resize";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly edge?: string;
        } | {
            readonly kind: "swipe";
            readonly direction: string;
        } | {
            readonly kind: "rotate-gesture";
            readonly rotation: number;
        } | {
            readonly kind: "sheet-begin" | "sheet-end";
        } | {
            readonly kind: "new-window-for-tab";
        } | {
            readonly kind: "session-end";
            readonly reasons: readonly string[];
        } | {
            readonly kind: "system-context-menu";
            readonly x: number;
            readonly y: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        center: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        moveTop: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "window">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        state: import("effect/Stream").Stream<{
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly normalBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly contentBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly visible: boolean;
            readonly focused: boolean;
            readonly minimized: boolean;
            readonly maximized: boolean;
            readonly fullScreen: boolean;
            readonly simpleFullScreen: boolean;
            readonly title: string;
            readonly alwaysOnTop: boolean;
            readonly opacity: number;
            readonly resizable: boolean;
            readonly movable: boolean;
            readonly minimizable: boolean;
            readonly maximizable: boolean;
            readonly closable: boolean;
            readonly fullScreenable: boolean;
            readonly menuBarVisible: boolean;
            readonly kiosk: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        awaitClosed: import("effect/Effect").Effect<void, never, import("../RuntimeContext.ts").MainContext>;
        attach: (view: import("./View.ts").Attachable, options: import("./View.ts").AttachOptions) => import("effect/Effect").Effect<import("./View.ts").Attachment, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        mediaSourceId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        contentBounds: import("effect/Effect").Effect<Electron.Rectangle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        sizeLimits: import("effect/Effect").Effect<{
            readonly minimum: {
                readonly width: number;
                readonly height: number;
            };
            readonly maximum: {
                readonly width: number;
                readonly height: number;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        enabled: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        backgroundColor: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        visibleOnAllWorkspaces: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        parentId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        childIds: import("effect/Effect").Effect<string[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        shadow: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        accessibleTitle: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        normal: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        menuBarAutoHide: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        nativeHandle: import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        touchBar: import("./TouchBar.ts").Handle;
    }, "closed" | "native" | "webContents">, isClosed: () => boolean) => () => void;
    find: (id: string) => BrowserWindowHandle | Omit<{
        setFocusable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focusable: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        contentProtected: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setRepresentedFilename: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        representedFilename: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setDocumentEdited: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        documentEdited: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVibrancy: (vibrancy: import("../WindowControls.ts").Vibrancy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWindowButtonPosition: (position: import("./Geometry.ts").Point | null) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        windowButtonPosition: import("effect/Effect").Effect<{
            x: number;
            y: number;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSheetOffset: (offset: {
            readonly y: number;
            readonly x?: number;
        }) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        previewFile: (path: string, displayName?: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        closeFilePreview: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setHiddenInMissionControl: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hiddenInMissionControl: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAutoHideCursor: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        invalidateShadow: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setExcludedFromShownWindowsMenu: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        excludedFromShownWindowsMenu: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        tabs: {
            identifier: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            selectNext: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            selectPrevious: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            showAll: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            mergeAll: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            moveToNewWindow: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            toggleBar: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            add: (window: {
                readonly id: string;
            }) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        };
        setAccentColor: (color: import("../WindowControls.ts").AccentColor) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAppDetails: (details: import("../WindowControls.ts").AppDetails) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundMaterial: (material: import("../WindowControls.ts").BackgroundMaterial) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbarButtons: (buttons: ReadonlyArray<import("../WindowControls.ts").ThumbarButton>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        thumbarClicks: import("effect/Stream").Stream<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbnailClip: (region: import("./Geometry.ts").Bounds) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setThumbnailToolTip: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        snapped: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        tabletMode: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        windowMessages: (message: number) => import("effect/Stream").Stream<import("../WindowControls.ts").WindowMessage, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        native: Electron.CrossProcessExports.BaseWindow;
        closed: import("effect/Deferred").Deferred<void, never>;
        webContents: {
            frames: (options?: import("../WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("../WebContents.ts").Frame, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            painting: import("effect/Effect").Effect<{
                readonly offscreen: boolean;
                readonly painting: boolean;
                readonly frameRate: number;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setPainting: (painting: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setFrameRate: (rate: import("../WebContents.ts").FrameRate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            invalidate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            frameTree: import("effect/Effect").Effect<readonly {
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            opener: import("effect/Effect").Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            focusedFrame: import("effect/Effect").Effect<{
                readonly processId: number;
                readonly routingId: number;
                readonly frameTreeNodeId: number;
                readonly token: string;
                readonly osProcessId: number;
                readonly isMainFrame: boolean;
                readonly parent: number | null;
                readonly url: string;
                readonly origin: string;
                readonly name: string;
                readonly visibilityState: string;
            } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            hostId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devToolsContentsId: import("effect/Effect").Effect<number | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            collectJavaScriptCallStack: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoomLevel: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoomMode: import("effect/Effect").Effect<"default" | "disabled" | "isolated" | "manual", import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            rendererProcessId: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            sharedWorkers: import("effect/Effect").Effect<readonly {
                readonly id: string;
                readonly url: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectSharedWorker: (id: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devToolsTargetId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            addDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            removeDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            printers: import("effect/Effect").Effect<readonly {
                readonly name: string;
                readonly displayName: string;
                readonly description: string;
            }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            webRtc: import("effect/Effect").Effect<{
                readonly ipHandlingPolicy: string;
                readonly udpPortRange: {
                    readonly min: number;
                    readonly max: number;
                };
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            caretBrowsing: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setCaretBrowsing: (enabled: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            events: import("effect/Stream").Stream<{
                readonly kind: "context-menu";
                readonly x: number;
                readonly y: number;
                readonly pageUrl: string;
                readonly frameUrl: string;
                readonly linkUrl: string;
                readonly linkText: string;
                readonly sourceUrl: string;
                readonly mediaType: string;
                readonly hasImageContents: boolean;
                readonly isEditable: boolean;
                readonly selectionText: string;
                readonly misspelledWord: string;
                readonly dictionarySuggestions: readonly string[];
                readonly source: string;
                readonly editFlags: {
                    readonly canUndo: boolean;
                    readonly canRedo: boolean;
                    readonly canCut: boolean;
                    readonly canCopy: boolean;
                    readonly canPaste: boolean;
                    readonly canDelete: boolean;
                    readonly canSelectAll: boolean;
                };
            } | {
                readonly kind: "cursor";
                readonly type: string;
            } | {
                readonly kind: "target-url";
                readonly url: string;
            } | {
                readonly kind: "theme-color";
                readonly color: string | null;
            } | {
                readonly kind: "html-full-screen";
                readonly active: boolean;
            } | {
                readonly kind: "dom-ready";
            } | {
                readonly kind: "preload-error";
                readonly path: string;
                readonly message: string;
            } | {
                readonly kind: "frame";
                readonly change: "created" | "loaded" | "navigated";
                readonly frame: {
                    readonly processId: number;
                    readonly routingId: number;
                    readonly isMainFrame: boolean;
                };
                readonly url?: string;
                readonly httpStatus?: number;
            } | {
                readonly kind: "devtools";
                readonly change: "closed" | "focused" | "opened";
            } | {
                readonly kind: "devtools-open-url";
                readonly url: string;
            } | {
                readonly kind: "devtools-reload-page";
            } | {
                readonly kind: "devtools-search-query";
                readonly query: string;
            } | {
                readonly kind: "content-bounds-updated";
                readonly bounds: {
                    readonly x: number;
                    readonly y: number;
                    readonly width: number;
                    readonly height: number;
                };
            } | {
                readonly kind: "preferred-size";
                readonly width: number;
                readonly height: number;
            } | {
                readonly kind: "input";
                readonly type: string;
            } | {
                readonly kind: "webview-attached";
                readonly nativeId: number;
            } | {
                readonly kind: "frame-will-navigate";
                readonly url: string;
                readonly isMainFrame: boolean;
                readonly isSameDocument: boolean;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            activity: import("effect/Effect").Effect<{
                readonly loading: boolean;
                readonly waitingForResponse: boolean;
                readonly crashed: boolean;
                readonly beingCaptured: boolean;
                readonly backgroundThrottling: boolean;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            devTools: import("effect/Effect").Effect<{
                readonly opened: boolean;
                readonly focused: boolean;
                readonly title: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            toggleDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setDevToolsTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectElement: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            inspectWorker: (kind: "service" | "shared") => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            disableDeviceEmulation: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            edit: (command: import("../WebContents.ts").EditCommand) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            replace: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            replaceMisspelling: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            copyImageAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            startDrag: (drag: import("../WebContents.ts").Drag) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            showDefinitionForSelection: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            takeHeapSnapshot: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            blocked: import("effect/Stream").Stream<{
                readonly kind: "download" | "navigation" | "popup" | "redirect" | "webview";
                readonly url: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            webviews: import("effect/Stream").Stream<import("./ContentsWebviews.ts").Handle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            load: <Keys extends string, const B extends readonly import("../Binding.ts").Bound<Keys>[]>(entry: import("../Renderer.ts").Entry<Keys> & import("../Binding.ts").Complete<Keys, B>, options: {
                readonly bindings: B;
            }) => import("effect/Effect").Effect<undefined, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            reload: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            reloadIgnoringCache: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            stopLoading: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            downloads: import("effect/Stream").Stream<import("./Download.ts").Handle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            print: (options?: import("../WebContents.ts").PrintOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            pdf: (options?: import("../WebContents.ts").PdfOptions) => import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            capture: (options?: import("../WebContents.ts").CaptureOptions) => import("effect/Effect").Effect<{
                bytes: Uint8Array<ArrayBuffer>;
                width: number;
                height: number;
                scaleFactor: number;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            zoom: import("effect/Stream").Stream<{
                readonly factor: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            setZoom: (factor: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            audio: import("effect/Stream").Stream<{
                readonly muted: boolean;
                readonly audible: boolean;
            }, never, import("../RuntimeContext.ts").MainContext>;
            setAudioMuted: (muted: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            userAgent: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setUserAgent: (userAgent: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            insertText: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            savePage: (path: string, type?: import("../WebContents.ts").SaveType) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setBackgroundThrottling: (allowed: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            setIgnoreMenuShortcuts: (ignore: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            find: (text: string, options?: import("../WebContents.ts").FindOptions) => import("effect/Effect").Effect<import("../WebContents.ts").Search, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
            findNext: (forward?: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            stopFind: (action?: import("../WebContents.ts").FindStop) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            style: (css: string, options?: import("../WebContents.ts").StyleOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
            history: import("effect/Stream").Stream<{
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            }, never, import("../RuntimeContext.ts").MainContext>;
            back: import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            forward: import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            go: (index: number) => import("effect/Effect").Effect<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            removeHistoryEntry: (index: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            clearHistory: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            openDevToolsIn: (host: WebContentsViewHandle, options?: import("../WebContents.ts").DevToolsHostOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            closeDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            console: import("effect/Stream").Stream<{
                readonly level: "debug" | "error" | "info" | "warning";
                readonly message: string;
                readonly lineNumber: number;
                readonly sourceId: string;
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            state: import("effect/Stream").Stream<{
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            responsiveness: import("effect/Stream").Stream<{
                readonly status: "unknown";
            } | {
                readonly status: "responsive" | "unresponsive";
                readonly processId: number;
            }, never, import("../RuntimeContext.ts").MainContext>;
            favicons: import("effect/Stream").Stream<readonly string[], never, import("../RuntimeContext.ts").MainContext>;
            title: import("effect/Stream").Stream<string, never, import("../RuntimeContext.ts").MainContext>;
            current: import("effect/Effect").Effect<{
                readonly state: {
                    readonly status: "ready";
                    readonly url: string;
                    readonly processId: number;
                    readonly httpStatus: number;
                } | {
                    readonly status: "failed";
                    readonly url: string;
                    readonly code: number;
                    readonly description: string;
                } | {
                    readonly status: "idle";
                } | {
                    readonly status: "loading";
                    readonly url: string;
                } | {
                    readonly status: "gone";
                    readonly reason: string;
                    readonly exitCode: number;
                };
                readonly history: {
                    readonly index: number;
                    readonly entries: readonly {
                        readonly url: string;
                        readonly title: string;
                    }[];
                    readonly canGoBack: boolean;
                    readonly canGoForward: boolean;
                };
                readonly title: string;
                readonly favicons: readonly string[];
                readonly zoom: {
                    readonly factor: number;
                };
                readonly audio: {
                    readonly muted: boolean;
                    readonly audible: boolean;
                };
            }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            terminate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            recover: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
            decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        } | undefined;
        id: string;
        current: import("effect/Effect").Effect<{
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly normalBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly contentBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly visible: boolean;
            readonly focused: boolean;
            readonly minimized: boolean;
            readonly maximized: boolean;
            readonly fullScreen: boolean;
            readonly simpleFullScreen: boolean;
            readonly title: string;
            readonly alwaysOnTop: boolean;
            readonly opacity: number;
            readonly resizable: boolean;
            readonly movable: boolean;
            readonly minimizable: boolean;
            readonly maximizable: boolean;
            readonly closable: boolean;
            readonly fullScreenable: boolean;
            readonly menuBarVisible: boolean;
            readonly kiosk: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        show: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        showInactive: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hide: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBounds: (bounds: import("./WindowControls.ts").BoundsUpdate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFullScreen: (fullScreen: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSimpleFullScreen: (simpleFullScreen: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        minimize: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        maximize: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        restore: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        close: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAlwaysOnTop: (alwaysOnTop: boolean, level?: import("./WindowControls.ts").AlwaysOnTopLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setOpacity: (opacity: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setResizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMovable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMinimizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMaximizable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setClosable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFullScreenable: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMenuBarVisibility: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setKiosk: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setSkipTaskbar: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentProtection: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        flash: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWindowButtonVisibility: (visible: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setProgress: (progress: number, mode?: import("./WindowControls.ts").ProgressMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setOverlayIcon: (icon: import("./Image.ts").Source | null, description: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIcon: (icon: import("./Image.ts").Source) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setParent: (parent: import("./Window.ts").Parent | null) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setEnabled: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIgnoreMouseEvents: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAutoHideMenuBar: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVisibleOnAllWorkspaces: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMinimumSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setMaximumSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAspectRatio: (ratio: number, extra?: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundColor: (color: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setHasShadow: (value: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentBounds: (bounds: import("./Geometry.ts").Bounds) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setContentSize: (size: import("../WindowControls.ts").Size) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        moveAbove: (mediaSourceId: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setAccessibleTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setTitleBarOverlay: (overlay: import("../WindowControls.ts").TitleBarOverlay) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setShape: (rectangles: ReadonlyArray<import("./Geometry.ts").Bounds>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeMenu: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "ready-to-show";
        } | {
            readonly kind: "persisted-state-restored";
        } | {
            readonly kind: "app-command";
            readonly command: string;
        } | {
            readonly kind: "moved" | "resized";
        } | {
            readonly kind: "will-move" | "will-resize";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly edge?: string;
        } | {
            readonly kind: "swipe";
            readonly direction: string;
        } | {
            readonly kind: "rotate-gesture";
            readonly rotation: number;
        } | {
            readonly kind: "sheet-begin" | "sheet-end";
        } | {
            readonly kind: "new-window-for-tab";
        } | {
            readonly kind: "session-end";
            readonly reasons: readonly string[];
        } | {
            readonly kind: "system-context-menu";
            readonly x: number;
            readonly y: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        center: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        moveTop: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "window">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        state: import("effect/Stream").Stream<{
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly normalBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly contentBounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
            readonly visible: boolean;
            readonly focused: boolean;
            readonly minimized: boolean;
            readonly maximized: boolean;
            readonly fullScreen: boolean;
            readonly simpleFullScreen: boolean;
            readonly title: string;
            readonly alwaysOnTop: boolean;
            readonly opacity: number;
            readonly resizable: boolean;
            readonly movable: boolean;
            readonly minimizable: boolean;
            readonly maximizable: boolean;
            readonly closable: boolean;
            readonly fullScreenable: boolean;
            readonly menuBarVisible: boolean;
            readonly kiosk: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        awaitClosed: import("effect/Effect").Effect<void, never, import("../RuntimeContext.ts").MainContext>;
        attach: (view: import("./View.ts").Attachable, options: import("./View.ts").AttachOptions) => import("effect/Effect").Effect<import("./View.ts").Attachment, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        mediaSourceId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        contentBounds: import("effect/Effect").Effect<Electron.Rectangle, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        sizeLimits: import("effect/Effect").Effect<{
            readonly minimum: {
                readonly width: number;
                readonly height: number;
            };
            readonly maximum: {
                readonly width: number;
                readonly height: number;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        enabled: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        backgroundColor: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        visibleOnAllWorkspaces: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        parentId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        childIds: import("effect/Effect").Effect<string[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        shadow: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        accessibleTitle: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        normal: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        menuBarAutoHide: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        nativeHandle: import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        touchBar: import("./TouchBar.ts").Handle;
    }, "closed" | "native" | "webContents"> | undefined;
};
/** Web contents by the id of the window, view or webview that owns them. */
export declare const contents: {
    publish: (id: string, handle: {
        frames: (options?: import("../WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("../WebContents.ts").Frame, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        painting: import("effect/Effect").Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setPainting: (painting: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFrameRate: (rate: import("../WebContents.ts").FrameRate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        invalidate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        frameTree: import("effect/Effect").Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        opener: import("effect/Effect").Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focusedFrame: import("effect/Effect").Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hostId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devToolsContentsId: import("effect/Effect").Effect<number | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        collectJavaScriptCallStack: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoomLevel: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoomMode: import("effect/Effect").Effect<"default" | "disabled" | "isolated" | "manual", import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        rendererProcessId: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        sharedWorkers: import("effect/Effect").Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectSharedWorker: (id: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devToolsTargetId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        addDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        printers: import("effect/Effect").Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        webRtc: import("effect/Effect").Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        caretBrowsing: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setCaretBrowsing: (enabled: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        activity: import("effect/Effect").Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devTools: import("effect/Effect").Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        toggleDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setDevToolsTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectElement: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectWorker: (kind: "service" | "shared") => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        disableDeviceEmulation: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        edit: (command: import("../WebContents.ts").EditCommand) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        replace: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        replaceMisspelling: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        copyImageAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        startDrag: (drag: import("../WebContents.ts").Drag) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        showDefinitionForSelection: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        takeHeapSnapshot: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        print: (options?: import("../WebContents.ts").PrintOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        pdf: (options?: import("../WebContents.ts").PdfOptions) => import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        capture: (options?: import("../WebContents.ts").CaptureOptions) => import("effect/Effect").Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoom: import("effect/Stream").Stream<{
            readonly factor: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        setZoom: (factor: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        audio: import("effect/Stream").Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        setAudioMuted: (muted: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        userAgent: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setUserAgent: (userAgent: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        insertText: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        savePage: (path: string, type?: import("../WebContents.ts").SaveType) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundThrottling: (allowed: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        find: (text: string, options?: import("../WebContents.ts").FindOptions) => import("effect/Effect").Effect<import("../WebContents.ts").Search, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        findNext: (forward?: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        stopFind: (action?: import("../WebContents.ts").FindStop) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        style: (css: string, options?: import("../WebContents.ts").StyleOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        history: import("effect/Stream").Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        back: import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        forward: import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        go: (index: number) => import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeHistoryEntry: (index: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        clearHistory: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        openDevToolsIn: (host: WebContentsViewHandle, options?: import("../WebContents.ts").DevToolsHostOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        closeDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        console: import("effect/Stream").Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        state: import("effect/Stream").Stream<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        responsiveness: import("effect/Stream").Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        favicons: import("effect/Stream").Stream<readonly string[], never, import("../RuntimeContext.ts").MainContext>;
        title: import("effect/Stream").Stream<string, never, import("../RuntimeContext.ts").MainContext>;
        current: import("effect/Effect").Effect<{
            readonly state: {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        terminate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        recover: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
    }, isClosed: () => boolean) => () => void;
    find: (id: string) => {
        frames: (options?: import("../WebContents.ts").FrameOptions) => import("effect/Stream").Stream<import("../WebContents.ts").Frame, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        painting: import("effect/Effect").Effect<{
            readonly offscreen: boolean;
            readonly painting: boolean;
            readonly frameRate: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setPainting: (painting: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setFrameRate: (rate: import("../WebContents.ts").FrameRate) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        invalidate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        frameTree: import("effect/Effect").Effect<readonly {
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        opener: import("effect/Effect").Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focusedFrame: import("effect/Effect").Effect<{
            readonly processId: number;
            readonly routingId: number;
            readonly frameTreeNodeId: number;
            readonly token: string;
            readonly osProcessId: number;
            readonly isMainFrame: boolean;
            readonly parent: number | null;
            readonly url: string;
            readonly origin: string;
            readonly name: string;
            readonly visibilityState: string;
        } | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        hostId: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devToolsContentsId: import("effect/Effect").Effect<number | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        collectJavaScriptCallStack: import("effect/Effect").Effect<string | null, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoomLevel: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setZoomLevel: (level: import("../WebContents.ts").ZoomLevel) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoomMode: import("effect/Effect").Effect<"default" | "disabled" | "isolated" | "manual", import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setZoomMode: (mode: import("../WebContents.ts").ZoomMode) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        rendererProcessId: import("effect/Effect").Effect<number, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        sharedWorkers: import("effect/Effect").Effect<readonly {
            readonly id: string;
            readonly url: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectSharedWorker: (id: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devToolsTargetId: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        addDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeDevToolsWorkspace: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        printers: import("effect/Effect").Effect<readonly {
            readonly name: string;
            readonly displayName: string;
            readonly description: string;
        }[], import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        webRtc: import("effect/Effect").Effect<{
            readonly ipHandlingPolicy: string;
            readonly udpPortRange: {
                readonly min: number;
                readonly max: number;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWebRtcIpHandlingPolicy: (policy: import("../WebContents.ts").WebRtcIpHandlingPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setWebRtcUdpPortRange: (range: import("../WebContents.ts").UdpPortRange) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        caretBrowsing: import("effect/Effect").Effect<boolean, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setCaretBrowsing: (enabled: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        events: import("effect/Stream").Stream<{
            readonly kind: "context-menu";
            readonly x: number;
            readonly y: number;
            readonly pageUrl: string;
            readonly frameUrl: string;
            readonly linkUrl: string;
            readonly linkText: string;
            readonly sourceUrl: string;
            readonly mediaType: string;
            readonly hasImageContents: boolean;
            readonly isEditable: boolean;
            readonly selectionText: string;
            readonly misspelledWord: string;
            readonly dictionarySuggestions: readonly string[];
            readonly source: string;
            readonly editFlags: {
                readonly canUndo: boolean;
                readonly canRedo: boolean;
                readonly canCut: boolean;
                readonly canCopy: boolean;
                readonly canPaste: boolean;
                readonly canDelete: boolean;
                readonly canSelectAll: boolean;
            };
        } | {
            readonly kind: "cursor";
            readonly type: string;
        } | {
            readonly kind: "target-url";
            readonly url: string;
        } | {
            readonly kind: "theme-color";
            readonly color: string | null;
        } | {
            readonly kind: "html-full-screen";
            readonly active: boolean;
        } | {
            readonly kind: "dom-ready";
        } | {
            readonly kind: "preload-error";
            readonly path: string;
            readonly message: string;
        } | {
            readonly kind: "frame";
            readonly change: "created" | "loaded" | "navigated";
            readonly frame: {
                readonly processId: number;
                readonly routingId: number;
                readonly isMainFrame: boolean;
            };
            readonly url?: string;
            readonly httpStatus?: number;
        } | {
            readonly kind: "devtools";
            readonly change: "closed" | "focused" | "opened";
        } | {
            readonly kind: "devtools-open-url";
            readonly url: string;
        } | {
            readonly kind: "devtools-reload-page";
        } | {
            readonly kind: "devtools-search-query";
            readonly query: string;
        } | {
            readonly kind: "content-bounds-updated";
            readonly bounds: {
                readonly x: number;
                readonly y: number;
                readonly width: number;
                readonly height: number;
            };
        } | {
            readonly kind: "preferred-size";
            readonly width: number;
            readonly height: number;
        } | {
            readonly kind: "input";
            readonly type: string;
        } | {
            readonly kind: "webview-attached";
            readonly nativeId: number;
        } | {
            readonly kind: "frame-will-navigate";
            readonly url: string;
            readonly isMainFrame: boolean;
            readonly isSameDocument: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        activity: import("effect/Effect").Effect<{
            readonly loading: boolean;
            readonly waitingForResponse: boolean;
            readonly crashed: boolean;
            readonly beingCaptured: boolean;
            readonly backgroundThrottling: boolean;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        devTools: import("effect/Effect").Effect<{
            readonly opened: boolean;
            readonly focused: boolean;
            readonly title: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        toggleDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setDevToolsTitle: (title: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectElement: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        inspectWorker: (kind: "service" | "shared") => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        enableDeviceEmulation: (parameters: import("../WebContents.ts").DeviceEmulation) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        disableDeviceEmulation: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        edit: (command: import("../WebContents.ts").EditCommand) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        replace: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        replaceMisspelling: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        adjustSelection: (adjustment: import("../WebContents.ts").SelectionAdjustment) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        copyVideoFrameAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        saveVideoFrameAs: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        copyImageAt: (point: import("../WebContents.ts").PagePoint) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setVisualZoomLimits: (limits: import("../WebContents.ts").VisualZoomLimits) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setImageAnimationPolicy: (policy: import("../WebContents.ts").ImageAnimationPolicy) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        startDrag: (drag: import("../WebContents.ts").Drag) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        showDefinitionForSelection: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        takeHeapSnapshot: (path: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        print: (options?: import("../WebContents.ts").PrintOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        pdf: (options?: import("../WebContents.ts").PdfOptions) => import("effect/Effect").Effect<Uint8Array<ArrayBuffer>, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        capture: (options?: import("../WebContents.ts").CaptureOptions) => import("effect/Effect").Effect<{
            bytes: Uint8Array<ArrayBuffer>;
            width: number;
            height: number;
            scaleFactor: number;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        zoom: import("effect/Stream").Stream<{
            readonly factor: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        setZoom: (factor: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        audio: import("effect/Stream").Stream<{
            readonly muted: boolean;
            readonly audible: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        setAudioMuted: (muted: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        userAgent: import("effect/Effect").Effect<string, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setUserAgent: (userAgent: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        insertText: (text: string) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        savePage: (path: string, type?: import("../WebContents.ts").SaveType) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setBackgroundThrottling: (allowed: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        setIgnoreMenuShortcuts: (ignore: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        find: (text: string, options?: import("../WebContents.ts").FindOptions) => import("effect/Effect").Effect<import("../WebContents.ts").Search, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        findNext: (forward?: boolean) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        stopFind: (action?: import("../WebContents.ts").FindStop) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        style: (css: string, options?: import("../WebContents.ts").StyleOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
        history: import("effect/Stream").Stream<{
            readonly index: number;
            readonly entries: readonly {
                readonly url: string;
                readonly title: string;
            }[];
            readonly canGoBack: boolean;
            readonly canGoForward: boolean;
        }, never, import("../RuntimeContext.ts").MainContext>;
        back: import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        forward: import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        go: (index: number) => import("effect/Effect").Effect<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        removeHistoryEntry: (index: number) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        clearHistory: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        openDevTools: (options?: import("../WebContents.ts").DevToolsOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        openDevToolsIn: (host: WebContentsViewHandle, options?: import("../WebContents.ts").DevToolsHostOptions) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        closeDevTools: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        focus: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        console: import("effect/Stream").Stream<{
            readonly level: "debug" | "error" | "info" | "warning";
            readonly message: string;
            readonly lineNumber: number;
            readonly sourceId: string;
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        state: import("effect/Stream").Stream<{
            readonly status: "ready";
            readonly url: string;
            readonly processId: number;
            readonly httpStatus: number;
        } | {
            readonly status: "failed";
            readonly url: string;
            readonly code: number;
            readonly description: string;
        } | {
            readonly status: "idle";
        } | {
            readonly status: "loading";
            readonly url: string;
        } | {
            readonly status: "gone";
            readonly reason: string;
            readonly exitCode: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        responsiveness: import("effect/Stream").Stream<{
            readonly status: "unknown";
        } | {
            readonly status: "responsive" | "unresponsive";
            readonly processId: number;
        }, never, import("../RuntimeContext.ts").MainContext>;
        favicons: import("effect/Stream").Stream<readonly string[], never, import("../RuntimeContext.ts").MainContext>;
        title: import("effect/Stream").Stream<string, never, import("../RuntimeContext.ts").MainContext>;
        current: import("effect/Effect").Effect<{
            readonly state: {
                readonly status: "ready";
                readonly url: string;
                readonly processId: number;
                readonly httpStatus: number;
            } | {
                readonly status: "failed";
                readonly url: string;
                readonly code: number;
                readonly description: string;
            } | {
                readonly status: "idle";
            } | {
                readonly status: "loading";
                readonly url: string;
            } | {
                readonly status: "gone";
                readonly reason: string;
                readonly exitCode: number;
            };
            readonly history: {
                readonly index: number;
                readonly entries: readonly {
                    readonly url: string;
                    readonly title: string;
                }[];
                readonly canGoBack: boolean;
                readonly canGoForward: boolean;
            };
            readonly title: string;
            readonly favicons: readonly string[];
            readonly zoom: {
                readonly factor: number;
            };
            readonly audio: {
                readonly muted: boolean;
                readonly audible: boolean;
            };
        }, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        terminate: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        recover: import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, import("../RuntimeContext.ts").MainContext>;
        decide: <Event, Answer, Timing extends "sync" | "async", R = never>(decidable: import("../Decision.ts").Decidable<Event, Answer, Timing, import("../Decision.ts").Composition, "contents">, decider: import("../Decision.ts").DeciderFor<NoInfer<Event>, NoInfer<Answer>, NoInfer<Timing>, R>) => import("effect/Effect").Effect<void, import("../SewedError.ts").SewedError, R | import("../RuntimeContext.ts").MainContext | import("effect/Scope").Scope>;
    } | undefined;
};
/** Records the native web contents behind a `WebContentsView` handle, for DevTools hosting. */
export declare const registerView: (handle: WebContentsViewHandle, native: WebContents) => void;
export declare const contentsOfView: (handle: WebContentsViewHandle) => WebContents | undefined;
//# sourceMappingURL=Handles.d.ts.map