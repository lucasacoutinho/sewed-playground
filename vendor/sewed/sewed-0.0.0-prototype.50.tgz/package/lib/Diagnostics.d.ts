import { Effect, Layer, Schema, Stream } from "effect";
import { Sink } from "./internal/Diagnostics.ts";
export { health as runtimeHealth, instrument } from "./internal/Tracing.ts";
export type { HealthOptions } from "./internal/Tracing.ts";
export declare const Placement: Schema.Struct<{
    runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    threadId: Schema.Finite;
    processId: Schema.optionalKey<Schema.Finite>;
    runtimeId: Schema.String;
}>;
export type Placement = typeof Placement.Type;
export declare const TraceSpan: Schema.TaggedStruct<"TraceSpan", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly parentId: Schema.optionalKey<Schema.String>;
    readonly name: Schema.String;
    readonly startTime: Schema.String;
    readonly endTime: Schema.optionalKey<Schema.String>;
    readonly outcome: Schema.Literals<readonly ["running", "success", "failure"]>;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly binding: Schema.optionalKey<Schema.String>;
}>;
export type TraceSpan = typeof TraceSpan.Type;
export declare const TraceEvent: Schema.TaggedStruct<"TraceEvent", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly name: Schema.String;
    readonly time: Schema.String;
}>;
export type TraceEvent = typeof TraceEvent.Type;
export declare const RuntimeSample: Schema.TaggedStruct<"RuntimeSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly delayMs: Schema.Number;
    readonly intervalMs: Schema.Number;
}>;
export type RuntimeSample = typeof RuntimeSample.Type;
export declare const QueueSample: Schema.TaggedStruct<"QueueSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literals<readonly ["rpc-server", "rpc-client"]>;
    readonly size: Schema.Number;
    readonly capacity: Schema.Number;
    readonly activeRequests: Schema.optionalKey<Schema.Number>;
}>;
export type QueueSample = typeof QueueSample.Type;
export declare const QueueClosed: Schema.TaggedStruct<"QueueClosed", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
}>;
export type QueueClosed = typeof QueueClosed.Type;
export declare const Observation: Schema.Union<readonly [Schema.TaggedStruct<"TraceSpan", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly parentId: Schema.optionalKey<Schema.String>;
    readonly name: Schema.String;
    readonly startTime: Schema.String;
    readonly endTime: Schema.optionalKey<Schema.String>;
    readonly outcome: Schema.Literals<readonly ["running", "success", "failure"]>;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly binding: Schema.optionalKey<Schema.String>;
}>, Schema.TaggedStruct<"TraceEvent", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly name: Schema.String;
    readonly time: Schema.String;
}>, Schema.TaggedStruct<"RuntimeSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly delayMs: Schema.Number;
    readonly intervalMs: Schema.Number;
}>, Schema.TaggedStruct<"QueueSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literals<readonly ["rpc-server", "rpc-client"]>;
    readonly size: Schema.Number;
    readonly capacity: Schema.Number;
    readonly activeRequests: Schema.optionalKey<Schema.Number>;
}>, Schema.TaggedStruct<"QueueClosed", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
}>]>;
export type Observation = typeof Observation.Type;
export declare const ResourceChanged: Schema.TaggedStruct<"ResourceChanged", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly resourceId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly state: Schema.Literals<readonly ["acquiring", "ready", "releasing"]>;
}>;
export type ResourceChanged = typeof ResourceChanged.Type;
export declare const ResourceClosed: Schema.TaggedStruct<"ResourceClosed", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly resourceId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
    readonly reason: Schema.String;
}>;
export type ResourceClosed = typeof ResourceClosed.Type;
export declare const TransferProgress: Schema.TaggedStruct<"TransferProgress", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly requestId: Schema.String;
    readonly frames: Schema.Int;
    readonly wireBytes: Schema.Int;
    readonly terminal: Schema.Boolean;
}>;
export type TransferProgress = typeof TransferProgress.Type;
export declare const Event: Schema.Union<readonly [Schema.TaggedStruct<"OwnerStarted", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly ownerId: Schema.String;
}>, Schema.TaggedStruct<"OwnerClosed", {
    readonly ownerId: Schema.String;
    readonly reason: Schema.Literals<readonly ["scope-closed", "shutdown", "terminated", "exited", "startup-failed"]>;
}>, Schema.TaggedStruct<"RuntimeClosed", {
    readonly runtimeId: Schema.String;
}>, Schema.TaggedStruct<"BindingOpened", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly bindingId: Schema.String;
    readonly slot: Schema.String;
    readonly ownerId: Schema.String;
}>, Schema.TaggedStruct<"BindingClosed", {
    readonly bindingId: Schema.String;
    readonly reason: Schema.Literals<readonly ["scope-closed", "navigation", "renderer-gone", "renderer-disconnected", "replaced"]>;
}>, Schema.TaggedStruct<"RequestStarted", {
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly requestId: Schema.String;
    readonly procedure: Schema.String;
    readonly traceId: Schema.optionalKey<Schema.String>;
    readonly spanId: Schema.optionalKey<Schema.String>;
}>, Schema.TaggedStruct<"RequestEnded", {
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly requestId: Schema.String;
    readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
    readonly reason: Schema.String;
}>, Schema.TaggedStruct<"EventsDropped", {
    readonly ownerId: Schema.String;
    readonly count: Schema.Finite;
}>, Schema.TaggedStruct<"ResourceChanged", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly resourceId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly state: Schema.Literals<readonly ["acquiring", "ready", "releasing"]>;
}>, Schema.TaggedStruct<"ResourceClosed", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly resourceId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly outcome: Schema.Literals<readonly ["success", "failure", "interrupted", "disconnected"]>;
    readonly reason: Schema.String;
}>, Schema.TaggedStruct<"TransferProgress", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly ownerId: Schema.String;
    readonly clientId: Schema.Finite;
    readonly requestId: Schema.String;
    readonly frames: Schema.Int;
    readonly wireBytes: Schema.Int;
    readonly terminal: Schema.Boolean;
}>, Schema.TaggedStruct<"TraceSpan", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly parentId: Schema.optionalKey<Schema.String>;
    readonly name: Schema.String;
    readonly startTime: Schema.String;
    readonly endTime: Schema.optionalKey<Schema.String>;
    readonly outcome: Schema.Literals<readonly ["running", "success", "failure"]>;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly binding: Schema.optionalKey<Schema.String>;
}>, Schema.TaggedStruct<"TraceEvent", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly traceId: Schema.String;
    readonly spanId: Schema.String;
    readonly name: Schema.String;
    readonly time: Schema.String;
}>, Schema.TaggedStruct<"RuntimeSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly delayMs: Schema.Number;
    readonly intervalMs: Schema.Number;
}>, Schema.TaggedStruct<"QueueSample", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
    readonly ownerId: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literals<readonly ["rpc-server", "rpc-client"]>;
    readonly size: Schema.Number;
    readonly capacity: Schema.Number;
    readonly activeRequests: Schema.optionalKey<Schema.Number>;
}>, Schema.TaggedStruct<"QueueClosed", {
    readonly runtime: Schema.Literals<readonly ["main", "worker", "utility", "renderer", "unknown"]>;
    readonly threadId: Schema.Finite;
    readonly processId: Schema.optionalKey<Schema.Finite>;
    readonly runtimeId: Schema.String;
    readonly queueId: Schema.String;
}>]>;
export type Event = typeof Event.Type;
export interface Record {
    readonly sequence: number;
    readonly timestamp: number;
    readonly event: Event;
}
export interface Snapshot {
    readonly events: readonly Record[];
    readonly owners: readonly Extract<Event, {
        _tag: "OwnerStarted";
    }>[];
    readonly bindings: readonly Extract<Event, {
        _tag: "BindingOpened";
    }>[];
    readonly requests: readonly Extract<Event, {
        _tag: "RequestStarted";
    }>[];
    readonly resources: readonly ResourceChanged[];
    readonly transfers: readonly TransferProgress[];
    readonly dropped: number;
    /** Number of live resource records evicted from the bounded active map. */
    readonly resourceDropped: number;
    /** Number of live transfer records evicted from the bounded active map. */
    readonly transferDropped: number;
    readonly complete: boolean;
    readonly closed: boolean;
}
/** Scope this collector outside the resources it observes so their finalizers are recorded. */
export declare const make: (options?: {
    readonly capacity?: number;
    readonly tracing?: boolean;
}) => Effect.Effect<{
    layer: Layer.Layer<Sink, never, never>;
    snapshot: Effect.Effect<Snapshot, never, never>;
    changes: Stream.Stream<Record, never, never>;
}, never, import("effect/Scope").Scope>;
export type Collector = Effect.Success<ReturnType<typeof make>>;
//# sourceMappingURL=Diagnostics.d.ts.map