import { Schema } from "effect";
/**
 * A HID device a page may be given. Carries what identifies a device to a person or a policy; the
 * report descriptors Electron also reports (`collections`) are not copied.
 */
export declare const Hid: Schema.Struct<{
    readonly deviceId: Schema.String;
    readonly name: Schema.String;
    readonly vendorId: Schema.Finite;
    readonly productId: Schema.Finite;
    readonly serialNumber: Schema.optionalKey<Schema.String>;
    readonly guid: Schema.optionalKey<Schema.String>;
}>;
export type Hid = typeof Hid.Type;
/**
 * A USB device a page may be given. Carries what identifies a device to a person or a policy; the
 * configuration and interface descriptors Electron also reports are not copied.
 */
export declare const Usb: Schema.Struct<{
    readonly deviceId: Schema.String;
    readonly vendorId: Schema.Finite;
    readonly productId: Schema.Finite;
    readonly deviceClass: Schema.Finite;
    readonly deviceSubclass: Schema.Finite;
    readonly deviceProtocol: Schema.Finite;
    readonly productName: Schema.optionalKey<Schema.String>;
    readonly manufacturerName: Schema.optionalKey<Schema.String>;
    readonly serialNumber: Schema.optionalKey<Schema.String>;
}>;
export type Usb = typeof Usb.Type;
/** A serial port a page may be given; Electron reports its USB ids as strings. */
export declare const SerialPort: Schema.Struct<{
    readonly portId: Schema.String;
    readonly portName: Schema.String;
    readonly displayName: Schema.optionalKey<Schema.String>;
    readonly vendorId: Schema.optionalKey<Schema.String>;
    readonly productId: Schema.optionalKey<Schema.String>;
    readonly serialNumber: Schema.optionalKey<Schema.String>;
}>;
export type SerialPort = typeof SerialPort.Type;
/** A Bluetooth device found while a page's request is scanning. */
export declare const Bluetooth: Schema.Struct<{
    readonly deviceId: Schema.String;
    readonly deviceName: Schema.String;
}>;
export type Bluetooth = typeof Bluetooth.Type;
/** One discoverable WebAuthn credential; `credentialId` is URL-safe base64 without padding. */
export declare const WebAuthnAccount: Schema.Struct<{
    readonly credentialId: Schema.String;
    readonly name: Schema.optionalKey<Schema.String>;
    readonly displayName: Schema.optionalKey<Schema.String>;
    readonly userHandle: Schema.optionalKey<Schema.String>;
}>;
export type WebAuthnAccount = typeof WebAuthnAccount.Type;
export declare const HidRequest: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly devices: Schema.$Array<Schema.Struct<{
        readonly deviceId: Schema.String;
        readonly name: Schema.String;
        readonly vendorId: Schema.Finite;
        readonly productId: Schema.Finite;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
        readonly guid: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export type HidRequest = typeof HidRequest.Type;
export declare const UsbRequest: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly devices: Schema.$Array<Schema.Struct<{
        readonly deviceId: Schema.String;
        readonly vendorId: Schema.Finite;
        readonly productId: Schema.Finite;
        readonly deviceClass: Schema.Finite;
        readonly deviceSubclass: Schema.Finite;
        readonly deviceProtocol: Schema.Finite;
        readonly productName: Schema.optionalKey<Schema.String>;
        readonly manufacturerName: Schema.optionalKey<Schema.String>;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export type UsbRequest = typeof UsbRequest.Type;
export declare const SerialPortRequest: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly ports: Schema.$Array<Schema.Struct<{
        readonly portId: Schema.String;
        readonly portName: Schema.String;
        readonly displayName: Schema.optionalKey<Schema.String>;
        readonly vendorId: Schema.optionalKey<Schema.String>;
        readonly productId: Schema.optionalKey<Schema.String>;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export type SerialPortRequest = typeof SerialPortRequest.Type;
export declare const BluetoothRequest: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly devices: Schema.$Array<Schema.Struct<{
        readonly deviceId: Schema.String;
        readonly deviceName: Schema.String;
    }>>;
}>;
export type BluetoothRequest = typeof BluetoothRequest.Type;
export declare const WebAuthnRequest: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly relyingPartyId: Schema.String;
    readonly accounts: Schema.$Array<Schema.Struct<{
        readonly credentialId: Schema.String;
        readonly name: Schema.optionalKey<Schema.String>;
        readonly displayName: Schema.optionalKey<Schema.String>;
        readonly userHandle: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export type WebAuthnRequest = typeof WebAuthnRequest.Type;
/**
 * What a chooser request receives: nothing, or the id of one of the entries it offered. An id the
 * request did not offer cancels it.
 */
export declare const Selection: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"cancel">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"select">;
    readonly id: Schema.String;
}>]>;
export type Selection = typeof Selection.Type;
/**
 * What a Bluetooth request receives each time its scan reports devices: `wait` keeps the request
 * scanning, so the next report asks again.
 */
export declare const BluetoothSelection: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"cancel">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"select">;
    readonly id: Schema.String;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"wait">;
}>]>;
export type BluetoothSelection = typeof BluetoothSelection.Type;
/**
 * A Bluetooth pairing prompt. `confirm` asks whether to pair, `confirmPin` asks whether `pin`
 * matches the one the device shows, and `providePin` asks for the device's pin.
 */
export declare const Pairing: Schema.Struct<{
    readonly origin: Schema.NullOr<Schema.String>;
    readonly document: Schema.NullOr<Schema.String>;
    readonly deviceId: Schema.String;
    readonly kind: Schema.Literals<readonly ["confirm", "confirmPin", "providePin"]>;
    readonly pin: Schema.optionalKey<Schema.String>;
}>;
export type Pairing = typeof Pairing.Type;
/**
 * The answer to a pairing prompt. `confirm` answers `confirm` and `confirmPin`; `pin` answers
 * `providePin`. An answer of the wrong kind for its prompt cancels the pairing.
 */
export declare const PairingAnswer: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"cancel">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"confirm">;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"pin">;
    readonly pin: Schema.String;
}>]>;
export type PairingAnswer = typeof PairingAnswer.Type;
/**
 * A device that appeared or went away while a chooser request is pending (`added`, `removed`), or
 * whose access a page gave up (`revoked`, which carries the origin when Electron reports one).
 */
export declare const Change: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"hid">;
    readonly change: Schema.Literals<readonly ["added", "removed", "revoked"]>;
    readonly device: Schema.Struct<{
        readonly deviceId: Schema.String;
        readonly name: Schema.String;
        readonly vendorId: Schema.Finite;
        readonly productId: Schema.Finite;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
        readonly guid: Schema.optionalKey<Schema.String>;
    }>;
    readonly origin: Schema.NullOr<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"usb">;
    readonly change: Schema.Literals<readonly ["added", "removed", "revoked"]>;
    readonly device: Schema.Struct<{
        readonly deviceId: Schema.String;
        readonly vendorId: Schema.Finite;
        readonly productId: Schema.Finite;
        readonly deviceClass: Schema.Finite;
        readonly deviceSubclass: Schema.Finite;
        readonly deviceProtocol: Schema.Finite;
        readonly productName: Schema.optionalKey<Schema.String>;
        readonly manufacturerName: Schema.optionalKey<Schema.String>;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
    }>;
    readonly origin: Schema.NullOr<Schema.String>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"serial">;
    readonly change: Schema.Literals<readonly ["added", "removed", "revoked"]>;
    readonly port: Schema.Struct<{
        readonly portId: Schema.String;
        readonly portName: Schema.String;
        readonly displayName: Schema.optionalKey<Schema.String>;
        readonly vendorId: Schema.optionalKey<Schema.String>;
        readonly productId: Schema.optionalKey<Schema.String>;
        readonly serialNumber: Schema.optionalKey<Schema.String>;
    }>;
    readonly origin: Schema.NullOr<Schema.String>;
}>]>;
export type Change = typeof Change.Type;
/** A USB class Chromium can keep away from pages. */
export declare const UsbClass: Schema.Literals<readonly ["audio", "audio-video", "hid", "mass-storage", "smart-card", "video", "wireless"]>;
export type UsbClass = typeof UsbClass.Type;
//# sourceMappingURL=Device.d.ts.map