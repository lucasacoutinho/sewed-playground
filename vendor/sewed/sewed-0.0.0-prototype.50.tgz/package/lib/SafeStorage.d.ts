import { Schema } from "effect";
import * as Binary from "./Binary.ts";
export declare const Availability: Schema.Struct<{
    readonly available: Schema.Boolean;
    readonly backend: Schema.String;
}>;
export type Availability = typeof Availability.Type;
/** Ciphertext with the backend that produced it, so stored secrets stay attributable across OS changes. */
export declare const Sealed: Schema.Struct<{
    readonly version: Schema.Literal<1>;
    readonly backend: Schema.String;
    readonly bytes: Binary.Bytes;
}>;
export type Sealed = typeof Sealed.Type;
//# sourceMappingURL=SafeStorage.d.ts.map