import { Schema } from "effect";
export { Bounds, Point } from "./internal/Geometry.ts";
export declare const Display: Schema.Struct<{
    readonly id: Schema.Finite;
    readonly label: Schema.String;
    readonly bounds: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly workArea: Schema.Struct<{
        readonly x: Schema.Finite;
        readonly y: Schema.Finite;
        readonly width: Schema.Finite;
        readonly height: Schema.Finite;
    }>;
    readonly scaleFactor: Schema.Finite;
    readonly rotation: Schema.Finite;
    readonly internal: Schema.Boolean;
}>;
export type Display = typeof Display.Type;
export declare const Change: Schema.Union<readonly [Schema.Struct<{
    readonly kind: Schema.Literal<"added">;
    readonly display: Schema.Struct<{
        readonly id: Schema.Finite;
        readonly label: Schema.String;
        readonly bounds: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly workArea: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly scaleFactor: Schema.Finite;
        readonly rotation: Schema.Finite;
        readonly internal: Schema.Boolean;
    }>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"removed">;
    readonly display: Schema.Struct<{
        readonly id: Schema.Finite;
        readonly label: Schema.String;
        readonly bounds: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly workArea: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly scaleFactor: Schema.Finite;
        readonly rotation: Schema.Finite;
        readonly internal: Schema.Boolean;
    }>;
}>, Schema.Struct<{
    readonly kind: Schema.Literal<"metrics">;
    readonly display: Schema.Struct<{
        readonly id: Schema.Finite;
        readonly label: Schema.String;
        readonly bounds: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly workArea: Schema.Struct<{
            readonly x: Schema.Finite;
            readonly y: Schema.Finite;
            readonly width: Schema.Finite;
            readonly height: Schema.Finite;
        }>;
        readonly scaleFactor: Schema.Finite;
        readonly rotation: Schema.Finite;
        readonly internal: Schema.Boolean;
    }>;
    readonly metrics: Schema.$Array<Schema.String>;
}>]>;
export type Change = typeof Change.Type;
//# sourceMappingURL=Screen.d.ts.map