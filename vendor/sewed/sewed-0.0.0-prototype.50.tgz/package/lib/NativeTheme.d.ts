import { Schema } from "effect";
import { Rpc, RpcGroup } from "effect/rpc";
import * as Capability from "./Capability.ts";
import { SewedError } from "./SewedError.ts";
export declare const Source: Schema.Literals<readonly ["system", "light", "dark"]>;
export type Source = typeof Source.Type;
export declare const State: Schema.Struct<{
    readonly source: Schema.Literals<readonly ["system", "light", "dark"]>;
    readonly shouldUseDarkColors: Schema.Boolean;
    readonly shouldUseHighContrastColors: Schema.Boolean;
    readonly shouldUseInvertedColorScheme: Schema.Boolean;
    readonly inForcedColorsMode: Schema.Boolean;
    readonly prefersReducedTransparency: Schema.Boolean;
    /** Present on macOS: the user asked for shapes or text beside color differences. */
    readonly shouldDifferentiateWithoutColor: Schema.optionalKey<Schema.Boolean>;
    /** Present on macOS and Windows: whether the taskbar, menu bar and tray are dark. */
    readonly shouldUseDarkColorsForSystemIntegratedUI: Schema.optionalKey<Schema.Boolean>;
}>;
export type State = typeof State.Type;
export declare const protocol: RpcGroup.RpcGroup<Rpc.Rpc<"setSource", Schema.Struct<{
    source: Schema.Literals<readonly ["system", "light", "dark"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly source: Schema.Literals<readonly ["system", "light", "dark"]>;
    readonly shouldUseDarkColors: Schema.Boolean;
    readonly shouldUseHighContrastColors: Schema.Boolean;
    readonly shouldUseInvertedColorScheme: Schema.Boolean;
    readonly inForcedColorsMode: Schema.Boolean;
    readonly prefersReducedTransparency: Schema.Boolean;
    /** Present on macOS: the user asked for shapes or text beside color differences. */
    readonly shouldDifferentiateWithoutColor: Schema.optionalKey<Schema.Boolean>;
    /** Present on macOS and Windows: whether the taskbar, menu bar and tray are dark. */
    readonly shouldUseDarkColorsForSystemIntegratedUI: Schema.optionalKey<Schema.Boolean>;
}>, typeof SewedError>, Schema.Never, never, never>>;
/**
 * What a theme capability may do. Every Layer that carries these options checks before the
 * platform runs, so a served renderer call meets the same rules a main-side call does.
 */
export interface Options {
    /** Whether callers may change the theme source; observing is always allowed. */
    readonly allowSetSource?: boolean;
}
/**
 * The whole theme surface as one capability: `NativeTheme.native` in `sewed/main` carries the
 * options, `Capability.client` reaches it from a document, and `Testing.NativeTheme.memory`
 * stands in for tests.
 */
export declare const capability: Capability.Capability<Rpc.Rpc<"setSource", Schema.Struct<{
    source: Schema.Literals<readonly ["system", "light", "dark"]>;
}>, Schema.Void, typeof SewedError, never, never> | Rpc.Rpc<"state", Schema.Void, import("effect/rpc/RpcSchema").Stream<Schema.Struct<{
    readonly source: Schema.Literals<readonly ["system", "light", "dark"]>;
    readonly shouldUseDarkColors: Schema.Boolean;
    readonly shouldUseHighContrastColors: Schema.Boolean;
    readonly shouldUseInvertedColorScheme: Schema.Boolean;
    readonly inForcedColorsMode: Schema.Boolean;
    readonly prefersReducedTransparency: Schema.Boolean;
    /** Present on macOS: the user asked for shapes or text beside color differences. */
    readonly shouldDifferentiateWithoutColor: Schema.optionalKey<Schema.Boolean>;
    /** Present on macOS and Windows: whether the taskbar, menu bar and tray are dark. */
    readonly shouldUseDarkColorsForSystemIntegratedUI: Schema.optionalKey<Schema.Boolean>;
}>, typeof SewedError>, Schema.Never, never, never>, "sewed/binding/native-theme">;
//# sourceMappingURL=NativeTheme.d.ts.map