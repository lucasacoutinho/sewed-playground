import { Schema } from "effect";
export declare const Options: Schema.Struct<{
    readonly allowFileAccess: Schema.optionalKey<Schema.Boolean>;
}>;
export type Options = typeof Options.Type;
export declare const Info: Schema.Struct<{
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly version: Schema.String;
    readonly url: Schema.String;
}>;
export type Info = typeof Info.Type;
/** An extension loaded into, ready in, or unloaded from a session. */
export declare const Event: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["loaded", "ready", "unloaded"]>;
    readonly extension: Schema.Struct<{
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly version: Schema.String;
        readonly url: Schema.String;
    }>;
}>;
export type Event = typeof Event.Type;
//# sourceMappingURL=Extension.d.ts.map