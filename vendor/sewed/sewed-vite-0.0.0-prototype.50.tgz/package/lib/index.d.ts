import type { Plugin } from "vite";
import type { SewedViteEvent } from "./events.js";
export type { SewedViteEvent };
export interface SewedViteOptions {
    readonly main: string;
    readonly tsconfig?: string;
    readonly cwd?: string;
    readonly electronPath?: string;
    readonly electronArgs?: readonly string[];
    readonly env?: Readonly<Record<string, string>>;
    readonly debounceMs?: number;
    readonly onEvent?: (event: SewedViteEvent) => void;
}
export declare function sewed(options: SewedViteOptions): Plugin;
/**
 * Resolves the Electron binary a launcher spawns: `require("electron")` from `cwd`'s
 * `package.json` (default: the current working directory), the same resolution the `sewed` Vite
 * plugin performs for its own development runs. An explicit `electronPath` overrides resolution
 * entirely and is taken as absolute or resolved against `cwd`. Throws when Electron cannot be
 * resolved there — install Electron >=41 <45 in the consumer project, or pass `electronPath`. A
 * Node launcher can import this from `@sewed/vite` without paying for a Vite dependency: the
 * package's own entry imports `vite` as types only.
 */
export declare function resolveElectron(options?: {
    readonly cwd?: string;
    readonly electronPath?: string;
}): string;
//# sourceMappingURL=index.d.ts.map