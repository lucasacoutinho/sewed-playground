import type { ManagedProcess, ProcessExit } from "./process.js";
import type { SewedViteEvent } from "../events.js";
export type RestartEvent = SewedViteEvent;
export interface RestartCoordinatorOptions<Artifact> {
    readonly build: (generation: number, signal: AbortSignal) => Promise<Artifact>;
    readonly start: (artifact: Artifact, generation: number) => Promise<ManagedProcess>;
    readonly stop: (processHandle: ManagedProcess) => Promise<ProcessExit>;
    readonly discard: (artifact: Artifact) => Promise<void>;
    readonly debounceMs?: number;
    readonly onEvent?: (event: RestartEvent) => void;
    readonly onProcessExit?: (generation: number, exit: ProcessExit) => void;
    readonly onError?: (error: unknown) => void;
}
export declare class RestartCoordinator<Artifact> {
    private readonly options;
    private readonly debounceMs;
    private desiredRevision;
    private handledRevision;
    private generation;
    private running;
    private activeBuild;
    private timer;
    private loop;
    private startup;
    private shutdownPromise;
    private disposed;
    private fatalError;
    private readonly cleanups;
    constructor(options: RestartCoordinatorOptions<Artifact>);
    start(): Promise<void>;
    request(): void;
    shutdown(): Promise<void>;
    private scheduleLoop;
    private runLoop;
    private build;
    private monitor;
    private shutdownInternal;
    private discardArtifact;
    private handleError;
    private emit;
}
//# sourceMappingURL=restart-coordinator.d.ts.map