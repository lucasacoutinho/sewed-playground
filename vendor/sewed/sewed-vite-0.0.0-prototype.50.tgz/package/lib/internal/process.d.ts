export interface ProcessExit {
    readonly code: number | null;
    readonly signal: NodeJS.Signals | null;
}
export interface ManagedProcess {
    readonly pid: number;
    readonly exit: Promise<ProcessExit>;
    readonly requestShutdown: () => void;
}
interface CommandResult {
    readonly code: number | null;
    readonly signal: NodeJS.Signals | null;
    readonly stdout: string;
    readonly stderr: string;
    readonly error: Error | undefined;
}
interface CommandOptions {
    readonly cwd: string;
    readonly signal?: AbortSignal;
    readonly stdio?: "pipe" | "inherit";
    readonly env?: NodeJS.ProcessEnv;
}
export declare function runCommand(command: string, args: readonly string[], options: CommandOptions): Promise<CommandResult>;
export declare function launchManagedProcess(options: {
    readonly command: string;
    readonly args: readonly string[];
    readonly cwd: string;
    readonly env?: NodeJS.ProcessEnv;
}): Promise<ManagedProcess>;
export declare function stopManagedProcess(processHandle: ManagedProcess, gracefulMs?: number, forceMs?: number): Promise<ProcessExit>;
export {};
//# sourceMappingURL=process.d.ts.map