export interface ProjectInfo {
    readonly projectDir: string;
    readonly tsconfigPath: string;
    readonly typescriptCli: string;
    readonly rootDir: string;
    readonly mainPath: string;
    readonly includePatterns: readonly string[];
    readonly includeRoots: readonly string[];
    readonly files: readonly string[];
    readonly watchFiles: readonly string[];
    readonly configPaths: readonly string[];
    readonly packageType: "module" | "commonjs" | undefined;
    readonly packageName: string | undefined;
    readonly packageVersion: string | undefined;
    readonly productName: string | undefined;
    readonly jsx: string | undefined;
}
export interface EmittedProject {
    readonly stageDir: string;
    readonly mainFile: string;
}
interface ProjectOptions {
    readonly projectDir: string;
    readonly tsconfig: string;
    readonly main: string;
    readonly signal: AbortSignal;
    readonly onConfigPaths?: (paths: readonly string[]) => void;
}
export declare function resolveProject(options: ProjectOptions): Promise<ProjectInfo>;
export declare function emitProject(project: ProjectInfo, stageDir: string, signal: AbortSignal): Promise<EmittedProject>;
/** Whether a TypeScript `package.json`'s `version` falls in the supported `>=7 <8` range. */
export declare function isSupportedTypescriptVersion(version: string): boolean;
/**
 * Checks a resolved TypeScript's own `package.json` shape against the supported `>=7 <8` range,
 * returning its version or throwing naming `location` and the version found — the check `@sewed/vite`
 * runs at run time now that `typescript` is not a declared peer (pnpm otherwise warns about
 * whatever major version happens to already be installed, even outside `>=7 <8`, which nothing
 * here can suppress). Takes the parsed `package.json` directly, not a path, so a fake `{ version }`
 * exercises it with no filesystem.
 */
export declare function checkTypescriptVersion(packageJson: {
    readonly version?: unknown;
}, location: string): string;
export declare function isWithin(parent: string, child: string): boolean;
export {};
//# sourceMappingURL=tsc.d.ts.map