/**
 * A listener set for an external store. Subscribing a listener already present does nothing, and
 * each unsubscribe works once, so `first` and `last` bracket the span the set is non-empty.
 */
export declare const subscribers: (lifecycle?: {
    readonly first?: () => void;
    readonly last?: () => void;
}) => {
    notify: () => void;
    subscribe: (listener: () => void) => (() => void);
};
export declare const make: <A>(initial: A, activate: (publish: (value: A) => void) => () => void) => {
    getSnapshot: () => A;
    publish: (value: A) => void;
    subscribe: (listener: () => void) => (() => void);
};
//# sourceMappingURL=Store.d.ts.map