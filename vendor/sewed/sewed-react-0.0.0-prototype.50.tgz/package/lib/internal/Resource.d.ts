import { Cause, Effect } from "effect";
import type { Scope } from "effect";
import type { SewedError } from "sewed";
import * as Connection from "./Connection.ts";
export type State<A, E> = {
    readonly status: "loading";
} | {
    readonly status: "ready";
    readonly value: A;
} | {
    readonly status: "releasing";
} | {
    readonly status: "released";
} | {
    readonly status: "failure";
    readonly cause: Cause.Cause<E | SewedError>;
};
export type Factory<A, E, R> = () => Effect.Effect<A, E, R | Scope.Scope>;
export interface Store<A, E> {
    readonly getSnapshot: () => State<A, E>;
    readonly subscribe: (listener: () => void) => () => void;
    readonly release: () => void;
    readonly reload: () => void;
}
export interface Owner<A, E, R> {
    readonly createStore: (factory: Factory<A, E, R>) => Store<A, E>;
}
/**
 * Creates the non-React owner behind one useResource call.
 *
 * Store creation has no runtime effects. Acquisition begins only when the
 * store receives its first committed subscription. One reconciliation fiber
 * owns the active scope and coalesces all later lifecycle requests.
 */
export declare const make: <A, E, R>(source: Connection.Source<R>) => Owner<A, E, R>;
//# sourceMappingURL=Resource.d.ts.map