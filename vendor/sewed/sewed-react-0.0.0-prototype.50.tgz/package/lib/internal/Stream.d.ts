import { Cause, Stream } from "effect";
import type { SewedError } from "sewed";
import type { ActionServices, Services } from "./Action.ts";
import * as Connection from "./Connection.ts";
export type State<A, E> = {
    readonly status: "loading";
} | {
    readonly status: "value";
    readonly value: A;
} | {
    readonly status: "failure";
    readonly cause: Cause.Cause<E | SewedError>;
};
export declare const make: <A, E>(source: Connection.Source<Services>, factory: () => Stream.Stream<A, E, ActionServices>) => {
    getSnapshot: () => State<A, E>;
    publish: (value: State<A, E>) => void;
    subscribe: (listener: () => void) => (() => void);
};
//# sourceMappingURL=Stream.d.ts.map