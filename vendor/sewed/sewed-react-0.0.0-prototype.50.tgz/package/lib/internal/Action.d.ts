import type { Cause, Effect, Scope } from "effect";
import type { SewedError } from "sewed";
import type { ClientContext, RendererContext } from "sewed";
import type * as Connection from "./Connection.ts";
export type Services = ClientContext | RendererContext;
export type ActionServices = Services | Scope.Scope;
export type State<A, E> = {
    readonly status: "idle";
} | {
    readonly status: "running";
} | {
    readonly status: "success";
    readonly value: A;
} | {
    readonly status: "failure";
    readonly cause: Cause.Cause<E | SewedError>;
} | {
    readonly status: "interrupted";
};
/**
 * The non-React owner behind one useAction call. An action is a resource acquired on demand: each
 * run is one store of a single resource owner, which already closes the run before it — fiber
 * first, then scope — on a replacement, a cancel, an unmount or a lost runtime. This module only
 * starts runs and names their states.
 */
export declare const make: <A, E>(source: Connection.Source<Services>) => {
    getSnapshot: () => State<A, E>;
    publish: (value: State<A, E>) => void;
    subscribe: (listener: () => void) => (() => void);
    run: (factory: () => Effect.Effect<A, E, ActionServices>, mode: "latest" | "exhaust") => void;
    cancel: () => void;
};
//# sourceMappingURL=Action.d.ts.map