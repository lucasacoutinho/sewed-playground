import { Cause, Effect, Exit, Fiber, Scope } from "effect";
import type { Context } from "effect";
import type { SewedError } from "sewed";
/** One factory run in a scope of its own. The scope outlives the fiber until {@link close}. */
export interface Run<A, E> {
    readonly scope: Scope.Closeable;
    readonly fiber: Fiber.Fiber<A, E | SewedError>;
}
export interface Closed<A, E> {
    readonly exit: Exit.Exit<A, E | SewedError>;
    readonly scope: Exit.Exit<void>;
}
export declare const start: <A, E, R>(runtime: Effect.Effect<Context.Context<R>, SewedError>, factory: () => Effect.Effect<A, E, R | Scope.Scope>) => Run<A, E>;
/** Interrupts the run if it is still going, waits for it, then closes its scope with its exit. */
export declare const close: <A, E>(run: Run<A, E>) => Effect.Effect<Closed<A, E>>;
/** What a closed run failed with, an interruption aside: its own failure, its finalizers', or both. */
export declare const failureOf: <A, E>(closed: Closed<A, E>) => Cause.Cause<E | SewedError> | undefined;
//# sourceMappingURL=ScopedRun.d.ts.map