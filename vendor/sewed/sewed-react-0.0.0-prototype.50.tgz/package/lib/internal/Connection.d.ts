import { Cause, Effect, type Fiber } from "effect";
import type { Context, Scope } from "effect";
import { Renderer, SewedError } from "sewed";
import type { ClientContext, RendererContext } from "sewed";
/** Where a renderer runtime is: still binding, ready for hooks, or unavailable with its cause. */
export type RuntimeState = {
    readonly status: "connecting";
} | {
    readonly status: "ready";
} | {
    readonly status: "unavailable";
    readonly cause: Cause.Cause<unknown>;
};
type Services = ClientContext | RendererContext;
/** An external store over one renderer connection, for `useSyncExternalStore` and plain code. */
export interface RuntimeStore {
    readonly subscribe: (listener: () => void) => () => void;
    readonly getSnapshot: () => RuntimeState;
    readonly close: () => void;
    /**
     * The connected runtime: succeeds at once while the store is ready, waits while the handshake
     * is in progress, and fails `Closed` carrying the cause once the store is unavailable. Every
     * hook `flatMap`s this to run its own work, so that work starts for real the moment the store
     * becomes ready, with no remount.
     */
    readonly runtime: Effect.Effect<Context.Context<Services>, SewedError>;
    /**
     * Runs an effect with the connected runtime in its own scope, for code that cannot use hooks.
     * It waits while the handshake is in progress and rejects with a `Closed` SewedError, carrying
     * the cause, when the runtime is unavailable. Runtime loss also interrupts running work and
     * waits for its finalizers before rejecting; an operation or cleanup failure is preserved.
     * An aborted `signal` interrupts the fiber, runs its finalizers, and rejects the promise with
     * the interruption, including when the effect itself aborts the signal during startup.
     */
    readonly run: <A, E>(effect: Effect.Effect<A, E, Services | Scope.Scope>, options?: {
        readonly signal?: AbortSignal;
    }) => Promise<A>;
}
/** What a hook's owner needs of a runtime store: the runtime, and when it stops being one. */
export interface Source<R> {
    readonly runtime: Effect.Effect<Context.Context<R>, SewedError>;
    readonly subscribe: RuntimeStore["subscribe"];
    readonly getSnapshot: RuntimeStore["getSnapshot"];
}
/** Watches a runtime's terminal state without missing an already-unavailable snapshot. */
export declare const watchUnavailable: (store: Pick<RuntimeStore, "subscribe" | "getSnapshot">, onUnavailable: (cause: Cause.Cause<unknown>) => void) => (() => void);
/** The `Closed` `SewedError` every unavailable runtime state fails `runtime`/`run` with. */
export declare const unavailable: (cause: Cause.Cause<unknown>) => SewedError;
/** The failure every owner reports once its runtime is gone. */
export declare const unavailableCause: (cause: Cause.Cause<unknown>) => Cause.Cause<SewedError>;
/**
 * Forks `work` against `source`'s runtime. Losing the runtime interrupts the fiber and tells
 * `onLost` why, so the caller reports `Closed` in place of the interruption. `stop` ends the
 * watch; until then `onLost` hears a loss even after the fiber has finished.
 */
export declare const forkWith: <A, E, R>(source: Source<R>, work: (context: Context.Context<R>) => Effect.Effect<A, E>, onLost: (cause: Cause.Cause<unknown>) => void) => {
    fiber: Fiber.Fiber<A, E | SewedError>;
    stop: () => void;
};
/** `RuntimeStore.run`'s own mechanism, shared by every store this module and `testing.ts` build. */
export declare const runWith: <A, E, R>(source: Source<R>, effect: Effect.Effect<A, E, R | Scope.Scope>, options?: {
    readonly signal?: AbortSignal;
}) => Promise<A>;
/**
 * A store that never changes: `ready` with `context` runs work against it at once; any other
 * state fails every `run` and every read of `runtime` `Closed`, with `state`'s own cause when it
 * carries one.
 */
export declare const staticStore: (state: RuntimeState, context?: Context.Context<Services>) => RuntimeStore;
/**
 * The document's one runtime store: the last stand-in still open, or whatever `connect` last
 * registered, or the static `unavailable` store a plain web page — nothing ever connected —
 * answers. `RuntimeProvider` reads this when it is given no `store` prop.
 */
export declare const documentStore: () => RuntimeStore;
/**
 * Stands `store` in for the document's store until the function this returns removes it — without
 * closing it. `@sewed/react/testing`'s `store(bindings)` calls this while it is open and removes
 * itself on `close()`. Stand-ins may close in any order: the returned closure removes exactly the
 * entry `standIn` pushed, wherever it now sits in {@link standIns}, and is a no-op if that entry is
 * already gone (a second `close()`, or one already removed by this same closure). `documentStore()`
 * keeps answering whichever stand-in remains that opened most recently, and once none are left it
 * falls through to the connected store — never a now-closed stand-in.
 */
export declare const standIn: (store: RuntimeStore) => (() => void);
/**
 * Connects this document to main outside React. The store is `connecting` until the handshake
 * completes, `ready` while the document's scope lives, and `unavailable` when the page has no
 * Sewed preload, the handshake fails, or the connection ends. Registers as `documentStore()`'s
 * store, closing whatever `connect` had registered before it.
 */
export declare const connect: (entry: Renderer.Entry) => RuntimeStore;
export {};
//# sourceMappingURL=Connection.d.ts.map