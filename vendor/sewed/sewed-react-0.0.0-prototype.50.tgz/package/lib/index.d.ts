import type { DependencyList, ReactNode } from "react";
import { Cause, Effect, Scope, Stream } from "effect";
import { Binding, ClientContext } from "sewed";
import type { RendererContext } from "sewed";
import type { Rpc } from "effect/rpc";
import * as Action from "./internal/Action.ts";
import * as Connection from "./internal/Connection.ts";
import * as Resource from "./internal/Resource.ts";
import * as StreamOwner from "./internal/Stream.ts";
export type ActionState<A, E> = Action.State<A, E>;
export type StreamState<A, E> = StreamOwner.State<A, E>;
export type ResourceState<A, E> = Resource.State<A, E>;
export type ResourceServices = ClientContext | RendererContext;
export type RuntimeState = Connection.RuntimeState;
export type RuntimeStore = Connection.RuntimeStore;
export declare const connect: typeof Connection.connect;
export declare const documentStore: typeof Connection.documentStore;
export declare const mount: (container: Element, children: ReactNode) => Effect.Effect<void, never, Action.ActionServices>;
/**
 * Provides a connected runtime to a React tree the application already owns. `store` is
 * optional: omitted, this reads `documentStore()` — the store `connect` last registered for this
 * document, or the static `unavailable` store when nothing has. Every hook memoizes on the store
 * itself, which is stable across connecting, ready and unavailable, so no hook below this
 * provider ever remounts as the runtime arrives or goes away.
 */
export declare const RuntimeProvider: ({ store, children, }: {
    readonly store?: RuntimeStore;
    readonly children?: ReactNode;
}) => import("react").FunctionComponentElement<import("react").ProviderProps<Connection.RuntimeStore>>;
/** The state of the runtime this tree was given: always ready under `mount`. */
export declare const useRuntimeStatus: () => RuntimeState;
export declare const useClient: <Rpcs extends Rpc.Any>(slot: Binding.Slot<Rpcs>, options?: {
    readonly connection?: Binding.Connection;
}) => Binding.Client<Rpcs>;
export declare const useAction: <Args extends readonly unknown[], A, E>(factory: (...args: Args) => Effect.Effect<A, E, Action.ActionServices>, options?: {
    readonly mode?: "latest" | "exhaust";
}) => {
    status: "idle";
    run: (...args: Args) => void;
    cancel: () => void;
} | {
    status: "running";
    run: (...args: Args) => void;
    cancel: () => void;
} | {
    status: "success";
    value: A;
    run: (...args: Args) => void;
    cancel: () => void;
} | {
    status: "failure";
    cause: Cause.Cause<E | import("sewed").SewedError>;
    run: (...args: Args) => void;
    cancel: () => void;
} | {
    status: "interrupted";
    run: (...args: Args) => void;
    cancel: () => void;
};
export declare const useStream: <A, E>(factory: () => Stream.Stream<A, E, Action.ActionServices>, dependencies: DependencyList) => StreamState<A, E>;
export declare const useResource: <A, E>(factory: () => Effect.Effect<A, E, ResourceServices | Scope.Scope>, dependencies: DependencyList) => ResourceState<A, E> & {
    readonly release: () => void;
    readonly reload: () => void;
};
//# sourceMappingURL=index.d.ts.map