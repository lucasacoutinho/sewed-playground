import { Binding } from "sewed";
import * as Connection from "./internal/Connection.ts";
/**
 * A `RuntimeStore` over in-process hosts, for a renderer module's own tests: `bindings` is what
 * `Binding.to(slot, host)` builds from an owner `Testing.host` (from `sewed/testing`) returns —
 * the same shape a real `Binding.layer` list takes, over hosts that dispatch in process instead
 * of across Electron's IPC bridge. There is no handshake to wait for, so the store answers
 * `ready` at once; `run` and every hook this package exports run over that context exactly as
 * `connect`'s does. It stands itself in for `documentStore()` while it stays open, so a renderer
 * module's plain actions — code outside React that reads `documentStore()` directly, the way
 * `connect`'s own consumer does — reach this store during the test too. `close()` closes the
 * scope the bindings' own connections live in, publishes `unavailable`, and removes exactly this
 * store, in any order — so nested or interleaved `store` calls in one test file may close in any
 * order, and a test can prove a component observes disconnection too. The host's own services
 * (whatever scope `Testing.host` itself was built in) are the caller's, and are released the same
 * way any other `Testing.host` use releases them: when that surrounding scope closes.
 */
export declare const store: (bindings: readonly Binding.Bound[]) => Connection.RuntimeStore;
//# sourceMappingURL=testing.d.ts.map